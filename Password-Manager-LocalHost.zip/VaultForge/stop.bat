@echo off
rem Stop the VaultForge background server
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop.ps1" %*
