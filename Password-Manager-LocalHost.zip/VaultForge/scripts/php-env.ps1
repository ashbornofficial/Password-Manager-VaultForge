# Shared helpers for start.ps1, stop.ps1 and run-tests.ps1 (dot-source this file).

function Get-VFPhp {
    if ($env:VAULTFORGE_PHP -and (Test-Path -LiteralPath $env:VAULTFORGE_PHP)) {
        return (Resolve-Path -LiteralPath $env:VAULTFORGE_PHP).Path
    }
    $cmd = Get-Command php -ErrorAction SilentlyContinue
    if (-not $cmd) {
        throw 'PHP was not found on PATH. Install PHP 8.3+ (https://windows.php.net) or set VAULTFORGE_PHP to the full path of php.exe.'
    }
    return $cmd.Source
}

# Arguments that run PHP with VaultForge's own ini file plus only the extensions it needs.
function Get-VFPhpArgs([string]$Php, [string]$Root) {
    $ini = Join-Path $Root 'config\php-server.ini'
    $phpArgs = @('-c', $ini)
    $extDir = Join-Path (Split-Path -Parent $Php) 'ext'
    if (Test-Path -LiteralPath $extDir) {
        $phpArgs += @('-d', "extension_dir=$extDir")
    }
    # Modules compiled into php.exe (no ini loaded).
    $builtin = @(& $Php -n -m 2>$null | ForEach-Object { $_.Trim().ToLowerInvariant() })
    foreach ($ext in @('sodium', 'pdo_sqlite', 'mbstring')) {
        if ($builtin -contains $ext) { continue }
        $dll = Join-Path $extDir "php_$ext.dll"
        if (Test-Path -LiteralPath $dll) {
            $phpArgs += @('-d', "extension=$ext")
        } elseif ($ext -ne 'mbstring') {
            Write-Warning "Required PHP extension '$ext' was not found in $extDir."
        }
    }
    return ,$phpArgs
}

function Format-VFArg([string]$Value) {
    if ($Value -match '[\s"]') { return '"' + ($Value -replace '"', '\"') + '"' }
    return $Value
}
