<?php /** @var int $status @var string $message */ ?>
<section class="card auth-card" aria-labelledby="error-title">
  <h1 id="error-title">
    <?= match (true) {
        $status === 404 => 'Page not found',
        $status === 503 => 'Storage problem',
        $status >= 500 => 'Something went wrong',
        default => 'Request refused',
    } ?>
  </h1>
  <div class="callout callout-error" role="alert"><?= icon('alert') ?><div><?= e($message) ?></div></div>
  <p class="help">Error <?= (int) $status ?>.</p>
  <a class="btn btn-ghost" href="/">Back to VaultForge</a>
</section>
