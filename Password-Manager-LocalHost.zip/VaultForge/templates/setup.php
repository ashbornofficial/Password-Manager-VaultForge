<?php /** @var ?string $error @var int $minLength @var string $csrf */ ?>
<section class="card auth-card" aria-labelledby="setup-title">
  <h1 id="setup-title">Create your vault</h1>
  <p class="muted">Choose a master password. It encrypts everything in VaultForge and is never stored anywhere.</p>

  <div class="callout callout-warn" role="note">
    <?= icon('alert') ?>
    <div>
      <strong>There is no password recovery.</strong>
      If you forget your master password, your vault cannot be decrypted by anyone — including you.
      There is no reset link, hidden recovery key or backdoor. Write it down and keep it somewhere safe.
    </div>
  </div>

  <?php if ($error): ?>
    <div class="callout callout-error" role="alert"><?= icon('alert') ?><div><?= e($error) ?></div></div>
  <?php endif; ?>

  <form method="post" action="/setup" class="form" data-loading="Deriving key…" autocomplete="off">
    <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">
    <div class="field">
      <label for="master_password">Master password</label>
      <div class="input-group">
        <input type="password" id="master_password" name="master_password" required minlength="<?= (int) $minLength ?>" maxlength="1024" autocomplete="new-password" autofocus aria-describedby="mp-help">
        <button type="button" class="icon-btn" data-toggle-visibility="master_password" aria-label="Show password"><?= icon('eye') ?></button>
      </div>
      <div class="strength" data-strength-for="master_password"></div>
      <p class="help" id="mp-help">At least <?= (int) $minLength ?> characters. A passphrase of 5+ random words works well.</p>
    </div>
    <div class="field">
      <label for="master_password_confirm">Confirm master password</label>
      <input type="password" id="master_password_confirm" name="master_password_confirm" required maxlength="1024" autocomplete="new-password" data-match="master_password">
      <p class="help match-hint" aria-live="polite"></p>
    </div>
    <label class="check">
      <input type="checkbox" name="acknowledge" value="1" required>
      <span>I understand that a forgotten master password <strong>cannot be recovered</strong>.</span>
    </label>
    <button type="submit" class="btn btn-primary btn-block"><?= icon('shield') ?><span>Create encrypted vault</span></button>
  </form>
</section>
