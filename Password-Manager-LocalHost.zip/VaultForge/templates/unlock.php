<?php /** @var ?string $error @var int $retryAfter @var string $csrf */ ?>
<section class="card auth-card" aria-labelledby="unlock-title">
  <h1 id="unlock-title">Unlock vault</h1>
  <p class="muted">Enter your master password to decrypt your vault.</p>

  <?php if ($error): ?>
    <div class="callout callout-error" role="alert"><?= icon('alert') ?><div><?= e($error) ?></div></div>
  <?php endif; ?>

  <form method="post" action="/unlock" class="form" data-loading="Unlocking…" autocomplete="off">
    <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">
    <div class="field">
      <label for="master_password">Master password</label>
      <div class="input-group">
        <input type="password" id="master_password" name="master_password" required maxlength="1024" autocomplete="current-password" autofocus>
        <button type="button" class="icon-btn" data-toggle-visibility="master_password" aria-label="Show password"><?= icon('eye') ?></button>
      </div>
    </div>
    <button type="submit" class="btn btn-primary btn-block" <?= $retryAfter > 0 ? 'disabled data-retry-after="' . (int) $retryAfter . '"' : '' ?>>
      <?= icon('lock') ?><span>Unlock</span>
    </button>
  </form>
  <p class="help center">Forgot it? The vault cannot be recovered without the master password.</p>
</section>
