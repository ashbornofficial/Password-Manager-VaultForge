<dialog class="dialog" id="entry-dialog" aria-labelledby="entry-dialog-title">
  <form method="dialog" id="entry-form" class="form" novalidate autocomplete="off">
    <div class="dialog-head">
      <h2 id="entry-dialog-title">New entry</h2>
      <button type="button" class="icon-btn" data-close aria-label="Close"><?= icon('x') ?></button>
    </div>
    <div class="dialog-body">
      <div class="field">
        <label for="entry-name">Website or service <span class="req" aria-hidden="true">*</span></label>
        <input type="text" id="entry-name" name="name" required maxlength="200">
        <p class="error-text" data-error-for="name"></p>
      </div>
      <div class="field">
        <label for="entry-url">URL</label>
        <input type="text" id="entry-url" name="url" maxlength="2048" placeholder="example.com" inputmode="url" spellcheck="false">
        <p class="error-text" data-error-for="url"></p>
      </div>
      <div class="field">
        <label for="entry-username">Username or email</label>
        <input type="text" id="entry-username" name="username" maxlength="320" spellcheck="false" autocomplete="off">
        <p class="error-text" data-error-for="username"></p>
      </div>
      <div class="field">
        <label for="entry-password">Password <span class="req" aria-hidden="true">*</span></label>
        <div class="input-group">
          <input type="password" id="entry-password" name="password" required maxlength="4096" class="mono" spellcheck="false" autocomplete="new-password">
          <button type="button" class="icon-btn" data-toggle-visibility="entry-password" aria-label="Show password"><?= icon('eye') ?></button>
          <button type="button" class="icon-btn" id="entry-generate" aria-label="Generate a password" title="Generate"><?= icon('refresh') ?></button>
        </div>
        <div class="strength" data-strength-for="entry-password"></div>
        <p class="error-text" data-error-for="password"></p>
      </div>
      <div class="field-row">
        <div class="field">
          <label for="entry-category">Category</label>
          <input type="text" id="entry-category" name="category" maxlength="50" list="entry-categories" placeholder="General">
          <datalist id="entry-categories"></datalist>
          <p class="error-text" data-error-for="category"></p>
        </div>
        <label class="check check-center"><input type="checkbox" id="entry-favorite" name="favorite"><span>Favorite</span></label>
      </div>
      <div class="field">
        <label for="entry-notes">Notes <span class="muted">(encrypted)</span></label>
        <textarea id="entry-notes" name="notes" rows="3" maxlength="10000"></textarea>
        <p class="error-text" data-error-for="notes"></p>
      </div>
    </div>
    <div class="dialog-foot">
      <button type="button" class="btn btn-ghost" data-close>Cancel</button>
      <button type="submit" class="btn btn-primary" id="entry-submit"><?= icon('check') ?><span>Save entry</span></button>
    </div>
  </form>
</dialog>
