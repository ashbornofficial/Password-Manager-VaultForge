<?php
/** @var string $title @var string $active @var string $content @var list<string> $scripts @var string $csrf */
/** @var list<array{type:string,message:string}> $flash @var int $idleSeconds @var int $clipboardSeconds */
$nav = [
    'dashboard' => ['/', 'grid', 'Dashboard'],
    'generator' => ['/generator', 'key', 'Generator'],
    'vault' => ['/vault', 'vault', 'Vault'],
    'backup' => ['/backup', 'archive', 'Backup & Restore'],
    'settings' => ['/settings', 'settings', 'Settings'],
];
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= e($csrf) ?>">
  <meta name="referrer" content="same-origin">
  <title><?= e($title) ?> · <?= e($appName) ?></title>
  <link rel="icon" href="/assets/img/favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="/assets/css/app.css?v=<?= e($appVersion) ?>">
  <script src="/assets/js/common.js?v=<?= e($appVersion) ?>" defer></script>
  <?php foreach ($scripts as $script): ?>
  <script src="/assets/js/<?= e($script) ?>.js?v=<?= e($appVersion) ?>" defer></script>
  <?php endforeach; ?>
</head>
<body class="app" data-unlocked="1" data-idle-seconds="<?= (int) $idleSeconds ?>" data-clipboard-seconds="<?= (int) $clipboardSeconds ?>">
<?= $view->render('partials/icons') ?>
<a class="skip-link" href="#content">Skip to content</a>
<div class="shell">
  <aside class="sidebar" id="sidebar" aria-label="Main navigation">
    <div class="brand">
      <span class="brand-mark"><?= icon('shield') ?></span>
      <span class="brand-text"><strong><?= e($appName) ?></strong><small>Local vault</small></span>
    </div>
    <nav class="nav">
      <?php foreach ($nav as $key => [$href, $ico, $label]): ?>
        <a href="<?= e($href) ?>" class="nav-link<?= $active === $key ? ' active' : '' ?>"<?= $active === $key ? ' aria-current="page"' : '' ?>>
          <?= icon($ico) ?><span><?= e($label) ?></span>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
      <div class="autolock" title="The vault locks automatically when you are inactive">
        <?= icon('lock', 'icon icon-sm') ?>
        <span>Auto-lock in <strong id="autolock-remaining">--:--</strong></span>
      </div>
      <form method="post" action="/lock" id="lock-form">
        <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="reason" value="manual" id="lock-reason">
        <button type="submit" class="btn btn-lock"><?= icon('lock') ?><span>Lock vault</span></button>
      </form>
      <p class="local-badge"><span class="dot"></span>127.0.0.1 only · offline</p>
    </div>
  </aside>
  <div class="sidebar-backdrop" id="sidebar-backdrop" hidden></div>
  <div class="main">
    <header class="topbar">
      <button type="button" class="icon-btn menu-btn" id="menu-btn" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><?= icon('menu') ?></button>
      <h1 class="page-title"><?= e($title) ?></h1>
      <button type="submit" form="lock-form" class="icon-btn topbar-lock" aria-label="Lock vault"><?= icon('lock') ?></button>
    </header>
    <main id="content" class="content" tabindex="-1">
      <?= $content ?>
    </main>
  </div>
</div>
<div class="toasts" id="toasts" role="status" aria-live="polite"></div>
<?php foreach ($flash as $f): ?>
  <div class="flash-data" hidden data-type="<?= e($f['type']) ?>" data-message="<?= e($f['message']) ?>"></div>
<?php endforeach; ?>
</body>
</html>
