<?php /** @var int $entryCount @var int $minBackupLength @var int $maxMb @var string $csrf */ ?>
<div class="grid-2">
  <section class="card" aria-labelledby="export-title">
    <div class="card-head"><h2 id="export-title"><?= icon('download') ?> Encrypted backup</h2></div>
    <p class="muted">Downloads a <code>.vfbackup</code> file containing all <?= (int) $entryCount ?> entries, encrypted with
      XChaCha20-Poly1305 using a key derived (Argon2id) from a <strong>separate backup password</strong>.
      Plaintext export is not offered.</p>
    <form method="post" action="/backup/export" class="form" data-loading="Encrypting…" data-loading-reset="8000" autocomplete="off">
      <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">
      <div class="field">
        <label for="exp-master">Current master password</label>
        <input type="password" id="exp-master" name="master_password" required maxlength="1024" autocomplete="current-password">
      </div>
      <div class="field">
        <label for="exp-pass">Backup password</label>
        <div class="input-group">
          <input type="password" id="exp-pass" name="backup_password" required minlength="<?= (int) $minBackupLength ?>" maxlength="1024" autocomplete="new-password">
          <button type="button" class="icon-btn" data-toggle-visibility="exp-pass" aria-label="Show password"><?= icon('eye') ?></button>
        </div>
        <div class="strength" data-strength-for="exp-pass"></div>
        <p class="help">At least <?= (int) $minBackupLength ?> characters and different from the master password. Without it the backup cannot be opened.</p>
      </div>
      <div class="field">
        <label for="exp-pass2">Confirm backup password</label>
        <input type="password" id="exp-pass2" name="backup_password_confirm" required maxlength="1024" autocomplete="new-password" data-match="exp-pass">
        <p class="help match-hint" aria-live="polite"></p>
      </div>
      <button type="submit" class="btn btn-primary"><?= icon('download') ?><span>Download encrypted backup</span></button>
    </form>
  </section>

  <section class="card" aria-labelledby="restore-title">
    <div class="card-head"><h2 id="restore-title"><?= icon('upload') ?> Restore from backup</h2></div>
    <p class="muted">The file's structure and integrity are verified and it is fully decrypted <em>before</em> anything is changed.
      A modified or damaged file is rejected.</p>
    <form method="post" action="/backup/restore" enctype="multipart/form-data" class="form" data-loading="Verifying &amp; restoring…"
          data-confirm-when="#mode-replace" data-confirm-title="Replace all entries?"
          data-confirm-message="Every entry currently in your vault will be deleted and replaced with the contents of the backup. A safety copy of the current database is saved to storage/backups first."
          data-confirm-ok="Replace entries" autocomplete="off">
      <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">
      <div class="field">
        <label for="res-file">Backup file (.vfbackup, max <?= (int) $maxMb ?> MB)</label>
        <input type="file" id="res-file" name="backup_file" accept=".vfbackup,application/json" required>
      </div>
      <div class="field">
        <label for="res-pass">Backup password</label>
        <input type="password" id="res-pass" name="backup_password" required maxlength="1024" autocomplete="off">
      </div>
      <fieldset class="checks">
        <legend>Restore mode</legend>
        <label class="check"><input type="radio" name="mode" value="merge" id="mode-merge" checked><span><strong>Merge</strong> — add backup entries, skip exact duplicates</span></label>
        <label class="check"><input type="radio" name="mode" value="replace" id="mode-replace"><span><strong>Replace</strong> — delete current entries first</span></label>
      </fieldset>
      <div class="callout callout-warn" id="replace-warning" hidden>
        <?= icon('alert') ?>
        <div>
          <strong>This overwrites your vault.</strong> All <?= (int) $entryCount ?> current entries will be replaced.
          <label class="check"><input type="checkbox" name="confirm_replace" value="1" id="confirm-replace"><span>I understand my current entries will be replaced.</span></label>
        </div>
      </div>
      <button type="submit" class="btn btn-primary"><?= icon('upload') ?><span>Verify &amp; restore</span></button>
    </form>
  </section>
</div>

<section class="card">
  <h2><?= icon('info') ?> About backups</h2>
  <ul class="bullets">
    <li>Backups are portable: they can be restored into this vault or a newly created one on another PC.</li>
    <li>Keep backup files and their password separate. Anyone with both can read your passwords.</li>
    <li>To move to a new PC: create a vault there, then restore with <em>Replace</em> or <em>Merge</em>.</li>
    <li>The raw database <code>storage/vault.sqlite</code> is never downloadable through the browser.</li>
  </ul>
</section>
