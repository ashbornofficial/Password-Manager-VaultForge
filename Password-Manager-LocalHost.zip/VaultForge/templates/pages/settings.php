<?php
/** @var int $autoLockMinutes @var int $clipboardSeconds @var array $autoLock @var int $clipboardMax @var ?int $idleOverride */
/** @var array $kdf @var array $kdfTarget @var string $cipher @var string $kdfAlg @var string $sodiumVersion */
/** @var string $dbPath @var int $dbSize @var int $entryCount @var int $minLength @var string $phpVersion @var string $csrf */
$mib = static fn (int $b): string => number_format($b / 1048576, 0) . ' MiB';
?>
<div class="grid-2">
  <section class="card" aria-labelledby="pref-title">
    <h2 id="pref-title">Security preferences</h2>
    <form method="post" action="/settings/preferences" class="form">
      <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">
      <div class="field">
        <label for="auto_lock_minutes">Auto-lock after inactivity (minutes)</label>
        <input type="number" id="auto_lock_minutes" name="auto_lock_minutes" required min="<?= (int) $autoLock['min_minutes'] ?>" max="<?= (int) $autoLock['max_minutes'] ?>" value="<?= (int) $autoLockMinutes ?>">
        <p class="help">Enforced by the server and the browser. <?= (int) $autoLock['min_minutes'] ?>–<?= (int) $autoLock['max_minutes'] ?> minutes.</p>
        <?php if ($idleOverride !== null): ?>
          <p class="help warn">VAULTFORGE_IDLE_SECONDS is set: auto-lock is currently forced to <?= (int) $idleOverride ?> seconds.</p>
        <?php endif; ?>
      </div>
      <div class="field">
        <label for="clipboard_clear_seconds">Clear copied passwords after (seconds)</label>
        <input type="number" id="clipboard_clear_seconds" name="clipboard_clear_seconds" required min="0" max="<?= (int) $clipboardMax ?>" value="<?= (int) $clipboardSeconds ?>">
        <p class="help">0 disables. Best effort: browsers only allow clearing while VaultForge's tab has focus.</p>
      </div>
      <button type="submit" class="btn btn-primary"><?= icon('check') ?><span>Save preferences</span></button>
    </form>
  </section>

  <section class="card" aria-labelledby="mp-title">
    <h2 id="mp-title">Change master password</h2>
    <p class="muted">Also rotates the data-encryption key: all <?= (int) $entryCount ?> entries are re-encrypted in one transaction.</p>
    <form method="post" action="/settings/master-password" class="form" data-loading="Re-encrypting…" autocomplete="off">
      <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">
      <div class="field">
        <label for="current_password">Current master password</label>
        <input type="password" id="current_password" name="current_password" required maxlength="1024" autocomplete="current-password">
      </div>
      <div class="field">
        <label for="new_password">New master password</label>
        <div class="input-group">
          <input type="password" id="new_password" name="new_password" required minlength="<?= (int) $minLength ?>" maxlength="1024" autocomplete="new-password">
          <button type="button" class="icon-btn" data-toggle-visibility="new_password" aria-label="Show password"><?= icon('eye') ?></button>
        </div>
        <div class="strength" data-strength-for="new_password"></div>
      </div>
      <div class="field">
        <label for="new_password_confirm">Confirm new master password</label>
        <input type="password" id="new_password_confirm" name="new_password_confirm" required maxlength="1024" autocomplete="new-password" data-match="new_password">
        <p class="help match-hint" aria-live="polite"></p>
      </div>
      <button type="submit" class="btn btn-primary"><?= icon('key') ?><span>Change master password</span></button>
    </form>
  </section>
</div>

<section class="card" aria-labelledby="info-title">
  <h2 id="info-title">How your data is protected</h2>
  <dl class="info-list">
    <dt>Key derivation</dt>
    <dd><?= e($kdfAlg) ?> (Argon2id) · <?= (int) $kdf['opslimit'] ?> passes · <?= e($mib((int) $kdf['memlimit'])) ?> · random 128-bit salt
      <?php if ((int) $kdf['opslimit'] !== (int) $kdfTarget['opslimit'] || (int) $kdf['memlimit'] !== (int) $kdfTarget['memlimit']): ?>
        <span class="warn">(changing the master password upgrades to <?= (int) $kdfTarget['opslimit'] ?> passes / <?= e($mib((int) $kdfTarget['memlimit'])) ?>)</span>
      <?php endif; ?>
    </dd>
    <dt>Encryption</dt><dd><?= e($cipher) ?> with a random 256-bit data key, itself wrapped by the master-password key</dd>
    <dt>Encrypted fields</dt><dd>Name, URL, username, password, notes, category</dd>
    <dt>Plaintext metadata</dt><dd>Entry count, favorite flag, created/updated timestamps, KDF parameters, preferences</dd>
    <dt>Database file</dt><dd><code><?= e($dbPath) ?></code> (<?= e(number_format($dbSize / 1024, 1)) ?> KiB). SQLite itself is <strong>not</strong> encrypted; sensitive fields are encrypted individually by the application.</dd>
    <dt>Vault created</dt><dd><?= e($kdf['created_at']) ?> UTC · key last changed <?= e($kdf['updated_at']) ?> UTC</dd>
    <dt>Runtime</dt><dd>PHP <?= e($phpVersion) ?> · libsodium <?= e($sodiumVersion) ?></dd>
    <dt>Recovery</dt><dd>None. Without the master password (or a backup and its password) the vault cannot be decrypted.</dd>
  </dl>
</section>
