<?php /** @var int $minLength @var int $maxLength @var string $ambiguous @var int $minWords @var int $maxWords @var int $wordCount */ ?>
<section class="card gen-card" aria-labelledby="gen-title">
  <h2 id="gen-title" class="sr-only">Generated value</h2>
  <div class="tabs" role="tablist" aria-label="Generator type">
    <button type="button" role="tab" class="tab active" id="tab-password" aria-selected="true" aria-controls="panel-password">Password</button>
    <button type="button" role="tab" class="tab" id="tab-passphrase" aria-selected="false" aria-controls="panel-passphrase" tabindex="-1">Passphrase</button>
  </div>

  <div class="gen-output" id="gen-output" aria-live="polite" data-sensitive></div>
  <div class="strength" id="gen-strength"></div>
  <p class="callout callout-error" id="gen-error" role="alert" hidden></p>

  <div class="btn-row">
    <button type="button" class="btn btn-ghost" id="gen-regen"><?= icon('refresh') ?><span>Regenerate</span></button>
    <button type="button" class="btn btn-ghost" id="gen-copy"><?= icon('copy') ?><span>Copy</span></button>
    <button type="button" class="btn btn-primary" id="gen-save"><?= icon('plus') ?><span>Save to vault</span></button>
  </div>
</section>

<section class="card" id="panel-password" role="tabpanel" aria-labelledby="tab-password">
  <h2>Password options</h2>
  <form id="password-options" class="form options-grid" novalidate>
    <div class="field field-wide">
      <label for="opt-length">Length: <strong id="opt-length-value">20</strong></label>
      <div class="range-row">
        <input type="range" id="opt-length" min="<?= (int) $minLength ?>" max="<?= (int) $maxLength ?>" value="20">
        <input type="number" id="opt-length-num" min="<?= (int) $minLength ?>" max="<?= (int) $maxLength ?>" value="20" aria-label="Length">
      </div>
    </div>
    <fieldset class="field-wide checks" id="class-checks">
      <legend>Character types</legend>
      <label class="check"><input type="checkbox" id="opt-upper" checked><span>Uppercase (A–Z)</span></label>
      <label class="check"><input type="checkbox" id="opt-lower" checked><span>Lowercase (a–z)</span></label>
      <label class="check"><input type="checkbox" id="opt-digits" checked><span>Numbers (0–9)</span></label>
      <label class="check"><input type="checkbox" id="opt-symbols" checked><span>Symbols (!@#…)</span></label>
    </fieldset>
    <label class="check field-wide">
      <input type="checkbox" id="opt-ambiguous">
      <span>Exclude ambiguous characters <code class="mono"><?= e(implode(' ', str_split($ambiguous))) ?></code></span>
    </label>
    <div class="field field-wide">
      <label class="check"><input type="checkbox" id="opt-custom-on"><span>Use a custom character set instead</span></label>
      <input type="text" id="opt-custom" maxlength="1024" placeholder="e.g. abcdef0123456789" disabled aria-describedby="custom-help" spellcheck="false" autocomplete="off">
      <p class="help" id="custom-help">Only these characters are used (duplicates and spaces are ignored; at least 2 distinct characters).</p>
    </div>
  </form>
</section>

<section class="card" id="panel-passphrase" role="tabpanel" aria-labelledby="tab-passphrase" hidden>
  <h2>Passphrase options</h2>
  <form id="passphrase-options" class="form options-grid" novalidate>
    <div class="field field-wide">
      <label for="opt-words">Words: <strong id="opt-words-value">5</strong></label>
      <input type="range" id="opt-words" min="<?= (int) $minWords ?>" max="<?= (int) $maxWords ?>" value="5">
      <p class="help">Word list: <?= (int) $wordCount ?> words (≈<?= e(number_format(log($wordCount, 2), 1)) ?> bits per word).</p>
    </div>
    <div class="field">
      <label for="opt-separator">Separator</label>
      <select id="opt-separator">
        <option value="hyphen">Hyphen ( - )</option>
        <option value="space">Space</option>
        <option value="period">Period ( . )</option>
        <option value="underscore">Underscore ( _ )</option>
        <option value="comma">Comma ( , )</option>
        <option value="digit">Random digit</option>
        <option value="none">None</option>
      </select>
    </div>
    <fieldset class="checks">
      <legend>Extras</legend>
      <label class="check"><input type="checkbox" id="opt-capitalize"><span>Capitalize words</span></label>
      <label class="check"><input type="checkbox" id="opt-number"><span>Add a number</span></label>
    </fieldset>
  </form>
</section>

<?= $view->render('partials/entry-dialog') ?>
