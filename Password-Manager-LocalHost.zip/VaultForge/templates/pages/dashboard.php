<section class="stats" aria-label="Vault statistics">
  <div class="stat"><span class="stat-label">Saved entries</span><strong class="stat-value" id="stat-total">–</strong></div>
  <div class="stat"><span class="stat-label">Favorites</span><strong class="stat-value" id="stat-favorites">–</strong></div>
  <div class="stat"><span class="stat-label">Categories</span><strong class="stat-value" id="stat-categories">–</strong></div>
  <div class="stat stat-warn"><span class="stat-label">Weak passwords</span><strong class="stat-value" id="stat-weak">–</strong></div>
  <div class="stat stat-warn"><span class="stat-label">Reused passwords</span><strong class="stat-value" id="stat-reused">–</strong></div>
</section>

<div class="grid-2">
  <section class="card" aria-labelledby="recent-title">
    <div class="card-head">
      <h2 id="recent-title">Recently updated</h2>
      <a class="btn btn-ghost btn-sm" href="/vault">Open vault</a>
    </div>
    <ul class="recent-list" id="recent-list" aria-live="polite"></ul>
    <div class="empty" id="recent-empty" hidden>
      <?= icon('vault', 'icon icon-xl') ?>
      <p><strong>Your vault is empty.</strong></p>
      <p class="muted">Generate a strong password and save it, or add an existing login.</p>
      <button type="button" class="btn btn-primary" id="dash-add"><?= icon('plus') ?><span>Add entry</span></button>
    </div>
  </section>

  <section class="card" aria-labelledby="quick-title">
    <div class="card-head">
      <h2 id="quick-title">Quick generate</h2>
      <a class="btn btn-ghost btn-sm" href="/generator">More options</a>
    </div>
    <p class="muted">20 characters · upper, lower, digits &amp; symbols.</p>
    <div class="gen-output gen-output-sm" id="quick-output" aria-live="polite" data-sensitive></div>
    <div class="strength" id="quick-strength"></div>
    <div class="btn-row">
      <button type="button" class="btn btn-ghost" id="quick-regen"><?= icon('refresh') ?><span>Regenerate</span></button>
      <button type="button" class="btn btn-ghost" id="quick-copy"><?= icon('copy') ?><span>Copy</span></button>
      <button type="button" class="btn btn-primary" id="quick-save"><?= icon('plus') ?><span>Save to vault</span></button>
    </div>
  </section>
</div>

<section class="card" aria-labelledby="cat-title">
  <h2 id="cat-title">Categories</h2>
  <div class="chips" id="category-chips"></div>
  <p class="muted" id="category-empty" hidden>No categories yet.</p>
</section>

<?= $view->render('partials/entry-dialog') ?>
