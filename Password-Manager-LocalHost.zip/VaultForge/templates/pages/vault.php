<section class="toolbar card" aria-label="Search and filters">
  <div class="search">
    <?= icon('search') ?>
    <label for="vault-search" class="sr-only">Search entries</label>
    <input type="search" id="vault-search" placeholder="Search name, username, URL…" maxlength="200" autocomplete="off">
  </div>
  <div class="field-inline">
    <label for="vault-category" class="sr-only">Category</label>
    <select id="vault-category"><option value="">All categories</option></select>
  </div>
  <div class="field-inline">
    <label for="vault-sort" class="sr-only">Sort</label>
    <select id="vault-sort">
      <option value="name">Name (A–Z)</option>
      <option value="updated">Recently updated</option>
      <option value="created">Recently created</option>
    </select>
  </div>
  <button type="button" class="btn btn-ghost toggle" id="vault-favorites" aria-pressed="false"><?= icon('star') ?><span>Favorites</span></button>
  <button type="button" class="btn btn-primary" id="vault-add"><?= icon('plus') ?><span>New entry</span></button>
</section>

<p class="muted result-count" id="vault-count" aria-live="polite"></p>
<ul class="entries" id="vault-list"></ul>

<div class="empty card" id="vault-empty" hidden>
  <?= icon('vault', 'icon icon-xl') ?>
  <p><strong id="vault-empty-title">No entries yet</strong></p>
  <p class="muted" id="vault-empty-text">Add your first login or generate a new password.</p>
  <button type="button" class="btn btn-primary" id="vault-empty-add"><?= icon('plus') ?><span>Add entry</span></button>
</div>

<?= $view->render('partials/entry-dialog') ?>
