<?php /** @var string $title @var string $content @var string $csrf @var array $flash */ ?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= e($csrf) ?>">
  <meta name="referrer" content="same-origin">
  <title><?= e($title) ?> · <?= e($appName) ?></title>
  <link rel="icon" href="/assets/img/favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="/assets/css/app.css?v=<?= e($appVersion) ?>">
  <script src="/assets/js/common.js?v=<?= e($appVersion) ?>" defer></script>
</head>
<body class="auth">
<?= $view->render('partials/icons') ?>
<main class="auth-wrap">
  <div class="auth-brand">
    <span class="brand-mark brand-mark-lg"><?= icon('shield') ?></span>
    <div><strong><?= e($appName) ?></strong><small>Private local password manager</small></div>
  </div>
  <?= $content ?>
  <p class="auth-foot"><span class="dot"></span>Runs only on this computer (127.0.0.1). No cloud, no tracking.</p>
</main>
<div class="toasts" id="toasts" role="status" aria-live="polite"></div>
<?php foreach ($flash as $f): ?>
  <div class="flash-data" hidden data-type="<?= e($f['type']) ?>" data-message="<?= e($f['message']) ?>"></div>
<?php endforeach; ?>
</body>
</html>
