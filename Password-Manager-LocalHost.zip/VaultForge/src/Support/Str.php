<?php

declare(strict_types=1);

namespace VaultForge\Support;

/** UTF-8 string helpers that work with or without the mbstring extension. */
final class Str
{
    public static function isUtf8(string $value): bool
    {
        return preg_match('//u', $value) === 1;
    }

    /** @return list<string> one element per Unicode code point */
    public static function chars(string $value): array
    {
        if ($value === '') {
            return [];
        }
        $chars = preg_split('//u', $value, -1, PREG_SPLIT_NO_EMPTY);
        return $chars === false ? [] : $chars;
    }

    public static function length(string $value): int
    {
        return count(self::chars($value));
    }

    public static function lower(string $value): string
    {
        return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    }

    /** Unicode code point of a single character. */
    public static function ord(string $char): int
    {
        if (strlen($char) === 1) {
            return ord($char);
        }
        if (function_exists('mb_ord')) {
            return (int) mb_ord($char, 'UTF-8');
        }
        $utf32 = iconv('UTF-8', 'UTF-32BE', $char);
        return $utf32 === false ? 0 : (int) unpack('N', $utf32)[1];
    }

    /** True if the string contains control characters (other than tab/newline when allowed). */
    public static function hasControlChars(string $value, bool $allowNewlines = false): bool
    {
        $pattern = $allowNewlines ? '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/' : '/[\x00-\x1F\x7F]/';
        return preg_match($pattern, $value) === 1;
    }
}
