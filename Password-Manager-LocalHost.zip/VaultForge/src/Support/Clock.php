<?php

declare(strict_types=1);

namespace VaultForge\Support;

final class Clock
{
    public const PATTERN = '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/';

    /** Current UTC time as ISO-8601 (e.g. 2026-10-13T09:30:00Z). */
    public static function now(): string
    {
        return gmdate('Y-m-d\TH:i:s\Z');
    }

    public static function isValid(string $value): bool
    {
        if (!preg_match(self::PATTERN, $value)) {
            return false;
        }
        $parsed = \DateTimeImmutable::createFromFormat('Y-m-d\TH:i:s\Z', $value, new \DateTimeZone('UTC'));
        return $parsed !== false && $parsed->format('Y-m-d\TH:i:s\Z') === $value;
    }
}
