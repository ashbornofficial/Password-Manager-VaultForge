<?php

declare(strict_types=1);

namespace VaultForge\Support;

/**
 * Append-only event log. Only event names and non-sensitive scalar context are written:
 * never passwords, keys, decrypted vault data or request bodies.
 */
final class Logger
{
    private static ?string $dir = null;

    public static function configure(string $dir): void
    {
        self::$dir = $dir;
    }

    /** @param array<string, scalar|null> $context */
    public static function event(string $event, array $context = []): void
    {
        if (self::$dir === null) {
            return;
        }
        if (!is_dir(self::$dir) && !@mkdir(self::$dir, 0700, true) && !is_dir(self::$dir)) {
            return;
        }
        $safe = [];
        foreach ($context as $key => $value) {
            if (is_scalar($value) || $value === null) {
                $safe[(string) $key] = is_string($value) && strlen($value) > 300 ? substr($value, 0, 300) . '...' : $value;
            }
        }
        $line = json_encode(
            ['ts' => Clock::now(), 'event' => $event] + $safe,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
        );
        @file_put_contents(self::$dir . DIRECTORY_SEPARATOR . 'app.log', $line . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}
