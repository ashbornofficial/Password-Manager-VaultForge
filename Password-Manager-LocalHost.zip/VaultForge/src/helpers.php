<?php

declare(strict_types=1);

if (!function_exists('e')) {
    /** Escape a value for safe output in HTML text and attribute contexts. */
    function e(mixed $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
    }
}

if (!function_exists('icon')) {
    /** Reference an icon from the inline SVG sprite (templates/partials/icons.php). */
    function icon(string $name, string $class = 'icon'): string
    {
        $name = preg_replace('/[^a-z0-9-]/', '', $name) ?? '';
        return '<svg class="' . e($class) . '" aria-hidden="true" focusable="false"><use href="#i-' . $name . '"></use></svg>';
    }
}
