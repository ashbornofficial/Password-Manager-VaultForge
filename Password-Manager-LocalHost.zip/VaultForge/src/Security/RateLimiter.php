<?php

declare(strict_types=1);

namespace VaultForge\Security;

use PDO;

/**
 * Throttles master-password verification (unlock, backup export, password change).
 * State lives in SQLite so it survives server restarts and session resets.
 * Note: this protects the running app; offline attacks on a stolen database are
 * resisted by Argon2id, not by this limiter.
 */
final class RateLimiter
{
    public function __construct(
        private readonly PDO $db,
        private readonly int $maxAttempts,
        private readonly int $baseLockout,
        private readonly int $maxLockout,
    ) {
    }

    /** Seconds until another attempt is allowed (0 = allowed now). */
    public function retryAfter(): int
    {
        $row = $this->row();
        return max(0, (int) $row['locked_until'] - time());
    }

    public function failures(): int
    {
        return (int) $this->row()['failed_count'];
    }

    public function recordFailure(): void
    {
        $this->db->beginTransaction();
        try {
            $failed = (int) $this->row()['failed_count'] + 1;
            $lockedUntil = 0;
            if ($failed >= $this->maxAttempts) {
                $exponent = min(20, $failed - $this->maxAttempts);
                $lockedUntil = time() + min($this->maxLockout, $this->baseLockout * (2 ** $exponent));
            }
            $stmt = $this->db->prepare('UPDATE login_throttle SET failed_count = :f, locked_until = :l, last_failed_at = :t WHERE id = 1');
            $stmt->execute([':f' => $failed, ':l' => $lockedUntil, ':t' => time()]);
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function reset(): void
    {
        $this->db->exec('UPDATE login_throttle SET failed_count = 0, locked_until = 0 WHERE id = 1');
    }

    /** @return array{failed_count: int, locked_until: int} */
    private function row(): array
    {
        $row = $this->db->query('SELECT failed_count, locked_until FROM login_throttle WHERE id = 1')->fetch();
        if ($row === false) {
            $this->db->exec('INSERT OR IGNORE INTO login_throttle (id, failed_count, locked_until, last_failed_at) VALUES (1, 0, 0, 0)');
            return ['failed_count' => 0, 'locked_until' => 0];
        }
        return $row;
    }
}
