<?php

declare(strict_types=1);

namespace VaultForge\Security;

final class Csrf
{
    public static function valid(SessionManager $session, mixed $token): bool
    {
        return is_string($token) && $token !== '' && hash_equals($session->csrfToken(), $token);
    }
}
