<?php

declare(strict_types=1);

namespace VaultForge\Security;

use VaultForge\Http\HttpException;
use VaultForge\Http\Request;

/**
 * Refuses anything that is not a loopback connection with an expected Host header.
 * This blocks LAN access if the server is ever bound to 0.0.0.0 by mistake, and
 * blocks DNS-rebinding attacks from web pages that resolve their own domain to 127.0.0.1.
 */
final class HostGuard
{
    /** @param list<string> $allowedHosts */
    public static function assertLocal(Request $request, array $allowedHosts): void
    {
        $remote = (string) ($request->server['REMOTE_ADDR'] ?? '');
        if (!in_array($remote, ['127.0.0.1', '::1'], true)) {
            throw new HttpException(403, 'VaultForge only accepts connections from this computer.');
        }
        $host = strtolower((string) ($request->server['HTTP_HOST'] ?? ''));
        if (!in_array($host, $allowedHosts, true)) {
            throw new HttpException(421, 'Unrecognised Host header. Open VaultForge at http://' . $allowedHosts[0] . '/');
        }
    }

    /** @param list<string> $allowedHosts @return list<string> */
    public static function allowedOrigins(array $allowedHosts): array
    {
        return array_map(static fn (string $h): string => 'http://' . $h, $allowedHosts);
    }
}
