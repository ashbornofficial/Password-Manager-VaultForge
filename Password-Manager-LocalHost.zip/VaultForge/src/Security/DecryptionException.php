<?php

declare(strict_types=1);

namespace VaultForge\Security;

final class DecryptionException extends \RuntimeException
{
}
