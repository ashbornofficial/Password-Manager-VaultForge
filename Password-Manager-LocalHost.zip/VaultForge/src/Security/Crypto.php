<?php

declare(strict_types=1);

namespace VaultForge\Security;

/**
 * Thin, opinionated wrapper around libsodium.
 *
 * Ciphertext format:  "VF1" (3 bytes) || nonce (24 bytes) || XChaCha20-Poly1305 ciphertext+tag
 * The magic prefix is also bound into the associated data, and callers pass a context
 * string (e.g. "entry:<uid>:password") so a ciphertext cannot be moved to another field/row.
 */
final class Crypto
{
    public const MAGIC = 'VF1';
    public const KEY_BYTES = SODIUM_CRYPTO_AEAD_XCHACHA20POLY1305_IETF_KEYBYTES;
    public const NONCE_BYTES = SODIUM_CRYPTO_AEAD_XCHACHA20POLY1305_IETF_NPUBBYTES;
    public const TAG_BYTES = SODIUM_CRYPTO_AEAD_XCHACHA20POLY1305_IETF_ABYTES;
    public const SALT_BYTES = SODIUM_CRYPTO_PWHASH_SALTBYTES;
    public const MIN_BLOB = 3 + self::NONCE_BYTES + self::TAG_BYTES;
    public const KDF_ALG = 'argon2id13';

    // Bounds accepted when reading KDF parameters from disk or from a backup file,
    // so a tampered file cannot force absurd CPU/memory use.
    public const OPSLIMIT_MIN = 1;
    public const OPSLIMIT_MAX = 10;
    public const MEMLIMIT_MIN = 8 * 1024 * 1024;
    public const MEMLIMIT_MAX = 1024 * 1024 * 1024;

    public static function newKey(): string
    {
        return sodium_crypto_aead_xchacha20poly1305_ietf_keygen();
    }

    public static function newSalt(): string
    {
        return random_bytes(self::SALT_BYTES);
    }

    /** Derive a 256-bit key from a password with Argon2id (libsodium crypto_pwhash). */
    public static function deriveKey(#[\SensitiveParameter] string $password, string $salt, int $opslimit, int $memlimit): string
    {
        if (strlen($salt) !== self::SALT_BYTES) {
            throw new \InvalidArgumentException('Invalid salt length.');
        }
        if (!self::kdfParamsValid($opslimit, $memlimit)) {
            throw new \InvalidArgumentException('KDF parameters out of the accepted range.');
        }
        return sodium_crypto_pwhash(
            self::KEY_BYTES,
            $password,
            $salt,
            $opslimit,
            $memlimit,
            SODIUM_CRYPTO_PWHASH_ALG_ARGON2ID13
        );
    }

    public static function kdfParamsValid(int $opslimit, int $memlimit): bool
    {
        return $opslimit >= self::OPSLIMIT_MIN && $opslimit <= self::OPSLIMIT_MAX
            && $memlimit >= self::MEMLIMIT_MIN && $memlimit <= self::MEMLIMIT_MAX;
    }

    public static function encrypt(#[\SensitiveParameter] string $plaintext, #[\SensitiveParameter] string $key, string $context): string
    {
        self::assertKey($key);
        $nonce = random_bytes(self::NONCE_BYTES);
        $ciphertext = sodium_crypto_aead_xchacha20poly1305_ietf_encrypt($plaintext, self::MAGIC . '|' . $context, $nonce, $key);
        return self::MAGIC . $nonce . $ciphertext;
    }

    /** @throws DecryptionException if the key/context is wrong or the data was modified */
    public static function decrypt(string $blob, #[\SensitiveParameter] string $key, string $context): string
    {
        self::assertKey($key);
        if (strlen($blob) < self::MIN_BLOB || !str_starts_with($blob, self::MAGIC)) {
            throw new DecryptionException('Ciphertext is malformed.');
        }
        $nonce = substr($blob, 3, self::NONCE_BYTES);
        $ciphertext = substr($blob, 3 + self::NONCE_BYTES);
        try {
            $plaintext = sodium_crypto_aead_xchacha20poly1305_ietf_decrypt($ciphertext, self::MAGIC . '|' . $context, $nonce, $key);
        } catch (\SodiumException) {
            $plaintext = false;
        }
        if ($plaintext === false) {
            throw new DecryptionException('Authentication failed: wrong key or tampered data.');
        }
        return $plaintext;
    }

    /** Best-effort wipe of a sensitive string held in a variable. */
    public static function wipe(?string &$value): void
    {
        if (is_string($value) && $value !== '') {
            sodium_memzero($value);
        }
        $value = null;
    }

    private static function assertKey(string $key): void
    {
        if (strlen($key) !== self::KEY_BYTES) {
            throw new \InvalidArgumentException('Invalid key length.');
        }
    }
}
