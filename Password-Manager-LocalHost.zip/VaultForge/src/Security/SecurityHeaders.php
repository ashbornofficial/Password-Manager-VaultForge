<?php

declare(strict_types=1);

namespace VaultForge\Security;

use VaultForge\Http\Response;

final class SecurityHeaders
{
    public const CSP = "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; font-src 'self'; "
        . "connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'; "
        . "manifest-src 'none'; worker-src 'none'";

    public static function apply(Response $response): void
    {
        $defaults = [
            'Content-Security-Policy' => self::CSP,
            'X-Content-Type-Options' => 'nosniff',
            'X-Frame-Options' => 'DENY',
            // "same-origin" (not "no-referrer"): with no-referrer, Chromium sends "Origin: null"
            // on form POSTs, which the Origin check would reject. Nothing leaks cross-origin.
            'Referrer-Policy' => 'same-origin',
            'Permissions-Policy' => 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=(), interest-cohort=()',
            'Cross-Origin-Opener-Policy' => 'same-origin',
            'Cross-Origin-Resource-Policy' => 'same-origin',
            'Cross-Origin-Embedder-Policy' => 'require-corp',
            'X-Permitted-Cross-Domain-Policies' => 'none',
            'Cache-Control' => 'no-store, max-age=0',
            'Pragma' => 'no-cache',
        ];
        foreach ($defaults as $name => $value) {
            if (!$response->hasHeader($name)) {
                $response->headers[$name] = $value;
            }
        }
    }
}
