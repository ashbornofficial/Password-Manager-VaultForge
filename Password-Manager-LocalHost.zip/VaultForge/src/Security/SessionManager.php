<?php

declare(strict_types=1);

namespace VaultForge\Security;

use VaultForge\Database\StorageException;

/**
 * PHP session handling plus the "split key" that keeps the vault's data-encryption key (DEK)
 * available between requests while the vault is unlocked:
 *
 *   session file (server)  : DEK encrypted with a random per-unlock wrapping key
 *   VFKEY cookie (browser) : that wrapping key (HttpOnly, SameSite=Strict)
 *
 * Neither half alone reveals the DEK. Locking deletes the session file and the cookie.
 */
final class SessionManager
{
    public const COOKIE_NAME = 'VFSESSID';
    public const KEY_COOKIE = 'VFKEY';
    private const DEK_CONTEXT = 'session-dek:v1';

    public function __construct(
        private readonly string $savePath,
        private readonly bool $secureCookies,
        private readonly int $absoluteLifetime,
    ) {
    }

    public function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        if (!is_dir($this->savePath) && !@mkdir($this->savePath, 0700, true) && !is_dir($this->savePath)) {
            throw new StorageException('sessions', 'The session directory could not be created inside the storage folder.');
        }

        ini_set('session.save_handler', 'files');
        ini_set('session.save_path', $this->savePath);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_cookies', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.use_trans_sid', '0');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', 'Strict');
        ini_set('session.cookie_secure', $this->secureCookies ? '1' : '0');
        ini_set('session.cache_limiter', '');
        ini_set('session.gc_maxlifetime', (string) $this->absoluteLifetime);
        ini_set('session.gc_probability', '1');
        ini_set('session.gc_divisor', '50');
        ini_set('session.lazy_write', '1');

        session_name(self::COOKIE_NAME);
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'domain' => '',
            'secure' => $this->secureCookies,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);

        if (!session_start()) {
            throw new StorageException('sessions', 'The PHP session could not be started.');
        }
        if (!isset($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
    }

    public function csrfToken(): string
    {
        return (string) ($_SESSION['csrf'] ?? '');
    }

    public function isUnlocked(): bool
    {
        return isset($_SESSION['vault']['dek'], $_SESSION['vault']['last_activity'], $_SESSION['vault']['unlocked_at']);
    }

    /** Mark the session unlocked. Regenerates the session ID and CSRF token (fixation defence). */
    public function unlock(#[\SensitiveParameter] string $dek): void
    {
        session_regenerate_id(true);
        $wrapKey = Crypto::newKey();
        $now = time();
        $_SESSION['vault'] = [
            'dek' => base64_encode(Crypto::encrypt($dek, $wrapKey, self::DEK_CONTEXT)),
            'unlocked_at' => $now,
            'last_activity' => $now,
        ];
        $_SESSION['csrf'] = bin2hex(random_bytes(32));

        $encoded = sodium_bin2base64($wrapKey, SODIUM_BASE64_VARIANT_URLSAFE_NO_PADDING);
        $this->setKeyCookie($encoded, 0);
        $_COOKIE[self::KEY_COOKIE] = $encoded;
        sodium_memzero($wrapKey);
    }

    /** The vault DEK for this request, or null if locked / the key cookie is missing or wrong. */
    public function dek(): ?string
    {
        if (!$this->isUnlocked()) {
            return null;
        }
        $cookie = $_COOKIE[self::KEY_COOKIE] ?? null;
        if (!is_string($cookie) || $cookie === '' || strlen($cookie) > 64) {
            return null;
        }
        try {
            $wrapKey = sodium_base642bin($cookie, SODIUM_BASE64_VARIANT_URLSAFE_NO_PADDING);
            if (strlen($wrapKey) !== Crypto::KEY_BYTES) {
                return null;
            }
            $blob = base64_decode((string) $_SESSION['vault']['dek'], true);
            if ($blob === false) {
                return null;
            }
            $dek = Crypto::decrypt($blob, $wrapKey, self::DEK_CONTEXT);
            sodium_memzero($wrapKey);
            return $dek;
        } catch (\SodiumException | DecryptionException) {
            return null;
        }
    }

    /** True when the unlocked session exceeded the idle timeout or the absolute lifetime. */
    public function isExpired(int $idleSeconds): bool
    {
        if (!$this->isUnlocked()) {
            return false;
        }
        $now = time();
        return ($now - (int) $_SESSION['vault']['last_activity']) > $idleSeconds
            || ($now - (int) $_SESSION['vault']['unlocked_at']) > $this->absoluteLifetime;
    }

    public function touch(): void
    {
        if ($this->isUnlocked()) {
            $_SESSION['vault']['last_activity'] = time();
        }
    }

    public function secondsUntilIdleLock(int $idleSeconds): int
    {
        if (!$this->isUnlocked()) {
            return 0;
        }
        return max(0, $idleSeconds - (time() - (int) $_SESSION['vault']['last_activity']));
    }

    /** Lock the vault: wipe all session data, delete the old session file and the key cookie. */
    public function lock(): void
    {
        if (isset($_SESSION['vault']['dek']) && is_string($_SESSION['vault']['dek'])) {
            sodium_memzero($_SESSION['vault']['dek']);
        }
        $_SESSION = [];
        session_regenerate_id(true);
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        $this->setKeyCookie('', time() - 86400);
        unset($_COOKIE[self::KEY_COOKIE]);
    }

    public function flash(string $type, string $message): void
    {
        $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
    }

    /** @return list<array{type: string, message: string}> */
    public function pullFlash(): array
    {
        $flash = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return is_array($flash) ? array_values($flash) : [];
    }

    private function setKeyCookie(string $value, int $expires): void
    {
        setcookie(self::KEY_COOKIE, $value, [
            'expires' => $expires,
            'path' => '/',
            'domain' => '',
            'secure' => $this->secureCookies,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
    }
}
