<?php

declare(strict_types=1);

namespace VaultForge\Generator;

final class PassphraseGenerator
{
    public const MIN_WORDS = 3;
    public const MAX_WORDS = 20;
    public const SEPARATORS = [
        'hyphen' => '-',
        'space' => ' ',
        'period' => '.',
        'underscore' => '_',
        'comma' => ',',
        'none' => '',
        'digit' => null, // a random digit between words
    ];

    /** @var list<string>|null */
    private static ?array $words = null;

    /** @return array{password: string, entropy: float, word_count: int, list_size: int} */
    public function generate(int $wordCount, string $separator = 'hyphen', bool $capitalize = false, bool $includeNumber = false): array
    {
        if ($wordCount < self::MIN_WORDS || $wordCount > self::MAX_WORDS) {
            throw new \InvalidArgumentException('Word count must be between ' . self::MIN_WORDS . ' and ' . self::MAX_WORDS . '.');
        }
        if (!array_key_exists($separator, self::SEPARATORS)) {
            throw new \InvalidArgumentException('Unknown separator.');
        }
        $list = self::wordlist();
        $size = count($list);

        $words = [];
        for ($i = 0; $i < $wordCount; $i++) {
            $word = $list[random_int(0, $size - 1)];
            $words[] = $capitalize ? ucfirst($word) : $word;
        }
        $entropy = $wordCount * log($size, 2);

        if ($includeNumber) {
            $index = random_int(0, $wordCount - 1);
            $words[$index] .= (string) random_int(0, 9);
            $entropy += log(10, 2) + log($wordCount, 2);
        }

        $sep = self::SEPARATORS[$separator];
        if ($sep === null) {
            $out = $words[0];
            for ($i = 1; $i < $wordCount; $i++) {
                $out .= random_int(0, 9) . $words[$i];
            }
            $entropy += ($wordCount - 1) * log(10, 2);
        } else {
            $out = implode($sep, $words);
        }

        return ['password' => $out, 'entropy' => round($entropy, 1), 'word_count' => $wordCount, 'list_size' => $size];
    }

    /** @return list<string> unique lowercase words, 3–9 letters */
    public static function wordlist(): array
    {
        if (self::$words !== null) {
            return self::$words;
        }
        $raw = file_get_contents(__DIR__ . '/wordlist.txt');
        if ($raw === false) {
            throw new \RuntimeException('Word list is missing.');
        }
        $words = preg_split('/\s+/', strtolower($raw), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $words = array_values(array_unique(array_filter($words, static fn (string $w): bool => preg_match('/^[a-z]{3,9}$/', $w) === 1)));
        if (count($words) < 1024) {
            throw new \RuntimeException('Word list is too small for secure passphrases.');
        }
        return self::$words = $words;
    }
}
