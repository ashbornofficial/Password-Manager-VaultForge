<?php

declare(strict_types=1);

namespace VaultForge\Generator;

use VaultForge\Support\Str;

/**
 * Cryptographically secure password generation (random_int, i.e. the OS CSPRNG).
 * Guarantees: exact length, only characters from the selected pool, and at least one
 * character from every selected class.
 */
final class PasswordGenerator
{
    public const MIN_LENGTH = 8;
    public const MAX_LENGTH = 128;
    public const MAX_CUSTOM_CHARS = 256;

    public const SETS = [
        'upper' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        'lower' => 'abcdefghijklmnopqrstuvwxyz',
        'digits' => '0123456789',
        'symbols' => '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~',
    ];

    /** Look-alike or hard-to-read characters removed by "exclude ambiguous". */
    public const AMBIGUOUS = 'Il1|O0o`\'".,:;';

    /**
     * @param array{length?: int, upper?: bool, lower?: bool, digits?: bool, symbols?: bool, exclude_ambiguous?: bool, custom?: string} $options
     * @return array{password: string, entropy: float, pool_size: int}
     */
    public function generate(array $options): array
    {
        $length = $options['length'] ?? 20;
        if (!is_int($length) || $length < self::MIN_LENGTH || $length > self::MAX_LENGTH) {
            throw new \InvalidArgumentException('Length must be between ' . self::MIN_LENGTH . ' and ' . self::MAX_LENGTH . '.');
        }
        $excludeAmbiguous = (bool) ($options['exclude_ambiguous'] ?? false);
        $groups = $this->groups($options, $excludeAmbiguous);

        $pool = array_values(array_unique(array_merge(...array_values($groups))));
        $chars = [];
        foreach ($groups as $group) {
            $chars[] = $group[random_int(0, count($group) - 1)];
        }
        $poolSize = count($pool);
        while (count($chars) < $length) {
            $chars[] = $pool[random_int(0, $poolSize - 1)];
        }
        // Fisher–Yates shuffle so the guaranteed characters are not at fixed positions.
        for ($i = count($chars) - 1; $i > 0; $i--) {
            $j = random_int(0, $i);
            [$chars[$i], $chars[$j]] = [$chars[$j], $chars[$i]];
        }

        return [
            'password' => implode('', $chars),
            'entropy' => round($length * log($poolSize, 2), 1),
            'pool_size' => $poolSize,
        ];
    }

    /** @return array<string, list<string>> */
    public function groups(array $options, bool $excludeAmbiguous): array
    {
        $ambiguous = str_split(self::AMBIGUOUS);
        $filter = static fn (array $chars): array => $excludeAmbiguous
            ? array_values(array_diff($chars, $ambiguous))
            : $chars;

        $custom = $options['custom'] ?? '';
        if (!is_string($custom)) {
            throw new \InvalidArgumentException('Custom character set must be text.');
        }
        if ($custom !== '') {
            if (strlen($custom) > 4096 || !Str::isUtf8($custom)) {
                throw new \InvalidArgumentException('Custom character set is too long or not valid UTF-8.');
            }
            $chars = array_values(array_unique(array_filter(
                Str::chars($custom),
                static fn (string $c): bool => preg_match('/^[\p{C}\p{Z}\s]$/u', $c) !== 1
            )));
            $chars = $filter($chars);
            if (count($chars) < 2) {
                throw new \InvalidArgumentException('The custom character set needs at least 2 distinct visible characters.');
            }
            if (count($chars) > self::MAX_CUSTOM_CHARS) {
                throw new \InvalidArgumentException('The custom character set may contain at most ' . self::MAX_CUSTOM_CHARS . ' distinct characters.');
            }
            return ['custom' => $chars];
        }

        $groups = [];
        foreach (self::SETS as $name => $set) {
            if (!empty($options[$name])) {
                $groups[$name] = $filter(str_split($set));
            }
        }
        if ($groups === []) {
            throw new \InvalidArgumentException('Select at least one character type.');
        }
        return $groups;
    }
}
