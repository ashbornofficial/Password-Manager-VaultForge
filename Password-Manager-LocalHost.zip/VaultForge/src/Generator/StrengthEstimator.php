<?php

declare(strict_types=1);

namespace VaultForge\Generator;

use VaultForge\Support\Str;

/**
 * Heuristic strength estimate for passwords typed by people.
 * Mirrors VF.strength() in public/assets/js/common.js — keep the two in sync.
 * Generated passwords report their exact entropy from the generator instead.
 */
final class StrengthEstimator
{
    public const COMMON = [
        'password', 'passw0rd', 'qwerty', 'letmein', 'welcome', 'admin', 'iloveyou', 'monkey', 'dragon',
        'football', 'baseball', 'master', 'login', 'abc123', '123456', '111111', '000000', 'sunshine',
        'princess', 'trustno1', 'superman', 'starwars', 'shadow', 'secret', 'hello', 'freedom',
        'whatever', 'qazwsx', 'asdf', 'zxcv', '1234', 'test', 'changeme',
    ];

    public const LABELS = ['Very weak', 'Weak', 'Fair', 'Strong', 'Very strong'];

    /** @return array{bits: float, score: int, label: string} */
    public static function estimate(string $password): array
    {
        $chars = Str::chars($password);
        $length = count($chars);
        if ($length === 0) {
            return ['bits' => 0.0, 'score' => 0, 'label' => self::LABELS[0]];
        }

        $pool = 0;
        if (preg_match('/[a-z]/', $password)) {
            $pool += 26;
        }
        if (preg_match('/[A-Z]/', $password)) {
            $pool += 26;
        }
        if (preg_match('/[0-9]/', $password)) {
            $pool += 10;
        }
        if (preg_match('/[\x20-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E]/', $password)) {
            $pool += 33;
        }
        if (preg_match('/[^\x00-\x7F]/', $password)) {
            $pool += 100;
        }
        $pool = max($pool, 2);

        $penalty = 0.0;
        for ($i = 1; $i < $length; $i++) {
            $a = Str::ord($chars[$i - 1]);
            $b = Str::ord($chars[$i]);
            if ($a === $b) {
                $penalty += 1;
            } elseif (abs($a - $b) === 1) {
                $penalty += 0.5;
            }
        }
        $lower = strtolower($password);
        foreach (self::COMMON as $word) {
            if (str_contains($lower, $word)) {
                $penalty += strlen($word) - 1;
            }
        }

        $perChar = log($pool, 2);
        $bits = max(1.0, $length - $penalty) * $perChar;
        $unique = count(array_unique($chars));
        $bits = min($bits, $unique * 2 * $perChar);

        return self::fromBits(round($bits, 1));
    }

    /** @return array{bits: float, score: int, label: string} */
    public static function fromBits(float $bits): array
    {
        $score = match (true) {
            $bits < 28 => 0,
            $bits < 36 => 1,
            $bits < 60 => 2,
            $bits < 80 => 3,
            default => 4,
        };
        return ['bits' => $bits, 'score' => $score, 'label' => self::LABELS[$score]];
    }
}
