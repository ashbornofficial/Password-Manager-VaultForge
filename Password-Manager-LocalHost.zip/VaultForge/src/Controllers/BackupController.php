<?php

declare(strict_types=1);

namespace VaultForge\Controllers;

use VaultForge\App;
use VaultForge\Auth\InvalidMasterPasswordException;
use VaultForge\Auth\MasterPasswordGate;
use VaultForge\Auth\ThrottledException;
use VaultForge\Backup\BackupException;
use VaultForge\Database\Connection;
use VaultForge\Http\Request;
use VaultForge\Http\Response;
use VaultForge\Support\Logger;
use VaultForge\Vault\ValidationException;

final class BackupController
{
    public function __construct(private readonly App $app)
    {
    }

    /** Download an encrypted backup. Requires the master password again plus a separate backup password. */
    public function export(Request $request): Response
    {
        $session = $this->app->session();
        $master = $request->input('master_password');
        $backupPassword = $request->input('backup_password');

        $error = $this->app->policy()->checkBackup($backupPassword, $request->input('backup_password_confirm'), $master);
        if ($error !== null) {
            return $this->fail($error);
        }
        try {
            $dek = (new MasterPasswordGate($this->app->keys(), $this->app->limiter()))->verify($master, 'backup_export');
            sodium_memzero($dek);
        } catch (ThrottledException | InvalidMasterPasswordException $e) {
            return $this->fail($e->getMessage());
        }

        $entries = $this->app->entries()->exportAll();
        $file = $this->app->backups()->create($entries, $backupPassword);
        Logger::event('backup_exported', ['entries' => count($entries)]);
        return Response::download($file, 'vaultforge-backup-' . gmdate('Ymd-His') . '.vfbackup', 'application/octet-stream');
    }

    /** Validate, decrypt and import a backup file. */
    public function restore(Request $request): Response
    {
        $mode = $request->input('mode');
        if (!in_array($mode, ['merge', 'replace'], true)) {
            return $this->fail('Choose how the backup should be restored.');
        }
        if ($mode === 'replace' && $request->input('confirm_replace') !== '1') {
            return $this->fail('Tick the confirmation box to replace all current entries.');
        }

        $upload = $request->files['backup_file'] ?? null;
        $maxBytes = (int) $this->app->config['backup']['max_bytes'];
        if (!is_array($upload) || !isset($upload['error']) || is_array($upload['error'])) {
            return $this->fail('Choose a backup file to restore.');
        }
        if ($upload['error'] === UPLOAD_ERR_INI_SIZE || $upload['error'] === UPLOAD_ERR_FORM_SIZE || (int) $upload['size'] > $maxBytes) {
            return $this->fail('The backup file is too large.');
        }
        if ($upload['error'] !== UPLOAD_ERR_OK || !is_uploaded_file((string) $upload['tmp_name'])) {
            return $this->fail('The backup file could not be uploaded. Please try again.');
        }
        $raw = (string) file_get_contents((string) $upload['tmp_name'], false, null, 0, $maxBytes + 1);
        @unlink((string) $upload['tmp_name']);

        try {
            $backups = $this->app->backups();
            $entries = $backups->decrypt($backups->parse($raw), $request->input('backup_password'));
        } catch (BackupException $e) {
            Logger::event('backup_restore_rejected');
            return $this->fail($e->getMessage());
        }

        $snapshot = null;
        if ($mode === 'replace') {
            $snapshot = $this->app->storagePath('backups') . DIRECTORY_SEPARATOR . 'pre-restore-' . gmdate('Ymd-His') . '.sqlite';
            Connection::snapshot($this->app->db(), $snapshot);
        }

        try {
            $result = $this->app->entries()->import($entries, $mode);
        } catch (ValidationException $e) {
            return $this->fail($e->getMessage());
        }

        Logger::event('backup_restored', ['mode' => $mode] + $result);
        $message = "Restore complete: {$result['added']} entries added";
        $message .= $mode === 'replace' ? ", {$result['removed']} previous entries replaced." : ", {$result['skipped']} duplicates skipped.";
        if ($snapshot !== null) {
            $message .= ' A safety copy of the previous database was saved to storage/backups/' . basename($snapshot) . '.';
        }
        $this->app->session()->flash('success', $message);
        return Response::redirect('/backup');
    }

    private function fail(string $message): Response
    {
        $this->app->session()->flash('error', $message);
        return Response::redirect('/backup');
    }
}
