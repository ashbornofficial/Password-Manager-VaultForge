<?php

declare(strict_types=1);

namespace VaultForge\Controllers;

use VaultForge\App;
use VaultForge\Generator\PassphraseGenerator;
use VaultForge\Generator\PasswordGenerator;
use VaultForge\Generator\StrengthEstimator;
use VaultForge\Http\HttpException;
use VaultForge\Http\Request;
use VaultForge\Http\Response;

final class GeneratorApiController
{
    public function __construct(private readonly App $app)
    {
    }

    public function password(Request $request): Response
    {
        $in = $request->json();
        $options = [
            'length' => self::int($in, 'length', 20),
            'upper' => self::bool($in, 'upper', true),
            'lower' => self::bool($in, 'lower', true),
            'digits' => self::bool($in, 'digits', true),
            'symbols' => self::bool($in, 'symbols', true),
            'exclude_ambiguous' => self::bool($in, 'exclude_ambiguous', false),
            'custom' => self::string($in, 'custom'),
        ];
        try {
            $result = (new PasswordGenerator())->generate($options);
        } catch (\InvalidArgumentException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        }
        return Response::json($result + ['strength' => StrengthEstimator::fromBits($result['entropy'])]);
    }

    public function passphrase(Request $request): Response
    {
        $in = $request->json();
        try {
            $result = (new PassphraseGenerator())->generate(
                self::int($in, 'words', 5),
                self::string($in, 'separator') ?: 'hyphen',
                self::bool($in, 'capitalize', false),
                self::bool($in, 'number', false),
            );
        } catch (\InvalidArgumentException $e) {
            return Response::json(['error' => $e->getMessage()], 422);
        }
        return Response::json($result + ['strength' => StrengthEstimator::fromBits($result['entropy'])]);
    }

    /** Keep-alive sent by the browser only while the user is actively using the page. */
    public function ping(Request $request): Response
    {
        $idle = $this->app->idleSeconds();
        return Response::json(['ok' => true, 'idle_seconds' => $idle, 'remaining' => $this->app->session()->secondsUntilIdleLock($idle)]);
    }

    private static function int(array $in, string $key, int $default): int
    {
        if (!array_key_exists($key, $in)) {
            return $default;
        }
        if (!is_int($in[$key])) {
            throw new HttpException(422, "$key must be an integer.");
        }
        return $in[$key];
    }

    private static function bool(array $in, string $key, bool $default): bool
    {
        if (!array_key_exists($key, $in)) {
            return $default;
        }
        if (!is_bool($in[$key])) {
            throw new HttpException(422, "$key must be true or false.");
        }
        return $in[$key];
    }

    private static function string(array $in, string $key): string
    {
        $value = $in[$key] ?? '';
        if (!is_string($value)) {
            throw new HttpException(422, "$key must be text.");
        }
        return $value;
    }
}
