<?php

declare(strict_types=1);

namespace VaultForge\Controllers;

use VaultForge\App;
use VaultForge\Http\HttpException;
use VaultForge\Http\Request;
use VaultForge\Http\Response;
use VaultForge\Security\DecryptionException;
use VaultForge\Support\Logger;
use VaultForge\Support\Str;
use VaultForge\Vault\ValidationException;

final class EntryApiController
{
    public function __construct(private readonly App $app)
    {
    }

    public function index(Request $request): Response
    {
        $query = $request->queryString('q');
        $category = $request->queryString('category');
        if (Str::length($query) > 200 || Str::length($category) > 50 || !Str::isUtf8($query . $category)) {
            throw new HttpException(422, 'Search text is too long.');
        }
        $sort = $request->queryString('sort');
        $sort = in_array($sort, ['name', 'updated', 'created'], true) ? $sort : 'name';
        $service = $this->app->entries();
        $entries = $service->list($query, $category, $request->queryString('favorites') === '1', $sort);
        return Response::json([
            'entries' => $entries,
            'count' => count($entries),
            'categories' => $service->categories(),
        ]);
    }

    public function store(Request $request): Response
    {
        try {
            $entry = $this->app->entries()->create($request->json());
        } catch (ValidationException $e) {
            return Response::json(['error' => $e->getMessage(), 'errors' => $e->errors], 422);
        }
        Logger::event('entry_created', ['id' => $entry['id']]);
        return Response::json(['entry' => $entry], 201);
    }

    public function show(Request $request, string $id): Response
    {
        $entry = $this->app->entries()->get((int) $id);
        if ($entry === null) {
            throw new HttpException(404, 'Entry not found.');
        }
        return Response::json(['entry' => $entry]);
    }

    public function secret(Request $request, string $id): Response
    {
        try {
            $secret = $this->app->entries()->secret((int) $id);
        } catch (DecryptionException) {
            throw new HttpException(500, 'This entry cannot be decrypted. It may be corrupted.');
        }
        if ($secret === null) {
            throw new HttpException(404, 'Entry not found.');
        }
        return Response::json($secret);
    }

    public function update(Request $request, string $id): Response
    {
        try {
            $entry = $this->app->entries()->update((int) $id, $request->json());
        } catch (ValidationException $e) {
            return Response::json(['error' => $e->getMessage(), 'errors' => $e->errors], 422);
        }
        if ($entry === null) {
            throw new HttpException(404, 'Entry not found.');
        }
        Logger::event('entry_updated', ['id' => $entry['id']]);
        return Response::json(['entry' => $entry]);
    }

    public function destroy(Request $request, string $id): Response
    {
        if (!$this->app->entries()->delete((int) $id)) {
            throw new HttpException(404, 'Entry not found.');
        }
        Logger::event('entry_deleted', ['id' => (int) $id]);
        return Response::json(['deleted' => true]);
    }

    public function favorite(Request $request, string $id): Response
    {
        $favorite = $request->json()['favorite'] ?? null;
        if (!is_bool($favorite)) {
            throw new HttpException(422, 'favorite must be true or false.');
        }
        $entry = $this->app->entries()->setFavorite((int) $id, $favorite);
        if ($entry === null) {
            throw new HttpException(404, 'Entry not found.');
        }
        return Response::json(['entry' => $entry]);
    }

    public function stats(Request $request): Response
    {
        return Response::json($this->app->entries()->stats());
    }
}
