<?php

declare(strict_types=1);

namespace VaultForge\Controllers;

use VaultForge\App;
use VaultForge\Generator\PassphraseGenerator;
use VaultForge\Generator\PasswordGenerator;
use VaultForge\Http\Request;
use VaultForge\Http\Response;
use VaultForge\Security\Crypto;
use VaultForge\Vault\EntryRepository;

final class PageController
{
    public function __construct(private readonly App $app)
    {
    }

    public function dashboard(Request $request): Response
    {
        return $this->app->page('pages/dashboard', 'Dashboard', 'dashboard', [], ['entry-dialog', 'dashboard']);
    }

    public function generator(Request $request): Response
    {
        return $this->app->page('pages/generator', 'Generator', 'generator', [
            'minLength' => PasswordGenerator::MIN_LENGTH,
            'maxLength' => PasswordGenerator::MAX_LENGTH,
            'ambiguous' => PasswordGenerator::AMBIGUOUS,
            'minWords' => PassphraseGenerator::MIN_WORDS,
            'maxWords' => PassphraseGenerator::MAX_WORDS,
            'wordCount' => count(PassphraseGenerator::wordlist()),
        ], ['entry-dialog', 'generator']);
    }

    public function vault(Request $request): Response
    {
        return $this->app->page('pages/vault', 'Vault', 'vault', [], ['entry-dialog', 'vault']);
    }

    public function backup(Request $request): Response
    {
        return $this->app->page('pages/backup', 'Backup & Restore', 'backup', [
            'entryCount' => (new EntryRepository($this->app->db()))->count(),
            'minBackupLength' => $this->app->config['passwords']['backup_min_length'],
            'maxMb' => (int) floor($this->app->config['backup']['max_bytes'] / 1048576),
        ]);
    }

    public function settings(Request $request): Response
    {
        $dbPath = $this->app->storagePath('vault.sqlite');
        return $this->app->page('pages/settings', 'Settings', 'settings', [
            'autoLockMinutes' => $this->app->settings()->autoLockMinutes(),
            'clipboardSeconds' => $this->app->settings()->clipboardClearSeconds(),
            'autoLock' => $this->app->config['auto_lock'],
            'clipboardMax' => $this->app->config['clipboard']['max_seconds'],
            'idleOverride' => $this->app->config['session']['idle_override_seconds'],
            'kdf' => $this->app->keys()->kdfInfo(),
            'kdfTarget' => $this->app->config['kdf'],
            'cipher' => 'XChaCha20-Poly1305 (IETF)',
            'kdfAlg' => Crypto::KDF_ALG,
            'sodiumVersion' => defined('SODIUM_LIBRARY_VERSION') ? SODIUM_LIBRARY_VERSION : 'unknown',
            'dbPath' => $dbPath,
            'dbSize' => is_file($dbPath) ? (int) filesize($dbPath) : 0,
            'entryCount' => (new EntryRepository($this->app->db()))->count(),
            'minLength' => $this->app->config['passwords']['master_min_length'],
            'phpVersion' => PHP_VERSION,
        ]);
    }
}
