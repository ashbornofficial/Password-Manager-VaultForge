<?php

declare(strict_types=1);

namespace VaultForge\Controllers;

use VaultForge\App;
use VaultForge\Auth\InvalidMasterPasswordException;
use VaultForge\Auth\MasterPasswordGate;
use VaultForge\Auth\ThrottledException;
use VaultForge\Http\Request;
use VaultForge\Http\Response;
use VaultForge\Security\Crypto;
use VaultForge\Support\Logger;
use VaultForge\Vault\EntryRepository;
use VaultForge\Vault\EntryService;

final class SettingsController
{
    public function __construct(private readonly App $app)
    {
    }

    public function preferences(Request $request): Response
    {
        $errors = $this->app->settings()->savePreferences($request->post);
        $session = $this->app->session();
        if ($errors !== []) {
            $session->flash('error', reset($errors));
        } else {
            Logger::event('preferences_saved');
            $session->flash('success', 'Preferences saved.');
        }
        return Response::redirect('/settings');
    }

    /**
     * Change the master password AND rotate the data-encryption key: every entry is
     * re-encrypted under a fresh DEK, which is wrapped with a key derived from the new
     * password and a fresh salt — all in one transaction.
     */
    public function changeMasterPassword(Request $request): Response
    {
        $session = $this->app->session();
        $current = $request->input('current_password');
        $new = $request->input('new_password');
        $confirm = $request->input('new_password_confirm');

        $error = $this->app->policy()->checkMaster($new, $confirm);
        if ($error === null && hash_equals($current, $new)) {
            $error = 'The new master password must be different from the current one.';
        }
        if ($error !== null) {
            $session->flash('error', $error);
            return Response::redirect('/settings');
        }

        try {
            $oldDek = (new MasterPasswordGate($this->app->keys(), $this->app->limiter()))->verify($current, 'change_master');
        } catch (ThrottledException | InvalidMasterPasswordException $e) {
            $session->flash('error', $e instanceof InvalidMasterPasswordException
                ? str_replace('Incorrect master password.', 'The current master password is incorrect.', $e->getMessage())
                : $e->getMessage());
            return Response::redirect('/settings');
        }

        $db = $this->app->db();
        $newDek = Crypto::newKey();
        $db->beginTransaction();
        try {
            $count = (new EntryService(new EntryRepository($db), $oldDek))->reencryptAll($newDek);
            $this->app->keys()->rewrap($new, $newDek);
            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            Logger::event('master_password_change_failed', ['class' => get_class($e)]);
            $session->flash('error', $e instanceof \RuntimeException && str_starts_with($e->getMessage(), 'Entry #')
                ? $e->getMessage()
                : 'The master password could not be changed. Nothing was modified.');
            return Response::redirect('/settings');
        } finally {
            sodium_memzero($oldDek);
        }

        $session->unlock($newDek);
        sodium_memzero($newDek);
        Logger::event('master_password_changed', ['entries_reencrypted' => $count]);
        $session->flash('success', "Master password changed. {$count} entries were re-encrypted with a new key.");
        return Response::redirect('/settings');
    }
}
