<?php

declare(strict_types=1);

namespace VaultForge\Controllers;

use VaultForge\App;
use VaultForge\Auth\InvalidMasterPasswordException;
use VaultForge\Auth\MasterPasswordGate;
use VaultForge\Auth\ThrottledException;
use VaultForge\Http\Request;
use VaultForge\Http\Response;
use VaultForge\Support\Logger;

final class AuthController
{
    public function __construct(private readonly App $app)
    {
    }

    public function showSetup(Request $request): Response
    {
        return $this->renderSetup(null);
    }

    public function setup(Request $request): Response
    {
        $password = $request->input('master_password');
        $confirm = $request->input('master_password_confirm');
        $error = $this->app->policy()->checkMaster($password, $confirm);
        if ($error === null && $request->input('acknowledge') !== '1') {
            $error = 'Please confirm that you understand a forgotten master password cannot be recovered.';
        }
        if ($error !== null) {
            return $this->renderSetup($error, 422);
        }

        try {
            $dek = $this->app->keys()->initialize($password);
        } catch (\LogicException) {
            return Response::redirect('/unlock');
        }
        $this->app->session()->unlock($dek);
        sodium_memzero($dek);
        $this->app->limiter()->reset();
        Logger::event('vault_created');
        $this->app->session()->flash('success', 'Your vault is ready. Store your master password somewhere safe — it cannot be recovered.');
        return Response::redirect('/');
    }

    public function showUnlock(Request $request): Response
    {
        $retry = $this->app->limiter()->retryAfter();
        return $this->renderUnlock($retry > 0 ? "Too many failed attempts. Try again in {$retry} seconds." : null, $retry);
    }

    public function unlock(Request $request): Response
    {
        $gate = new MasterPasswordGate($this->app->keys(), $this->app->limiter());
        try {
            $dek = $gate->verify($request->input('master_password'), 'unlock');
        } catch (ThrottledException $e) {
            return $this->renderUnlock($e->getMessage(), $e->retryAfter, 429);
        } catch (InvalidMasterPasswordException $e) {
            return $this->renderUnlock($e->getMessage(), $this->app->limiter()->retryAfter(), 401);
        }
        $this->app->session()->unlock($dek);
        sodium_memzero($dek);
        Logger::event('unlock_success');
        return Response::redirect('/');
    }

    public function lock(Request $request): Response
    {
        $session = $this->app->session();
        $wasUnlocked = $session->isUnlocked();
        $session->lock();
        if ($wasUnlocked) {
            $idle = $request->input('reason') === 'idle';
            Logger::event($idle ? 'auto_lock_client' : 'manual_lock');
            $session->flash('info', $idle ? 'VaultForge locked automatically after a period of inactivity.' : 'Vault locked.');
        }
        return Response::redirect($this->app->keys()->isInitialized() ? '/unlock' : '/setup');
    }

    private function renderSetup(?string $error, int $status = 200): Response
    {
        $p = $this->app->config['passwords'];
        return $this->app->authPage('setup', 'Create your vault', [
            'error' => $error,
            'minLength' => $p['master_min_length'],
        ], $status);
    }

    private function renderUnlock(?string $error, int $retryAfter, int $status = 200): Response
    {
        return $this->app->authPage('unlock', 'Unlock', [
            'error' => $error,
            'retryAfter' => $retryAfter,
        ], $status);
    }
}
