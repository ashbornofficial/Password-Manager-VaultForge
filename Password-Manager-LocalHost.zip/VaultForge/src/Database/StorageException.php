<?php

declare(strict_types=1);

namespace VaultForge\Database;

/** A storage problem with a message that is safe and useful to show the user. */
final class StorageException extends \RuntimeException
{
    public function __construct(public readonly string $kind, string $message, ?\Throwable $previous = null)
    {
        parent::__construct($message, 0, $previous);
    }
}
