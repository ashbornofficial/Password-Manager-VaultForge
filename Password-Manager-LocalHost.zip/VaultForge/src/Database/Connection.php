<?php

declare(strict_types=1);

namespace VaultForge\Database;

use PDO;
use PDOException;

final class Connection
{
    private const SQLITE_HEADER = "SQLite format 3\0";

    /**
     * Open (or create) the SQLite database, refusing files that are not SQLite databases
     * instead of overwriting them.
     */
    public static function open(string $path): PDO
    {
        if (!extension_loaded('pdo_sqlite')) {
            throw new StorageException('extension', 'The pdo_sqlite PHP extension is not loaded. Run bin/check.php for details.');
        }
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new StorageException('storage_missing', 'The storage directory does not exist and could not be created: ' . $dir);
        }
        if (!is_writable($dir)) {
            throw new StorageException('storage_readonly', 'The storage directory is not writable. Check folder permissions: ' . $dir);
        }

        if (file_exists($path)) {
            if (!is_file($path) || !is_readable($path) || !is_writable($path)) {
                throw new StorageException('db_inaccessible', 'The vault database exists but cannot be read or written. Check file permissions or whether another program has locked it.');
            }
            if (filesize($path) > 0) {
                $handle = @fopen($path, 'rb');
                $header = $handle ? (string) fread($handle, 16) : '';
                if ($handle) {
                    fclose($handle);
                }
                if ($header !== self::SQLITE_HEADER) {
                    throw new StorageException('db_corrupt', 'The vault database file is not a valid SQLite database (it may be corrupted). It has NOT been modified. Restore storage/vault.sqlite from a copy, or move it aside and restore an encrypted backup.');
                }
            }
        }

        try {
            $pdo = new PDO('sqlite:' . $path, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT => 5,
            ]);
            $pdo->exec('PRAGMA foreign_keys = ON');
            $pdo->exec('PRAGMA busy_timeout = 5000');
            $pdo->exec('PRAGMA journal_mode = DELETE');
            $pdo->exec('PRAGMA synchronous = FULL');
            // Overwrite deleted content with zeros (old ciphertexts, old wrapped keys).
            $pdo->exec('PRAGMA secure_delete = ON');
        } catch (PDOException $e) {
            throw new StorageException('db_open', 'The vault database could not be opened. It may be corrupted or locked by another program.', $e);
        }
        return $pdo;
    }

    public static function integrityOk(PDO $pdo): bool
    {
        try {
            $result = $pdo->query('PRAGMA quick_check')->fetchColumn();
            return $result === 'ok';
        } catch (PDOException) {
            return false;
        }
    }

    /** Consistent copy of the whole database file (used before destructive restores). */
    public static function snapshot(PDO $pdo, string $target): void
    {
        $dir = dirname($target);
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new StorageException('snapshot', 'Could not create the backup snapshot directory.');
        }
        $pdo->exec('VACUUM INTO ' . $pdo->quote($target));
    }
}
