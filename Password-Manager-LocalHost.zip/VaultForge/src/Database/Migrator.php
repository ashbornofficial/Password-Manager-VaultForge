<?php

declare(strict_types=1);

namespace VaultForge\Database;

use PDO;

/**
 * Forward-only schema migrations. Each file in src/Database/migrations is named
 * NNN_description.php and returns ['name' => string, 'statements' => list<string>].
 * Every migration runs in its own transaction (SQLite DDL is transactional) and is
 * recorded in schema_migrations. Never edit a migration that has shipped; add a new one.
 */
final class Migrator
{
    public function __construct(private readonly PDO $db, private readonly string $directory)
    {
    }

    /** @return list<int> versions applied by this call */
    public function migrate(): array
    {
        $this->db->exec('CREATE TABLE IF NOT EXISTS schema_migrations (
            version INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            applied_at TEXT NOT NULL
        )');

        $applied = array_map('intval', $this->db->query('SELECT version FROM schema_migrations')->fetchAll(PDO::FETCH_COLUMN));
        $available = $this->available();
        $latest = $available === [] ? 0 : max(array_keys($available));

        if ($applied !== [] && max($applied) > $latest) {
            throw new StorageException('db_newer', 'This vault was created by a newer version of VaultForge. Update the application before opening it.');
        }

        $ran = [];
        foreach ($available as $version => $migration) {
            if (in_array($version, $applied, true)) {
                continue;
            }
            $this->db->beginTransaction();
            try {
                foreach ($migration['statements'] as $sql) {
                    $this->db->exec($sql);
                }
                $stmt = $this->db->prepare('INSERT INTO schema_migrations (version, name, applied_at) VALUES (:v, :n, :t)');
                $stmt->execute([':v' => $version, ':n' => $migration['name'], ':t' => gmdate('Y-m-d\TH:i:s\Z')]);
                $this->db->commit();
            } catch (\Throwable $e) {
                $this->db->rollBack();
                throw new StorageException('migration', 'A database migration failed; no changes were applied.', $e);
            }
            $ran[] = $version;
        }
        return $ran;
    }

    public function currentVersion(): int
    {
        return (int) $this->db->query('SELECT COALESCE(MAX(version), 0) FROM schema_migrations')->fetchColumn();
    }

    /** @return array<int, array{name: string, statements: list<string>}> */
    private function available(): array
    {
        $migrations = [];
        foreach (glob($this->directory . '/*.php') ?: [] as $file) {
            if (!preg_match('/^(\d{3})_[a-z0-9_]+\.php$/', basename($file), $m)) {
                continue;
            }
            $migrations[(int) $m[1]] = require $file;
        }
        ksort($migrations);
        return $migrations;
    }
}
