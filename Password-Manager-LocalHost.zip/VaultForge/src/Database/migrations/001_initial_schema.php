<?php

declare(strict_types=1);

/*
 * Initial schema.
 *
 * Plaintext columns are limited to: row ids, random entry uids, the favorite flag,
 * timestamps, KDF parameters/salt and app settings. Entry name, URL, username,
 * category, password and notes are stored only as authenticated ciphertext.
 *
 * The CHECK constraints are a last line of defence: a secret column only accepts a
 * BLOB that starts with the "VF1" ciphertext magic (0x564631) and is at least
 * 3 + 24 (nonce) + 16 (tag) bytes long, so an accidental plaintext TEXT insert fails.
 */

$ciphertext = static fn (string $col): string =>
    "$col BLOB NOT NULL CHECK (typeof($col) = 'blob' AND length($col) >= 43 AND substr($col, 1, 3) = X'564631')";

return [
    'name' => 'initial_schema',
    'statements' => [
        "CREATE TABLE vault_meta (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            format_version INTEGER NOT NULL,
            kdf_alg TEXT NOT NULL,
            kdf_opslimit INTEGER NOT NULL,
            kdf_memlimit INTEGER NOT NULL,
            kdf_salt BLOB NOT NULL CHECK (typeof(kdf_salt) = 'blob' AND length(kdf_salt) = 16),
            " . $ciphertext('wrapped_dek') . ",
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )",
        "CREATE TABLE entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uid TEXT NOT NULL UNIQUE CHECK (length(uid) = 32),
            " . $ciphertext('meta_ct') . ",
            " . $ciphertext('password_ct') . ",
            " . $ciphertext('notes_ct') . ",
            favorite INTEGER NOT NULL DEFAULT 0 CHECK (favorite IN (0, 1)),
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )",
        'CREATE INDEX idx_entries_updated ON entries (updated_at)',
        'CREATE TABLE settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )',
        'CREATE TABLE login_throttle (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            failed_count INTEGER NOT NULL DEFAULT 0,
            locked_until INTEGER NOT NULL DEFAULT 0,
            last_failed_at INTEGER NOT NULL DEFAULT 0
        )',
        'INSERT INTO login_throttle (id, failed_count, locked_until, last_failed_at) VALUES (1, 0, 0, 0)',
    ],
];
