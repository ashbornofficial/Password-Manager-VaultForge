<?php

declare(strict_types=1);

namespace VaultForge\Http;

final class HttpException extends \RuntimeException
{
    /** @param array<string, mixed> $extra additional JSON fields for API responses */
    public function __construct(public readonly int $status, string $message, public readonly array $extra = [])
    {
        parent::__construct($message);
    }
}
