<?php

declare(strict_types=1);

namespace VaultForge\Http;

final class Request
{
    public const MAX_JSON_BYTES = 1048576;

    private ?array $json = null;

    /**
     * @param array<string, mixed> $query
     * @param array<string, mixed> $post
     * @param array<string, mixed> $files
     * @param array<string, mixed> $server
     */
    public function __construct(
        public readonly string $method,
        public readonly string $path,
        public readonly array $query,
        public readonly array $post,
        public readonly array $files,
        public readonly array $server,
        private readonly ?string $rawBody = null,
    ) {
    }

    public static function fromGlobals(): self
    {
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
        $path = parse_url($uri, PHP_URL_PATH);
        $path = is_string($path) && $path !== '' ? rawurldecode($path) : '/';
        if (str_contains($path, "\0") || !preg_match('//u', $path)) {
            $path = '/__invalid__';
        }
        if ($path !== '/') {
            $path = rtrim($path, '/');
            $path = $path === '' ? '/' : $path;
        }
        return new self(
            strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')),
            $path,
            $_GET,
            $_POST,
            $_FILES,
            $_SERVER,
        );
    }

    public function header(string $name): ?string
    {
        $key = strtoupper(str_replace('-', '_', $name));
        $value = $this->server[in_array($key, ['CONTENT_TYPE', 'CONTENT_LENGTH'], true) ? $key : 'HTTP_' . $key] ?? null;
        return is_string($value) ? $value : null;
    }

    public function isApi(): bool
    {
        return str_starts_with($this->path, '/api/');
    }

    public function isUnsafeMethod(): bool
    {
        return !in_array($this->method, ['GET', 'HEAD', 'OPTIONS'], true);
    }

    /** String form field (empty string if missing or not a string). */
    public function input(string $key): string
    {
        $value = $this->post[$key] ?? '';
        return is_string($value) ? $value : '';
    }

    public function queryString(string $key): string
    {
        $value = $this->query[$key] ?? '';
        return is_string($value) ? $value : '';
    }

    /** Decoded JSON request body (an object). */
    public function json(): array
    {
        if ($this->json !== null) {
            return $this->json;
        }
        $length = (int) ($this->header('Content-Length') ?? 0);
        if ($length > self::MAX_JSON_BYTES) {
            throw new HttpException(413, 'Request body too large.');
        }
        $raw = $this->rawBody ?? (string) file_get_contents('php://input', false, null, 0, self::MAX_JSON_BYTES + 1);
        if (strlen($raw) > self::MAX_JSON_BYTES) {
            throw new HttpException(413, 'Request body too large.');
        }
        if (trim($raw) === '') {
            return $this->json = [];
        }
        try {
            $data = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new HttpException(400, 'Malformed JSON body.');
        }
        if (!is_array($data) || array_is_list($data) && $data !== []) {
            throw new HttpException(400, 'JSON body must be an object.');
        }
        return $this->json = $data;
    }
}
