<?php

declare(strict_types=1);

namespace VaultForge\Http;

final class View
{
    /** @param array<string, mixed> $shared variables available to every template */
    public function __construct(private readonly string $directory, private array $shared = [])
    {
    }

    public function share(string $key, mixed $value): void
    {
        $this->shared[$key] = $value;
    }

    /** @param array<string, mixed> $data */
    public function render(string $template, array $data = []): string
    {
        if (!preg_match('#^[a-z0-9/_-]+$#', $template)) {
            throw new \InvalidArgumentException('Invalid template name.');
        }
        $file = $this->directory . '/' . $template . '.php';
        if (!is_file($file)) {
            throw new \RuntimeException('Template not found: ' . $template);
        }
        $vars = $data + $this->shared + ['view' => $this];
        return (static function (string $__file, array $__vars): string {
            extract($__vars, EXTR_SKIP);
            ob_start();
            try {
                require $__file;
                return (string) ob_get_clean();
            } catch (\Throwable $e) {
                ob_end_clean();
                throw $e;
            }
        })($file, $vars);
    }
}
