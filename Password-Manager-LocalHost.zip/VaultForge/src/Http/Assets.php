<?php

declare(strict_types=1);

namespace VaultForge\Http;

/**
 * Serves files from public/assets only, with a fixed extension whitelist.
 * The PHP built-in server is started with public/index.php as router, so it never
 * serves files by itself; everything goes through here or through the app.
 */
final class Assets
{
    private const TYPES = [
        'css' => 'text/css; charset=utf-8',
        'js' => 'text/javascript; charset=utf-8',
        'svg' => 'image/svg+xml',
        'png' => 'image/png',
        'ico' => 'image/x-icon',
        'woff2' => 'font/woff2',
    ];

    public static function serve(Request $request, string $publicDir): Response
    {
        if (!in_array($request->method, ['GET', 'HEAD'], true)) {
            throw new HttpException(405, 'Method not allowed.');
        }
        $base = realpath($publicDir . DIRECTORY_SEPARATOR . 'assets');
        $target = realpath($publicDir . str_replace('/', DIRECTORY_SEPARATOR, $request->path));
        if ($base === false || $target === false || !is_file($target)) {
            throw new HttpException(404, 'Not found.');
        }
        $normalize = static fn (string $p): string => strtolower(str_replace('\\', '/', $p));
        if (!str_starts_with($normalize($target), $normalize($base) . '/')) {
            throw new HttpException(404, 'Not found.');
        }
        $ext = strtolower(pathinfo($target, PATHINFO_EXTENSION));
        if (!isset(self::TYPES[$ext])) {
            throw new HttpException(404, 'Not found.');
        }
        $body = $request->method === 'HEAD' ? '' : (string) file_get_contents($target);
        return new Response(200, ['Content-Type' => self::TYPES[$ext], 'Cache-Control' => 'no-cache'], $body);
    }
}
