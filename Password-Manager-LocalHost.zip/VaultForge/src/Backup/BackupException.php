<?php

declare(strict_types=1);

namespace VaultForge\Backup;

/** Backup problem with a user-facing message. */
final class BackupException extends \RuntimeException
{
}
