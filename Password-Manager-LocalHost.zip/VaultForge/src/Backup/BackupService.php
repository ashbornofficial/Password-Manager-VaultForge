<?php

declare(strict_types=1);

namespace VaultForge\Backup;

use VaultForge\Security\Crypto;
use VaultForge\Security\DecryptionException;
use VaultForge\Support\Clock;
use VaultForge\Vault\EntryService;
use VaultForge\Vault\EntryValidator;
use VaultForge\Vault\ValidationException;

/**
 * Encrypted backup files (.vfbackup).
 *
 * The file is JSON: a plaintext header (format, version, timestamps, entry count, cipher,
 * Argon2id parameters + salt) and a base64 XChaCha20-Poly1305 ciphertext of the entries.
 * The key comes from a separate backup password. The complete header is bound into the
 * associated data, so changing any header field (or the ciphertext) makes decryption fail.
 */
final class BackupService
{
    public const FORMAT = 'vaultforge-backup';
    public const VERSION = 1;
    public const CIPHER = 'xchacha20poly1305-ietf';
    private const TOP_KEYS = ['format', 'version', 'created_at', 'entry_count', 'cipher', 'kdf', 'ciphertext'];
    private const KDF_KEYS = ['alg', 'opslimit', 'memlimit', 'salt'];
    private const ENTRY_KEYS = ['name', 'url', 'username', 'password', 'notes', 'category', 'favorite', 'created_at', 'updated_at'];

    public function __construct(
        private readonly int $opslimit,
        private readonly int $memlimit,
        private readonly int $maxBytes,
    ) {
    }

    /** @param list<array<string, mixed>> $entries fully decrypted entries */
    public function create(array $entries, #[\SensitiveParameter] string $password): string
    {
        $salt = Crypto::newSalt();
        $header = self::header(Clock::now(), count($entries), $this->opslimit, $this->memlimit, $salt);
        $key = Crypto::deriveKey($password, $salt, $this->opslimit, $this->memlimit);
        $payload = json_encode(['entries' => $entries], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        try {
            $blob = Crypto::encrypt($payload, $key, self::context($header));
        } finally {
            sodium_memzero($key);
            sodium_memzero($payload);
        }
        $document = $header + ['ciphertext' => base64_encode($blob)];
        return json_encode($document, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n";
    }

    /**
     * Validate the file structure without decrypting it.
     * @return array{header: array<string, mixed>, blob: string}
     */
    public function parse(string $raw): array
    {
        if ($raw === '') {
            throw new BackupException('The backup file is empty.');
        }
        if (strlen($raw) > $this->maxBytes) {
            throw new BackupException('The backup file is too large.');
        }
        try {
            $doc = json_decode($raw, true, 8, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new BackupException('This is not a VaultForge backup file (invalid JSON).');
        }
        if (!is_array($doc) || ($doc['format'] ?? null) !== self::FORMAT) {
            throw new BackupException('This is not a VaultForge backup file.');
        }
        if (($doc['version'] ?? null) !== self::VERSION) {
            throw new BackupException('Unsupported backup version. Update VaultForge to restore this file.');
        }
        if (!self::hasExactKeys($doc, self::TOP_KEYS)) {
            throw new BackupException('The backup file has an unexpected structure.');
        }
        if (!is_string($doc['created_at']) || !Clock::isValid($doc['created_at'])
            || !is_int($doc['entry_count']) || $doc['entry_count'] < 0 || $doc['entry_count'] > EntryService::MAX_ENTRIES
            || $doc['cipher'] !== self::CIPHER) {
            throw new BackupException('The backup header is invalid.');
        }
        $kdf = $doc['kdf'];
        if (!is_array($kdf) || !self::hasExactKeys($kdf, self::KDF_KEYS) || $kdf['alg'] !== Crypto::KDF_ALG
            || !is_int($kdf['opslimit']) || !is_int($kdf['memlimit'])
            || !Crypto::kdfParamsValid($kdf['opslimit'], $kdf['memlimit']) || !is_string($kdf['salt'])) {
            throw new BackupException('The backup key-derivation parameters are invalid or outside safe limits.');
        }
        $salt = base64_decode($kdf['salt'], true);
        if ($salt === false || strlen($salt) !== Crypto::SALT_BYTES) {
            throw new BackupException('The backup salt is invalid.');
        }
        $blob = is_string($doc['ciphertext']) ? base64_decode($doc['ciphertext'], true) : false;
        if ($blob === false || strlen($blob) < Crypto::MIN_BLOB) {
            throw new BackupException('The backup ciphertext is missing or damaged.');
        }
        return [
            'header' => self::header($doc['created_at'], $doc['entry_count'], $kdf['opslimit'], $kdf['memlimit'], $salt),
            'salt' => $salt,
            'blob' => $blob,
        ];
    }

    /**
     * Decrypt and fully validate a parsed backup.
     * @return list<array<string, mixed>> validated entries (with timestamps)
     */
    public function decrypt(array $parsed, #[\SensitiveParameter] string $password): array
    {
        $header = $parsed['header'];
        if ($password === '' || strlen($password) > 1024) {
            throw new BackupException('Enter the backup password that was used when the backup was created.');
        }
        $key = Crypto::deriveKey($password, $parsed['salt'], $header['kdf']['opslimit'], $header['kdf']['memlimit']);
        try {
            $payload = Crypto::decrypt($parsed['blob'], $key, self::context($header));
        } catch (DecryptionException) {
            throw new BackupException('Wrong backup password, or the file has been modified or corrupted. Nothing was restored.');
        } finally {
            sodium_memzero($key);
        }

        try {
            $data = json_decode($payload, true, 8, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new BackupException('The decrypted backup content is invalid.');
        } finally {
            sodium_memzero($payload);
        }
        if (!is_array($data) || !self::hasExactKeys($data, ['entries']) || !is_array($data['entries']) || !array_is_list($data['entries'])) {
            throw new BackupException('The decrypted backup content has an unexpected structure.');
        }
        if (count($data['entries']) !== $header['entry_count']) {
            throw new BackupException('The backup entry count does not match its header.');
        }
        $entries = [];
        foreach ($data['entries'] as $i => $entry) {
            if (!is_array($entry) || !self::hasExactKeys($entry, self::ENTRY_KEYS)) {
                throw new BackupException('Backup entry #' . ($i + 1) . ' has an unexpected structure.');
            }
            try {
                $entries[] = EntryValidator::validate($entry, true);
            } catch (ValidationException $e) {
                throw new BackupException('Backup entry #' . ($i + 1) . ' is invalid (' . implode(', ', array_keys($e->errors)) . ').');
            }
        }
        return $entries;
    }

    private static function header(string $createdAt, int $count, int $ops, int $mem, string $salt): array
    {
        return [
            'format' => self::FORMAT,
            'version' => self::VERSION,
            'created_at' => $createdAt,
            'entry_count' => $count,
            'cipher' => self::CIPHER,
            'kdf' => ['alg' => Crypto::KDF_ALG, 'opslimit' => $ops, 'memlimit' => $mem, 'salt' => base64_encode($salt)],
        ];
    }

    private static function context(array $header): string
    {
        return 'backup:v1:' . json_encode($header, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    }

    private static function hasExactKeys(array $data, array $keys): bool
    {
        $actual = array_keys($data);
        sort($actual);
        sort($keys);
        return $actual === $keys;
    }
}
