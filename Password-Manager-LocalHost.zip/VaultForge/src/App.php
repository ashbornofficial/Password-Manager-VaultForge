<?php

declare(strict_types=1);

namespace VaultForge;

use PDO;
use Throwable;
use VaultForge\Auth\PasswordPolicy;
use VaultForge\Auth\VaultKeyService;
use VaultForge\Backup\BackupService;
use VaultForge\Controllers\AuthController;
use VaultForge\Controllers\BackupController;
use VaultForge\Controllers\EntryApiController;
use VaultForge\Controllers\GeneratorApiController;
use VaultForge\Controllers\PageController;
use VaultForge\Controllers\SettingsController;
use VaultForge\Database\Connection;
use VaultForge\Database\Migrator;
use VaultForge\Database\StorageException;
use VaultForge\Http\Assets;
use VaultForge\Http\HttpException;
use VaultForge\Http\Request;
use VaultForge\Http\Response;
use VaultForge\Http\View;
use VaultForge\Security\Csrf;
use VaultForge\Security\HostGuard;
use VaultForge\Security\RateLimiter;
use VaultForge\Security\SecurityHeaders;
use VaultForge\Security\SessionManager;
use VaultForge\Settings\SettingsRepository;
use VaultForge\Support\Logger;
use VaultForge\Vault\EntryRepository;
use VaultForge\Vault\EntryService;

final class App
{
    private ?PDO $db = null;
    private ?SessionManager $session = null;
    private ?View $view = null;
    private ?VaultKeyService $keys = null;
    private ?SettingsRepository $settings = null;
    private ?RateLimiter $limiter = null;

    public function __construct(public readonly array $config)
    {
        Logger::configure($this->storagePath('logs'));
    }

    public static function create(): self
    {
        return new self(require VF_ROOT . '/config/config.php');
    }

    public function run(): void
    {
        $request = Request::fromGlobals();
        $response = $this->handle($request);
        SecurityHeaders::apply($response);
        $response->send();
    }

    public function handle(Request $request): Response
    {
        try {
            HostGuard::assertLocal($request, $this->config['allowed_hosts']);
            if (str_starts_with($request->path, '/assets/')) {
                return Assets::serve($request, VF_ROOT . DIRECTORY_SEPARATOR . 'public');
            }
            $this->boot();
            $this->enforceAutoLock();
            $rejected = $this->checkRequestIntegrity($request);
            return $rejected ?? $this->route($request);
        } catch (HttpException $e) {
            return $this->error($request, $e->status, $e->getMessage(), $e->extra);
        } catch (StorageException $e) {
            Logger::event('storage_error', ['kind' => $e->kind, 'previous' => $e->getPrevious() ? get_class($e->getPrevious()) : null]);
            return $this->error($request, 503, $e->getMessage());
        } catch (Throwable $e) {
            Logger::event('unhandled_exception', [
                'class' => get_class($e),
                'message' => $e->getMessage(),
                'at' => basename($e->getFile()) . ':' . $e->getLine(),
            ]);
            return $this->error($request, 500, 'An unexpected error occurred. A short diagnostic (without secrets) was written to storage/logs/app.log.');
        }
    }

    // ---------------------------------------------------------------- services

    public function db(): PDO
    {
        return $this->db ??= Connection::open($this->storagePath('vault.sqlite'));
    }

    public function session(): SessionManager
    {
        return $this->session ??= new SessionManager(
            $this->storagePath('sessions'),
            $this->isHttps(),
            (int) $this->config['session']['absolute_lifetime']
        );
    }

    public function view(): View
    {
        return $this->view ??= new View(VF_ROOT . '/templates', [
            'appName' => $this->config['app_name'],
            'appVersion' => $this->config['version'],
        ]);
    }

    public function keys(): VaultKeyService
    {
        return $this->keys ??= new VaultKeyService($this->db(), $this->config['kdf']['opslimit'], $this->config['kdf']['memlimit']);
    }

    public function settings(): SettingsRepository
    {
        return $this->settings ??= new SettingsRepository($this->db(), $this->config);
    }

    public function limiter(): RateLimiter
    {
        $l = $this->config['login'];
        return $this->limiter ??= new RateLimiter($this->db(), $l['max_attempts'], $l['base_lockout'], $l['max_lockout']);
    }

    public function policy(): PasswordPolicy
    {
        $p = $this->config['passwords'];
        return new PasswordPolicy($p['master_min_length'], $p['master_min_bits'], $p['backup_min_length']);
    }

    public function backups(): BackupService
    {
        return new BackupService($this->config['kdf']['opslimit'], $this->config['kdf']['memlimit'], $this->config['backup']['max_bytes']);
    }

    /** Entry service bound to the current session's DEK. Only valid on "unlocked" routes. */
    public function entries(): EntryService
    {
        $dek = $this->session()->dek();
        if ($dek === null) {
            throw new HttpException(401, 'The vault is locked.', ['locked' => true]);
        }
        return new EntryService(new EntryRepository($this->db()), $dek);
    }

    public function storagePath(string $child = ''): string
    {
        $base = rtrim($this->config['storage_path'], '/\\');
        return $child === '' ? $base : $base . DIRECTORY_SEPARATOR . $child;
    }

    public function idleSeconds(): int
    {
        return $this->config['session']['idle_override_seconds'] ?? $this->settings()->autoLockMinutes() * 60;
    }

    // ---------------------------------------------------------------- rendering

    /** Render an app page inside the main layout. */
    public function page(string $template, string $title, string $active, array $data = [], array $scripts = []): Response
    {
        $this->view()->share('csrf', $this->session()->csrfToken());
        $content = $this->view()->render($template, $data);
        return Response::html($this->view()->render('layout', [
            'title' => $title,
            'active' => $active,
            'content' => $content,
            'scripts' => $scripts,
            'csrf' => $this->session()->csrfToken(),
            'flash' => $this->session()->pullFlash(),
            'idleSeconds' => $this->idleSeconds(),
            'clipboardSeconds' => $this->settings()->clipboardClearSeconds(),
        ]));
    }

    /** Render a page in the minimal (logged-out) layout. */
    public function authPage(string $template, string $title, array $data = [], int $status = 200): Response
    {
        $this->view()->share('csrf', $this->session?->csrfToken() ?? '');
        $content = $this->view()->render($template, $data);
        return Response::html($this->view()->render('auth-layout', [
            'title' => $title,
            'content' => $content,
            'csrf' => $this->session?->csrfToken() ?? '',
            'flash' => $this->session ? $this->session->pullFlash() : [],
        ]), $status);
    }

    public function error(Request $request, int $status, string $message, array $extra = []): Response
    {
        if ($request->isApi()) {
            return Response::json(['error' => $message] + $extra, $status);
        }
        try {
            return $this->authPage('error', 'Error', ['status' => $status, 'message' => $message], $status);
        } catch (Throwable) {
            return Response::html('<!doctype html><title>Error</title><p>' . e($message) . '</p>', $status);
        }
    }

    // ---------------------------------------------------------------- pipeline

    private function boot(): void
    {
        (new Migrator($this->db(), VF_ROOT . '/src/Database/migrations'))->migrate();
        $this->session()->start();
    }

    private function enforceAutoLock(): void
    {
        $session = $this->session();
        if (!$session->isUnlocked()) {
            return;
        }
        if ($session->isExpired($this->idleSeconds())) {
            $session->lock();
            $session->flash('info', 'VaultForge locked automatically after a period of inactivity.');
            Logger::event('auto_lock');
            return;
        }
        $session->touch();
    }

    /** CSRF token + Origin / Fetch-Metadata checks for state-changing and API requests. */
    private function checkRequestIntegrity(Request $request): ?Response
    {
        if (!$request->isUnsafeMethod() && !$request->isApi()) {
            return null;
        }
        $site = $request->header('Sec-Fetch-Site');
        if ($site !== null && !in_array($site, ['same-origin', 'none'], true)) {
            Logger::event('blocked_cross_site', ['sec_fetch_site' => $site, 'path' => $request->path]);
            return $this->error($request, 403, 'Cross-site request blocked.');
        }
        $origin = $request->header('Origin');
        if ($origin !== null && !in_array(strtolower($origin), HostGuard::allowedOrigins($this->config['allowed_hosts']), true)) {
            Logger::event('blocked_origin', ['path' => $request->path]);
            return $this->error($request, 403, 'Request origin not allowed.');
        }

        $length = (int) ($request->header('Content-Length') ?? 0);
        if (!$request->isApi() && $request->post === [] && $length > $this->iniBytes((string) ini_get('post_max_size'))) {
            return $this->formError($request, 'The upload is too large.');
        }

        $token = $request->isApi() ? $request->header('X-CSRF-Token') : ($request->post['_csrf'] ?? null);
        if (!Csrf::valid($this->session(), $token)) {
            if ($request->isApi() && !$this->session()->isUnlocked()) {
                // Typical after an auto-lock: the page's token was rotated. Report the real state.
                return $this->keys()->isInitialized()
                    ? Response::json(['error' => 'The vault is locked.', 'locked' => true], 401)
                    : Response::json(['error' => 'The vault has not been set up yet.', 'setup' => true], 409);
            }
            Logger::event('csrf_rejected', ['path' => $request->path]);
            if (!$request->isApi()) {
                return $this->formError($request, 'Your session expired or the form was out of date. Please try again.');
            }
            return $this->error($request, 403, 'Invalid or missing CSRF token. Reload the page.');
        }
        return null;
    }

    private function formError(Request $request, string $message): Response
    {
        $this->session()->flash('error', $message);
        if (!$this->session()->isUnlocked()) {
            return Response::redirect($this->keys()->isInitialized() ? '/unlock' : '/setup');
        }
        $back = in_array($request->path, ['/backup/export', '/backup/restore'], true) ? '/backup' : (str_starts_with($request->path, '/settings') ? '/settings' : '/');
        return Response::redirect($back);
    }

    private function route(Request $request): Response
    {
        $routes = [
            // method, pattern, handler, access
            ['GET', '/', [PageController::class, 'dashboard'], 'unlocked'],
            ['GET', '/generator', [PageController::class, 'generator'], 'unlocked'],
            ['GET', '/vault', [PageController::class, 'vault'], 'unlocked'],
            ['GET', '/backup', [PageController::class, 'backup'], 'unlocked'],
            ['GET', '/settings', [PageController::class, 'settings'], 'unlocked'],

            ['GET', '/setup', [AuthController::class, 'showSetup'], 'setup'],
            ['POST', '/setup', [AuthController::class, 'setup'], 'setup'],
            ['GET', '/unlock', [AuthController::class, 'showUnlock'], 'locked'],
            ['POST', '/unlock', [AuthController::class, 'unlock'], 'locked'],
            ['POST', '/lock', [AuthController::class, 'lock'], 'any'],

            ['POST', '/settings/preferences', [SettingsController::class, 'preferences'], 'unlocked'],
            ['POST', '/settings/master-password', [SettingsController::class, 'changeMasterPassword'], 'unlocked'],
            ['POST', '/backup/export', [BackupController::class, 'export'], 'unlocked'],
            ['POST', '/backup/restore', [BackupController::class, 'restore'], 'unlocked'],

            ['GET', '/api/entries', [EntryApiController::class, 'index'], 'unlocked'],
            ['POST', '/api/entries', [EntryApiController::class, 'store'], 'unlocked'],
            ['GET', '#^/api/entries/(\d{1,10})$#', [EntryApiController::class, 'show'], 'unlocked'],
            ['PUT', '#^/api/entries/(\d{1,10})$#', [EntryApiController::class, 'update'], 'unlocked'],
            ['DELETE', '#^/api/entries/(\d{1,10})$#', [EntryApiController::class, 'destroy'], 'unlocked'],
            ['GET', '#^/api/entries/(\d{1,10})/secret$#', [EntryApiController::class, 'secret'], 'unlocked'],
            ['POST', '#^/api/entries/(\d{1,10})/favorite$#', [EntryApiController::class, 'favorite'], 'unlocked'],
            ['GET', '/api/stats', [EntryApiController::class, 'stats'], 'unlocked'],
            ['POST', '/api/generate/password', [GeneratorApiController::class, 'password'], 'unlocked'],
            ['POST', '/api/generate/passphrase', [GeneratorApiController::class, 'passphrase'], 'unlocked'],
            ['POST', '/api/ping', [GeneratorApiController::class, 'ping'], 'unlocked'],
        ];

        $allowed = [];
        foreach ($routes as [$method, $pattern, $handler, $access]) {
            $params = [];
            if ($pattern[0] === '#') {
                if (!preg_match($pattern, $request->path, $m)) {
                    continue;
                }
                $params = array_slice($m, 1);
            } elseif ($pattern !== $request->path) {
                continue;
            }
            if ($method !== $request->method) {
                $allowed[] = $method;
                continue;
            }
            $guard = $this->guard($request, $access);
            if ($guard !== null) {
                return $guard;
            }
            [$class, $action] = $handler;
            return (new $class($this))->$action($request, ...$params);
        }
        if ($allowed !== []) {
            $response = $this->error($request, 405, 'Method not allowed.');
            $response->headers['Allow'] = implode(', ', array_unique($allowed));
            return $response;
        }
        throw new HttpException(404, 'Page not found.');
    }

    private function guard(Request $request, string $access): ?Response
    {
        $initialized = $this->keys()->isInitialized();
        $session = $this->session();

        if ($access === 'any') {
            return null;
        }
        if ($access === 'setup') {
            return $initialized ? Response::redirect($session->isUnlocked() ? '/' : '/unlock') : null;
        }
        if (!$initialized) {
            return $request->isApi()
                ? Response::json(['error' => 'The vault has not been set up yet.', 'setup' => true], 409)
                : Response::redirect('/setup');
        }
        if ($access === 'locked') {
            return $session->isUnlocked() && $session->dek() !== null ? Response::redirect('/') : null;
        }
        // unlocked
        if (!$session->isUnlocked() || $session->dek() === null) {
            if ($session->isUnlocked()) {
                $session->lock(); // key cookie missing or invalid: treat as locked
            }
            return $request->isApi()
                ? Response::json(['error' => 'The vault is locked.', 'locked' => true], 401)
                : Response::redirect('/unlock');
        }
        return null;
    }

    private function isHttps(): bool
    {
        return (($_SERVER['HTTPS'] ?? '') !== '' && strtolower((string) $_SERVER['HTTPS']) !== 'off');
    }

    private function iniBytes(string $value): int
    {
        $value = trim($value);
        $number = (int) $value;
        return match (strtolower(substr($value, -1))) {
            'g' => $number * 1024 ** 3,
            'm' => $number * 1024 ** 2,
            'k' => $number * 1024,
            default => $number,
        };
    }
}
