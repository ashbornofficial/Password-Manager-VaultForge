<?php

declare(strict_types=1);

namespace VaultForge\Vault;

final class ValidationException extends \RuntimeException
{
    /** @param array<string, string> $errors field => message */
    public function __construct(public readonly array $errors, string $message = 'Please correct the highlighted fields.')
    {
        parent::__construct($message);
    }
}
