<?php

declare(strict_types=1);

namespace VaultForge\Vault;

use PDO;

/**
 * Raw access to the entries table. Secret columns only ever receive ciphertext
 * produced by EntryService; all values are bound through prepared statements.
 */
final class EntryRepository
{
    private const COLUMNS = 'id, uid, meta_ct, password_ct, notes_ct, favorite, created_at, updated_at';

    public function __construct(private readonly PDO $db)
    {
    }

    public function db(): PDO
    {
        return $this->db;
    }

    /** @return list<array<string, mixed>> */
    public function all(): array
    {
        return $this->db->query('SELECT ' . self::COLUMNS . ' FROM entries ORDER BY id')->fetchAll();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT ' . self::COLUMNS . ' FROM entries WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public function count(): int
    {
        return (int) $this->db->query('SELECT COUNT(*) FROM entries')->fetchColumn();
    }

    public function insert(string $uid, string $meta, string $password, string $notes, bool $favorite, string $createdAt, string $updatedAt): int
    {
        $stmt = $this->db->prepare('INSERT INTO entries (uid, meta_ct, password_ct, notes_ct, favorite, created_at, updated_at)
            VALUES (:uid, :meta, :pw, :notes, :fav, :c, :u)');
        $stmt->bindValue(':uid', $uid);
        $stmt->bindValue(':meta', $meta, PDO::PARAM_LOB);
        $stmt->bindValue(':pw', $password, PDO::PARAM_LOB);
        $stmt->bindValue(':notes', $notes, PDO::PARAM_LOB);
        $stmt->bindValue(':fav', $favorite ? 1 : 0, PDO::PARAM_INT);
        $stmt->bindValue(':c', $createdAt);
        $stmt->bindValue(':u', $updatedAt);
        $stmt->execute();
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, string $meta, string $password, string $notes, bool $favorite, string $updatedAt): bool
    {
        $stmt = $this->db->prepare('UPDATE entries SET meta_ct = :meta, password_ct = :pw, notes_ct = :notes,
            favorite = :fav, updated_at = :u WHERE id = :id');
        $stmt->bindValue(':meta', $meta, PDO::PARAM_LOB);
        $stmt->bindValue(':pw', $password, PDO::PARAM_LOB);
        $stmt->bindValue(':notes', $notes, PDO::PARAM_LOB);
        $stmt->bindValue(':fav', $favorite ? 1 : 0, PDO::PARAM_INT);
        $stmt->bindValue(':u', $updatedAt);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->rowCount() === 1;
    }

    /** Replace ciphertexts only (key rotation); timestamps are preserved. */
    public function replaceCiphertexts(int $id, string $meta, string $password, string $notes): void
    {
        $stmt = $this->db->prepare('UPDATE entries SET meta_ct = :meta, password_ct = :pw, notes_ct = :notes WHERE id = :id');
        $stmt->bindValue(':meta', $meta, PDO::PARAM_LOB);
        $stmt->bindValue(':pw', $password, PDO::PARAM_LOB);
        $stmt->bindValue(':notes', $notes, PDO::PARAM_LOB);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
    }

    public function setFavorite(int $id, bool $favorite): bool
    {
        $stmt = $this->db->prepare('UPDATE entries SET favorite = :fav WHERE id = :id');
        $stmt->execute([':fav' => $favorite ? 1 : 0, ':id' => $id]);
        return $stmt->rowCount() === 1;
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare('DELETE FROM entries WHERE id = :id');
        $stmt->execute([':id' => $id]);
        return $stmt->rowCount() === 1;
    }

    public function deleteAll(): int
    {
        return (int) $this->db->exec('DELETE FROM entries');
    }
}
