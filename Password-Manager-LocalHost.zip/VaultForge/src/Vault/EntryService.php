<?php

declare(strict_types=1);

namespace VaultForge\Vault;

use VaultForge\Generator\StrengthEstimator;
use VaultForge\Security\Crypto;
use VaultForge\Security\DecryptionException;
use VaultForge\Support\Clock;
use VaultForge\Support\Str;

/**
 * Vault operations on decrypted data. Requires the DEK, i.e. an unlocked vault.
 *
 * Per entry, three ciphertexts are stored:
 *   meta_ct     JSON {name, url, username, category}
 *   password_ct the password
 *   notes_ct    the notes (always present, possibly empty, so emptiness is not revealed)
 * Each is bound to the entry's random uid and field name via the AEAD associated data.
 */
final class EntryService
{
    public const MAX_ENTRIES = 20000;

    public function __construct(
        private readonly EntryRepository $repo,
        #[\SensitiveParameter] private readonly string $dek,
    ) {
    }

    /** @return list<array<string, mixed>> entry summaries (no password or notes) */
    public function list(string $query = '', string $category = '', bool $favoritesOnly = false, string $sort = 'name'): array
    {
        $needle = Str::lower(trim($query));
        $category = Str::lower(trim($category));
        $items = [];
        foreach ($this->repo->all() as $row) {
            $entry = $this->summarize($row);
            if ($favoritesOnly && !$entry['favorite']) {
                continue;
            }
            if ($category !== '' && Str::lower($entry['category']) !== $category) {
                continue;
            }
            if ($needle !== '') {
                $haystack = Str::lower($entry['name'] . "\n" . $entry['username'] . "\n" . $entry['url'] . "\n" . $entry['category']);
                if (!str_contains($haystack, $needle)) {
                    continue;
                }
            }
            $items[] = $entry;
        }
        usort($items, match ($sort) {
            'updated' => static fn (array $a, array $b): int => [$b['updated_at'], $b['id']] <=> [$a['updated_at'], $a['id']],
            'created' => static fn (array $a, array $b): int => [$b['created_at'], $b['id']] <=> [$a['created_at'], $a['id']],
            default => static fn (array $a, array $b): int => strnatcasecmp($a['name'], $b['name']) ?: $a['id'] <=> $b['id'],
        });
        return $items;
    }

    public function get(int $id): ?array
    {
        $row = $this->repo->find($id);
        return $row === null ? null : $this->summarize($row);
    }

    /** @return array{password: string, notes: string}|null */
    public function secret(int $id): ?array
    {
        $row = $this->repo->find($id);
        if ($row === null) {
            return null;
        }
        return [
            'password' => Crypto::decrypt($row['password_ct'], $this->dek, self::context($row['uid'], 'password')),
            'notes' => Crypto::decrypt($row['notes_ct'], $this->dek, self::context($row['uid'], 'notes')),
        ];
    }

    /** @param array<string, mixed> $input */
    public function create(array $input): array
    {
        if ($this->repo->count() >= self::MAX_ENTRIES) {
            throw new ValidationException(['name' => 'The vault is full.'], 'The vault has reached the maximum number of entries.');
        }
        $data = EntryValidator::validate($input);
        $id = $this->insert($data, Clock::now(), Clock::now());
        return $this->get($id);
    }

    /** @param array<string, mixed> $input */
    public function update(int $id, array $input): ?array
    {
        $row = $this->repo->find($id);
        if ($row === null) {
            return null;
        }
        $data = EntryValidator::validate($input);
        $uid = $row['uid'];
        $this->repo->update(
            $id,
            $this->encryptMeta($uid, $data),
            Crypto::encrypt($data['password'], $this->dek, self::context($uid, 'password')),
            Crypto::encrypt($data['notes'], $this->dek, self::context($uid, 'notes')),
            $data['favorite'],
            Clock::now()
        );
        return $this->get($id);
    }

    public function setFavorite(int $id, bool $favorite): ?array
    {
        return $this->repo->setFavorite($id, $favorite) ? $this->get($id) : null;
    }

    public function delete(int $id): bool
    {
        return $this->repo->delete($id);
    }

    /** @return list<string> */
    public function categories(): array
    {
        $categories = EntryValidator::SUGGESTED_CATEGORIES;
        foreach ($this->list() as $entry) {
            if ($entry['category'] !== '' && empty($entry['corrupt'])) {
                $categories[] = $entry['category'];
            }
        }
        $unique = [];
        foreach ($categories as $c) {
            $unique[Str::lower($c)] ??= $c;
        }
        $values = array_values($unique);
        natcasesort($values);
        return array_values($values);
    }

    /** Dashboard statistics, including weak and reused password counts. */
    public function stats(): array
    {
        $rows = $this->repo->all();
        $favorites = 0;
        $categories = [];
        $weak = 0;
        $fingerprints = [];
        $unreadable = 0;
        $summaries = [];
        foreach ($rows as $row) {
            $entry = $this->summarize($row);
            $summaries[] = $entry;
            if (!empty($entry['corrupt'])) {
                $unreadable++;
                continue;
            }
            if ($entry['favorite']) {
                $favorites++;
            }
            $categories[$entry['category']] = ($categories[$entry['category']] ?? 0) + 1;
            try {
                $password = Crypto::decrypt($row['password_ct'], $this->dek, self::context($row['uid'], 'password'));
            } catch (DecryptionException) {
                $unreadable++;
                continue;
            }
            if (StrengthEstimator::estimate($password)['score'] < 2) {
                $weak++;
            }
            $fp = hash('sha256', $password);
            $fingerprints[$fp] = ($fingerprints[$fp] ?? 0) + 1;
            sodium_memzero($password);
        }
        $reused = 0;
        foreach ($fingerprints as $count) {
            if ($count > 1) {
                $reused += $count;
            }
        }
        usort($summaries, static fn (array $a, array $b): int => [$b['updated_at'], $b['id']] <=> [$a['updated_at'], $a['id']]);
        ksort($categories, SORT_NATURAL | SORT_FLAG_CASE);
        return [
            'total' => count($rows),
            'favorites' => $favorites,
            'categories' => $categories,
            'weak' => $weak,
            'reused' => $reused,
            'unreadable' => $unreadable,
            'recent' => array_slice($summaries, 0, 6),
        ];
    }

    /** Every entry fully decrypted, for an encrypted backup. Fails if any entry cannot be decrypted. */
    public function exportAll(): array
    {
        $out = [];
        foreach ($this->repo->all() as $row) {
            $meta = $this->decryptMeta($row);
            $secret = $this->secret((int) $row['id']);
            $out[] = [
                'name' => $meta['name'],
                'url' => $meta['url'],
                'username' => $meta['username'],
                'password' => $secret['password'],
                'notes' => $secret['notes'],
                'category' => $meta['category'],
                'favorite' => (bool) $row['favorite'],
                'created_at' => $row['created_at'],
                'updated_at' => $row['updated_at'],
            ];
        }
        return $out;
    }

    /**
     * Import validated entries (from a backup) in a single transaction.
     * mode "replace" deletes all current entries first; "merge" skips exact duplicates.
     * @param list<array<string, mixed>> $entries
     * @return array{added: int, skipped: int, removed: int}
     */
    public function import(array $entries, string $mode): array
    {
        if (!in_array($mode, ['replace', 'merge'], true)) {
            throw new \InvalidArgumentException('Unknown import mode.');
        }
        $db = $this->repo->db();
        $db->beginTransaction();
        try {
            $removed = 0;
            $seen = [];
            if ($mode === 'replace') {
                $removed = $this->repo->deleteAll();
            } else {
                foreach ($this->exportAll() as $existing) {
                    $seen[self::fingerprint($existing)] = true;
                }
            }
            if (($mode === 'merge' ? $this->repo->count() : 0) + count($entries) > self::MAX_ENTRIES) {
                throw new ValidationException([], 'The restore would exceed the maximum number of entries.');
            }
            $added = 0;
            $skipped = 0;
            foreach ($entries as $entry) {
                $fp = self::fingerprint($entry);
                if (isset($seen[$fp])) {
                    $skipped++;
                    continue;
                }
                $seen[$fp] = true;
                $this->insert($entry, $entry['created_at'], $entry['updated_at']);
                $added++;
            }
            $db->commit();
            return ['added' => $added, 'skipped' => $skipped, 'removed' => $removed];
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }
    }

    /**
     * Re-encrypt every entry under a new DEK (master password change / key rotation).
     * Must be called inside the caller's transaction.
     */
    public function reencryptAll(#[\SensitiveParameter] string $newDek): int
    {
        if (!$this->repo->db()->inTransaction()) {
            throw new \LogicException('reencryptAll() must run inside a transaction.');
        }
        $count = 0;
        $target = new self($this->repo, $newDek);
        foreach ($this->repo->all() as $row) {
            $uid = $row['uid'];
            try {
                $meta = $this->decryptMeta($row);
                $password = Crypto::decrypt($row['password_ct'], $this->dek, self::context($uid, 'password'));
                $notes = Crypto::decrypt($row['notes_ct'], $this->dek, self::context($uid, 'notes'));
            } catch (DecryptionException | \JsonException) {
                throw new \RuntimeException('Entry #' . $row['id'] . ' could not be decrypted, so the key change was cancelled. No data was modified.');
            }
            $this->repo->replaceCiphertexts(
                (int) $row['id'],
                $target->encryptMeta($uid, $meta),
                Crypto::encrypt($password, $newDek, self::context($uid, 'password')),
                Crypto::encrypt($notes, $newDek, self::context($uid, 'notes'))
            );
            sodium_memzero($password);
            $count++;
        }
        return $count;
    }

    private function insert(array $data, string $createdAt, string $updatedAt): int
    {
        $uid = bin2hex(random_bytes(16));
        return $this->repo->insert(
            $uid,
            $this->encryptMeta($uid, $data),
            Crypto::encrypt($data['password'], $this->dek, self::context($uid, 'password')),
            Crypto::encrypt($data['notes'], $this->dek, self::context($uid, 'notes')),
            (bool) $data['favorite'],
            $createdAt,
            $updatedAt
        );
    }

    private function encryptMeta(string $uid, array $data): string
    {
        $json = json_encode([
            'name' => $data['name'],
            'url' => $data['url'],
            'username' => $data['username'],
            'category' => $data['category'],
        ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return Crypto::encrypt($json, $this->dek, self::context($uid, 'meta'));
    }

    /** @return array{name: string, url: string, username: string, category: string} */
    private function decryptMeta(array $row): array
    {
        $json = Crypto::decrypt($row['meta_ct'], $this->dek, self::context($row['uid'], 'meta'));
        $meta = json_decode($json, true, 4, JSON_THROW_ON_ERROR);
        return [
            'name' => (string) ($meta['name'] ?? ''),
            'url' => (string) ($meta['url'] ?? ''),
            'username' => (string) ($meta['username'] ?? ''),
            'category' => (string) ($meta['category'] ?? EntryValidator::DEFAULT_CATEGORY),
        ];
    }

    private function summarize(array $row): array
    {
        $base = [
            'id' => (int) $row['id'],
            'favorite' => (bool) $row['favorite'],
            'created_at' => $row['created_at'],
            'updated_at' => $row['updated_at'],
        ];
        try {
            return $base + $this->decryptMeta($row) + ['corrupt' => false];
        } catch (DecryptionException | \JsonException) {
            return $base + ['name' => 'Unreadable entry #' . $row['id'], 'url' => '', 'username' => '', 'category' => '', 'corrupt' => true];
        }
    }

    private static function fingerprint(array $entry): string
    {
        return hash('sha256', json_encode([Str::lower($entry['name']), $entry['username'], $entry['password']], JSON_THROW_ON_ERROR));
    }

    private static function context(string $uid, string $field): string
    {
        return 'entry:v1:' . $uid . ':' . $field;
    }
}
