<?php

declare(strict_types=1);

namespace VaultForge\Vault;

use VaultForge\Support\Clock;
use VaultForge\Support\Str;

/** Server-side validation and normalisation of entry input (API and backup files). */
final class EntryValidator
{
    public const MAX_NAME = 200;
    public const MAX_URL = 2048;
    public const MAX_USERNAME = 320;
    public const MAX_PASSWORD = 4096;
    public const MAX_NOTES = 10000;
    public const MAX_CATEGORY = 50;
    public const DEFAULT_CATEGORY = 'General';
    public const SUGGESTED_CATEGORIES = ['General', 'Email', 'Social', 'Finance', 'Work', 'Shopping', 'Development', 'Entertainment', 'Other'];

    /**
     * @param array<string, mixed> $input
     * @return array{name: string, url: string, username: string, password: string, notes: string, category: string, favorite: bool, created_at?: string, updated_at?: string}
     * @throws ValidationException
     */
    public static function validate(array $input, bool $withTimestamps = false): array
    {
        $errors = [];

        $name = self::string($input, 'name', $errors);
        $name = trim($name);
        if ($name === '') {
            $errors['name'] ??= 'Name is required.';
        } elseif (Str::length($name) > self::MAX_NAME || Str::hasControlChars($name)) {
            $errors['name'] = 'Name must be at most ' . self::MAX_NAME . ' characters, without control characters.';
        }

        $url = trim(self::string($input, 'url', $errors));
        if ($url !== '') {
            if (!preg_match('#^[a-z][a-z0-9+.-]*://#i', $url)) {
                $url = 'https://' . $url;
            }
            $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
            if (strlen($url) > self::MAX_URL || Str::hasControlChars($url) || preg_match('/\s/', $url)
                || !in_array($scheme, ['http', 'https'], true) || filter_var($url, FILTER_VALIDATE_URL) === false) {
                $errors['url'] = 'Enter a valid http:// or https:// address (or leave it empty).';
            }
        }

        $username = trim(self::string($input, 'username', $errors));
        if (Str::length($username) > self::MAX_USERNAME || Str::hasControlChars($username)) {
            $errors['username'] = 'Username must be at most ' . self::MAX_USERNAME . ' characters.';
        }

        $password = self::string($input, 'password', $errors);
        if ($password === '') {
            $errors['password'] ??= 'Password is required.';
        } elseif (Str::length($password) > self::MAX_PASSWORD || str_contains($password, "\0")) {
            $errors['password'] = 'Password must be at most ' . self::MAX_PASSWORD . ' characters.';
        }

        $notes = str_replace("\r\n", "\n", self::string($input, 'notes', $errors));
        if (Str::length($notes) > self::MAX_NOTES || Str::hasControlChars($notes, true)) {
            $errors['notes'] = 'Notes must be at most ' . self::MAX_NOTES . ' characters.';
        }

        $category = trim(self::string($input, 'category', $errors));
        if ($category === '') {
            $category = self::DEFAULT_CATEGORY;
        } elseif (Str::length($category) > self::MAX_CATEGORY || Str::hasControlChars($category)) {
            $errors['category'] = 'Category must be at most ' . self::MAX_CATEGORY . ' characters.';
        }

        $favorite = $input['favorite'] ?? false;
        if (!is_bool($favorite)) {
            $errors['favorite'] = 'Favorite must be true or false.';
            $favorite = false;
        }

        $result = compact('name', 'url', 'username', 'password', 'notes', 'category', 'favorite');

        if ($withTimestamps) {
            foreach (['created_at', 'updated_at'] as $field) {
                $value = $input[$field] ?? null;
                if (!is_string($value) || !Clock::isValid($value)) {
                    $errors[$field] = 'Invalid timestamp.';
                } else {
                    $result[$field] = $value;
                }
            }
        }

        if ($errors !== []) {
            throw new ValidationException($errors);
        }
        return $result;
    }

    /** @param array<string, string> $errors */
    private static function string(array $input, string $key, array &$errors): string
    {
        $value = $input[$key] ?? '';
        if (!is_string($value)) {
            $errors[$key] = 'Invalid value.';
            return '';
        }
        if (!Str::isUtf8($value)) {
            $errors[$key] = 'Text must be valid UTF-8.';
            return '';
        }
        return $value;
    }
}
