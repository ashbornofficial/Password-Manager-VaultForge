<?php

declare(strict_types=1);

namespace VaultForge\Auth;

final class ThrottledException extends \RuntimeException
{
    public function __construct(public readonly int $retryAfter)
    {
        parent::__construct("Too many failed attempts. Try again in {$retryAfter} seconds.");
    }
}
