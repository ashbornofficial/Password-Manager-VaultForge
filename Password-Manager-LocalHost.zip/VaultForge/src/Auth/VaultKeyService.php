<?php

declare(strict_types=1);

namespace VaultForge\Auth;

use PDO;
use VaultForge\Database\StorageException;
use VaultForge\Security\Crypto;
use VaultForge\Security\DecryptionException;
use VaultForge\Support\Clock;

/**
 * Key hierarchy:
 *
 *   master password --Argon2id(salt, ops, mem)--> KEK (never stored)
 *   KEK --XChaCha20-Poly1305--> wrapped DEK (stored in vault_meta)
 *   DEK (random 256-bit) --XChaCha20-Poly1305--> every encrypted entry field
 *
 * The master password is verified cryptographically: unwrapping the DEK only succeeds
 * (Poly1305 tag check) with the KEK derived from the correct password. No password
 * hash or "verifier" is stored, and there is no recovery key.
 */
final class VaultKeyService
{
    public const FORMAT_VERSION = 1;

    public function __construct(
        private readonly PDO $db,
        private readonly int $opslimit,
        private readonly int $memlimit,
    ) {
    }

    public function isInitialized(): bool
    {
        return (int) $this->db->query('SELECT COUNT(*) FROM vault_meta WHERE id = 1')->fetchColumn() === 1;
    }

    /** Create the vault. Returns the new DEK. */
    public function initialize(#[\SensitiveParameter] string $masterPassword): string
    {
        $dek = Crypto::newKey();
        $this->db->beginTransaction();
        try {
            if ($this->isInitialized()) {
                throw new \LogicException('The vault is already initialised.');
            }
            [$salt, $wrapped] = $this->wrap($masterPassword, $dek, $this->opslimit, $this->memlimit);
            $now = Clock::now();
            $stmt = $this->db->prepare('INSERT INTO vault_meta
                (id, format_version, kdf_alg, kdf_opslimit, kdf_memlimit, kdf_salt, wrapped_dek, created_at, updated_at)
                VALUES (1, :fv, :alg, :ops, :mem, :salt, :dek, :c, :u)');
            $stmt->bindValue(':fv', self::FORMAT_VERSION, PDO::PARAM_INT);
            $stmt->bindValue(':alg', Crypto::KDF_ALG);
            $stmt->bindValue(':ops', $this->opslimit, PDO::PARAM_INT);
            $stmt->bindValue(':mem', $this->memlimit, PDO::PARAM_INT);
            $stmt->bindValue(':salt', $salt, PDO::PARAM_LOB);
            $stmt->bindValue(':dek', $wrapped, PDO::PARAM_LOB);
            $stmt->bindValue(':c', $now);
            $stmt->bindValue(':u', $now);
            $stmt->execute();
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
        return $dek;
    }

    /**
     * Verify the master password and return the DEK.
     * @throws InvalidMasterPasswordException
     */
    public function unlock(#[\SensitiveParameter] string $masterPassword): string
    {
        $meta = $this->meta();
        if ($masterPassword === '') {
            throw new InvalidMasterPasswordException('Incorrect master password.');
        }
        $kek = Crypto::deriveKey($masterPassword, $meta['kdf_salt'], $meta['kdf_opslimit'], $meta['kdf_memlimit']);
        try {
            return Crypto::decrypt(
                $meta['wrapped_dek'],
                $kek,
                self::context($meta['kdf_alg'], $meta['kdf_opslimit'], $meta['kdf_memlimit'], $meta['kdf_salt'])
            );
        } catch (DecryptionException) {
            throw new InvalidMasterPasswordException('Incorrect master password.');
        } finally {
            sodium_memzero($kek);
        }
    }

    /**
     * Re-protect a DEK with a new master password (fresh salt, current KDF parameters).
     * Callers wrap this in a transaction together with any entry re-encryption.
     */
    public function rewrap(#[\SensitiveParameter] string $newMasterPassword, #[\SensitiveParameter] string $dek): void
    {
        [$salt, $wrapped] = $this->wrap($newMasterPassword, $dek, $this->opslimit, $this->memlimit);
        $stmt = $this->db->prepare('UPDATE vault_meta SET kdf_alg = :alg, kdf_opslimit = :ops, kdf_memlimit = :mem,
            kdf_salt = :salt, wrapped_dek = :dek, updated_at = :u WHERE id = 1');
        $stmt->bindValue(':alg', Crypto::KDF_ALG);
        $stmt->bindValue(':ops', $this->opslimit, PDO::PARAM_INT);
        $stmt->bindValue(':mem', $this->memlimit, PDO::PARAM_INT);
        $stmt->bindValue(':salt', $salt, PDO::PARAM_LOB);
        $stmt->bindValue(':dek', $wrapped, PDO::PARAM_LOB);
        $stmt->bindValue(':u', Clock::now());
        $stmt->execute();
        if ($stmt->rowCount() !== 1) {
            throw new \LogicException('Vault metadata row is missing.');
        }
    }

    /** Public (non-secret) KDF information for the settings page. */
    public function kdfInfo(): array
    {
        $meta = $this->meta();
        return [
            'alg' => $meta['kdf_alg'],
            'opslimit' => $meta['kdf_opslimit'],
            'memlimit' => $meta['kdf_memlimit'],
            'created_at' => $meta['created_at'],
            'updated_at' => $meta['updated_at'],
        ];
    }

    /** @return array{0: string, 1: string} [salt, wrapped DEK] */
    private function wrap(string $password, string $dek, int $ops, int $mem): array
    {
        $salt = Crypto::newSalt();
        $kek = Crypto::deriveKey($password, $salt, $ops, $mem);
        try {
            return [$salt, Crypto::encrypt($dek, $kek, self::context(Crypto::KDF_ALG, $ops, $mem, $salt))];
        } finally {
            sodium_memzero($kek);
        }
    }

    /** Associated data binds the wrapped key to the exact KDF parameters and salt. */
    private static function context(string $alg, int $ops, int $mem, string $salt): string
    {
        return 'dek:v1:' . $alg . ':' . $ops . ':' . $mem . ':' . bin2hex($salt);
    }

    /** @return array{kdf_alg: string, kdf_opslimit: int, kdf_memlimit: int, kdf_salt: string, wrapped_dek: string, created_at: string, updated_at: string} */
    private function meta(): array
    {
        $row = $this->db->query('SELECT format_version, kdf_alg, kdf_opslimit, kdf_memlimit, kdf_salt, wrapped_dek, created_at, updated_at
            FROM vault_meta WHERE id = 1')->fetch();
        if ($row === false) {
            throw new StorageException('not_initialized', 'The vault has not been set up yet.');
        }
        $row['kdf_opslimit'] = (int) $row['kdf_opslimit'];
        $row['kdf_memlimit'] = (int) $row['kdf_memlimit'];
        if ((int) $row['format_version'] !== self::FORMAT_VERSION
            || $row['kdf_alg'] !== Crypto::KDF_ALG
            || !is_string($row['kdf_salt']) || strlen($row['kdf_salt']) !== Crypto::SALT_BYTES
            || !is_string($row['wrapped_dek'])
            || !Crypto::kdfParamsValid($row['kdf_opslimit'], $row['kdf_memlimit'])) {
            throw new StorageException('meta_corrupt', 'The vault key metadata is damaged or has an unsupported format. Restore storage/vault.sqlite from a copy or restore an encrypted backup into a new vault.');
        }
        return $row;
    }
}
