<?php

declare(strict_types=1);

namespace VaultForge\Auth;

final class InvalidMasterPasswordException extends \RuntimeException
{
}
