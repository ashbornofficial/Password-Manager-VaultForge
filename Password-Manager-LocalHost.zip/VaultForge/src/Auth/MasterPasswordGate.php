<?php

declare(strict_types=1);

namespace VaultForge\Auth;

use VaultForge\Security\RateLimiter;
use VaultForge\Support\Logger;

/** Every master-password check goes through here so the same throttle applies everywhere. */
final class MasterPasswordGate
{
    public function __construct(private readonly VaultKeyService $keys, private readonly RateLimiter $limiter)
    {
    }

    /**
     * @return string the DEK
     * @throws ThrottledException|InvalidMasterPasswordException
     */
    public function verify(#[\SensitiveParameter] string $password, string $purpose): string
    {
        $retry = $this->limiter->retryAfter();
        if ($retry > 0) {
            throw new ThrottledException($retry);
        }
        if ($password === '' || strlen($password) > PasswordPolicy::MAX_BYTES) {
            $this->fail($purpose);
        }
        try {
            $dek = $this->keys->unlock($password);
        } catch (InvalidMasterPasswordException) {
            $this->fail($purpose);
        }
        $this->limiter->reset();
        return $dek;
    }

    private function fail(string $purpose): never
    {
        $this->limiter->recordFailure();
        Logger::event('master_password_failed', ['purpose' => $purpose, 'consecutive_failures' => $this->limiter->failures()]);
        $retry = $this->limiter->retryAfter();
        throw new InvalidMasterPasswordException(
            'Incorrect master password.' . ($retry > 0 ? " Too many failed attempts: try again in {$retry} seconds." : '')
        );
    }
}
