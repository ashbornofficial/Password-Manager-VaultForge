<?php

declare(strict_types=1);

namespace VaultForge\Auth;

use VaultForge\Generator\StrengthEstimator;
use VaultForge\Support\Str;

final class PasswordPolicy
{
    public const MAX_BYTES = 1024;

    public function __construct(
        private readonly int $masterMinLength,
        private readonly int $masterMinBits,
        private readonly int $backupMinLength,
    ) {
    }

    /** @return string|null error message, or null if acceptable */
    public function checkMaster(#[\SensitiveParameter] string $password, #[\SensitiveParameter] string $confirmation): ?string
    {
        if ($password === '') {
            return 'Enter a master password.';
        }
        if (strlen($password) > self::MAX_BYTES || !Str::isUtf8($password)) {
            return 'The master password is too long or contains invalid characters.';
        }
        if (Str::length($password) < $this->masterMinLength) {
            return "The master password must be at least {$this->masterMinLength} characters long.";
        }
        if (StrengthEstimator::estimate($password)['bits'] < $this->masterMinBits) {
            return 'This master password is too predictable. Use a longer passphrase or mix more character types.';
        }
        if (!hash_equals($password, $confirmation)) {
            return 'The two master passwords do not match.';
        }
        return null;
    }

    public function checkBackup(#[\SensitiveParameter] string $password, #[\SensitiveParameter] string $confirmation, #[\SensitiveParameter] string $masterPassword): ?string
    {
        if (strlen($password) > self::MAX_BYTES || !Str::isUtf8($password)) {
            return 'The backup password is too long or contains invalid characters.';
        }
        if (Str::length($password) < $this->backupMinLength) {
            return "The backup password must be at least {$this->backupMinLength} characters long.";
        }
        if (!hash_equals($password, $confirmation)) {
            return 'The two backup passwords do not match.';
        }
        if (hash_equals($password, $masterPassword)) {
            return 'Use a backup password that is different from your master password.';
        }
        return null;
    }

    public function minMasterLength(): int
    {
        return $this->masterMinLength;
    }

    public function minBackupLength(): int
    {
        return $this->backupMinLength;
    }
}
