<?php

declare(strict_types=1);

namespace VaultForge\Settings;

use PDO;

/** Non-sensitive application preferences (stored in plaintext). */
final class SettingsRepository
{
    public function __construct(private readonly PDO $db, private readonly array $config)
    {
    }

    public function autoLockMinutes(): int
    {
        $c = $this->config['auto_lock'];
        return $this->clamp((int) $this->get('auto_lock_minutes', (string) $c['default_minutes']), $c['min_minutes'], $c['max_minutes']);
    }

    public function clipboardClearSeconds(): int
    {
        $c = $this->config['clipboard'];
        return $this->clamp((int) $this->get('clipboard_clear_seconds', (string) $c['default_seconds']), 0, $c['max_seconds']);
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, string> validation errors
     */
    public function savePreferences(array $input): array
    {
        $errors = [];
        $autoLock = filter_var($input['auto_lock_minutes'] ?? null, FILTER_VALIDATE_INT);
        $a = $this->config['auto_lock'];
        if ($autoLock === false || $autoLock < $a['min_minutes'] || $autoLock > $a['max_minutes']) {
            $errors['auto_lock_minutes'] = "Auto-lock must be between {$a['min_minutes']} and {$a['max_minutes']} minutes.";
        }
        $clip = filter_var($input['clipboard_clear_seconds'] ?? null, FILTER_VALIDATE_INT);
        $c = $this->config['clipboard'];
        if ($clip === false || $clip < 0 || $clip > $c['max_seconds']) {
            $errors['clipboard_clear_seconds'] = "Clipboard clearing must be between 0 and {$c['max_seconds']} seconds.";
        }
        if ($errors !== []) {
            return $errors;
        }
        $this->db->beginTransaction();
        try {
            $this->set('auto_lock_minutes', (string) $autoLock);
            $this->set('clipboard_clear_seconds', (string) $clip);
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
        return [];
    }

    public function get(string $key, string $default): string
    {
        $stmt = $this->db->prepare('SELECT value FROM settings WHERE key = :k');
        $stmt->execute([':k' => $key]);
        $value = $stmt->fetchColumn();
        return $value === false ? $default : (string) $value;
    }

    public function set(string $key, string $value): void
    {
        $stmt = $this->db->prepare('INSERT INTO settings (key, value) VALUES (:k, :v) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
        $stmt->execute([':k' => $key, ':v' => $value]);
    }

    private function clamp(int $value, int $min, int $max): int
    {
        return max($min, min($max, $value));
    }
}
