<#
.SYNOPSIS
  Stop the VaultForge background server started by start.ps1.
#>
param([int]$Port = 8080)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$pidFile = Join-Path $Root 'storage\server.pid'
$stopped = $false

if (Test-Path -LiteralPath $pidFile) {
    $id = [int](Get-Content -LiteralPath $pidFile -Raw)
    $proc = Get-Process -Id $id -ErrorAction SilentlyContinue
    if ($proc -and $proc.ProcessName -like 'php*') {
        Stop-Process -Id $id -Force -Confirm:$false
        $stopped = $true
        Write-Host "Stopped VaultForge (PID $id)." -ForegroundColor Green
    }
    Remove-Item -LiteralPath $pidFile -Force
}

if (-not $stopped) {
    # Fallback: a php.exe listening on 127.0.0.1:<Port>.
    $conns = Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    foreach ($c in $conns) {
        $p = Get-Process -Id $c.OwningProcess -ErrorAction SilentlyContinue
        if ($p -and $p.ProcessName -like 'php*') {
            Stop-Process -Id $p.Id -Force -Confirm:$false
            $stopped = $true
            Write-Host "Stopped php.exe on 127.0.0.1:$Port (PID $($p.Id))." -ForegroundColor Green
        }
    }
}
if (-not $stopped) { Write-Host 'VaultForge is not running.' -ForegroundColor Yellow }
