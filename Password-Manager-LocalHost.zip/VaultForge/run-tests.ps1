<#
.SYNOPSIS
  Run the VaultForge test-suite with the same PHP runtime as the server.
.EXAMPLE
  .\run-tests.ps1            # everything
  .\run-tests.ps1 generator  # only tests matching "generator"
#>
param([string]$Filter = '')
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
. (Join-Path $Root 'scripts\php-env.ps1')
$php = Get-VFPhp
$phpArgs = Get-VFPhpArgs -Php $php -Root $Root
# The integration tests start servers with these same arguments.
$env:VAULTFORGE_PHP_ARGS = ConvertTo-Json -Compress -InputObject @($phpArgs)
$runArgs = $phpArgs + @('-d', 'display_errors=1', (Join-Path $Root 'tests\run.php'))
if ($Filter) { $runArgs += $Filter }
& $php @runArgs
exit $LASTEXITCODE
