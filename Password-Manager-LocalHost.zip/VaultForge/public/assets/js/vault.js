/* Vault page: list, search, filter, reveal, copy, edit, delete. */
(() => {
  'use strict';
  const VF = window.VF;
  const REVEAL_SECONDS = 30;

  document.addEventListener('DOMContentLoaded', () => {
    const list = VF.$('#vault-list');
    if (!list) return;
    const search = VF.$('#vault-search');
    const category = VF.$('#vault-category');
    const sort = VF.$('#vault-sort');
    const favBtn = VF.$('#vault-favorites');
    const empty = VF.$('#vault-empty');
    const count = VF.$('#vault-count');
    let entries = [];
    let categories = [];
    let timer = null;
    let seq = 0;
    const revealTimers = new Map();

    VF.wipers.push(() => {
      entries = [];
      revealTimers.forEach((t) => clearTimeout(t));
      revealTimers.clear();
      list.replaceChildren();
    });

    // Restore filters passed in the URL (e.g. from dashboard category chips).
    const params = new URLSearchParams(window.location.search);
    if (params.get('q')) search.value = params.get('q');
    let pendingCategory = params.get('category') || '';
    if (params.get('favorites') === '1') favBtn.setAttribute('aria-pressed', 'true');

    const filtersActive = () => search.value.trim() !== '' || category.value !== '' || favBtn.getAttribute('aria-pressed') === 'true';

    async function load() {
      const mine = ++seq;
      const qs = new URLSearchParams({ q: search.value.trim(), category: pendingCategory || category.value, sort: sort.value });
      if (favBtn.getAttribute('aria-pressed') === 'true') qs.set('favorites', '1');
      try {
        const res = await VF.api('GET', '/api/entries?' + qs.toString());
        if (mine !== seq) return;
        entries = res.entries;
        categories = res.categories;
        fillCategories();
        render();
      } catch (e) {
        VF.toast(e.message, 'error');
      }
    }

    function fillCategories() {
      const selected = pendingCategory || category.value;
      pendingCategory = '';
      category.replaceChildren(VF.h('option', { value: '', text: 'All categories' }),
        ...categories.map((c) => VF.h('option', { value: c, text: c })));
      category.value = categories.includes(selected) ? selected : '';
    }

    function render() {
      revealTimers.forEach((t) => clearTimeout(t));
      revealTimers.clear();
      list.replaceChildren(...entries.map(row));
      const filtered = filtersActive();
      count.textContent = entries.length ? `${entries.length} ${entries.length === 1 ? 'entry' : 'entries'}${filtered ? ' match' : ''}` : '';
      empty.hidden = entries.length > 0;
      VF.$('#vault-empty-title').textContent = filtered ? 'No matching entries' : 'No entries yet';
      VF.$('#vault-empty-text').textContent = filtered ? 'Try a different search or clear the filters.' : 'Add your first login or generate a new password.';
      VF.$('#vault-empty-add').hidden = filtered;
    }

    async function fetchSecret(id) {
      return VF.api('GET', `/api/entries/${id}/secret`);
    }

    function row(entry) {
      const secretBox = VF.h('div', { class: 'entry-secret', hidden: true, 'data-sensitive': '' });
      const revealBtn = VF.h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': `Reveal password for ${entry.name}`, title: 'Reveal password' }, VF.icon('eye'));
      const hide = () => {
        secretBox.textContent = '';
        secretBox.hidden = true;
        revealBtn.replaceChildren(VF.icon('eye'));
        revealBtn.setAttribute('aria-label', `Reveal password for ${entry.name}`);
        clearTimeout(revealTimers.get(entry.id));
        revealTimers.delete(entry.id);
      };
      revealBtn.addEventListener('click', async () => {
        if (!secretBox.hidden) { hide(); return; }
        try {
          const s = await fetchSecret(entry.id);
          secretBox.textContent = s.password;
          secretBox.hidden = false;
          revealBtn.replaceChildren(VF.icon('eye-off'));
          revealBtn.setAttribute('aria-label', `Hide password for ${entry.name}`);
          revealTimers.set(entry.id, setTimeout(hide, REVEAL_SECONDS * 1000));
        } catch (e) { VF.toast(e.message, 'error'); }
      });

      const copyUser = VF.h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': `Copy username for ${entry.name}`, title: 'Copy username', disabled: entry.username === '' },
        VF.icon('user'));
      copyUser.addEventListener('click', () => VF.copy(entry.username, { label: 'Username copied' }));

      const copyPass = VF.h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': `Copy password for ${entry.name}`, title: 'Copy password' }, VF.icon('copy'));
      copyPass.addEventListener('click', async () => {
        try {
          const s = await fetchSecret(entry.id);
          await VF.copy(s.password, { sensitive: true, label: 'Password copied' });
        } catch (e) { VF.toast(e.message, 'error'); }
      });

      const fav = VF.h('button', {
        type: 'button', class: 'icon-btn icon-btn-sm' + (entry.favorite ? ' fav-on' : ''),
        'aria-label': entry.favorite ? `Remove ${entry.name} from favorites` : `Add ${entry.name} to favorites`,
        'aria-pressed': String(entry.favorite), title: 'Favorite',
      }, VF.icon('star'));
      fav.addEventListener('click', async () => {
        try {
          await VF.api('POST', `/api/entries/${entry.id}/favorite`, { favorite: !entry.favorite });
          load();
        } catch (e) { VF.toast(e.message, 'error'); }
      });

      const edit = VF.h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': `Edit ${entry.name}`, title: 'Edit' }, VF.icon('edit'));
      edit.addEventListener('click', async () => {
        try {
          const s = await fetchSecret(entry.id);
          const saved = await VF.entryDialog.open({ entry, secret: s, categories });
          if (saved) load();
        } catch (e) { VF.toast(e.message, 'error'); }
      });

      const del = VF.h('button', { type: 'button', class: 'icon-btn icon-btn-sm danger', 'aria-label': `Delete ${entry.name}`, title: 'Delete' }, VF.icon('trash'));
      del.addEventListener('click', async () => {
        const ok = await VF.confirm({
          title: 'Delete entry?',
          message: `“${entry.name}” will be permanently deleted from your vault. This cannot be undone.`,
          confirmText: 'Delete', danger: true,
        });
        if (!ok) return;
        try {
          await VF.api('DELETE', `/api/entries/${entry.id}`);
          VF.toast('Entry deleted.', 'success');
          load();
        } catch (e) { VF.toast(e.message, 'error'); }
      });

      const sub = VF.h('div', { class: 'entry-sub' });
      if (entry.username) sub.append(VF.h('span', { text: entry.username }));
      if (/^https?:\/\//i.test(entry.url)) {
        let host = entry.url;
        try { host = new URL(entry.url).host; } catch (e) { /* keep raw */ }
        sub.append(VF.h('a', { href: entry.url, target: '_blank', rel: 'noopener noreferrer' }, VF.icon('external', 'icon icon-sm'), host));
      }

      const actions = entry.corrupt ? [del] : [revealBtn, copyUser, copyPass, fav, edit, del];
      return VF.h('li', { class: 'entry' + (entry.corrupt ? ' corrupt' : '') },
        VF.h('div', { class: 'avatar', 'aria-hidden': 'true', text: (Array.from(entry.name.trim())[0] || '?') }),
        VF.h('div', { class: 'entry-main' },
          VF.h('div', { class: 'entry-title' },
            VF.h('strong', { text: entry.name }),
            entry.category ? VF.h('span', { class: 'badge', text: entry.category }) : null),
          sub, secretBox),
        VF.h('div', { class: 'entry-actions' }, actions));
    }

    const schedule = () => { clearTimeout(timer); timer = setTimeout(load, 180); };
    search.addEventListener('input', schedule);
    category.addEventListener('change', load);
    sort.addEventListener('change', load);
    favBtn.addEventListener('click', () => {
      favBtn.setAttribute('aria-pressed', String(favBtn.getAttribute('aria-pressed') !== 'true'));
      load();
    });
    const add = async () => { if (await VF.entryDialog.open({ categories })) load(); };
    VF.$('#vault-add').addEventListener('click', add);
    VF.$('#vault-empty-add').addEventListener('click', add);
    document.addEventListener('keydown', (e) => {
      if (e.key === '/' && document.activeElement === document.body) { e.preventDefault(); search.focus(); }
    });

    load();
  });
})();
