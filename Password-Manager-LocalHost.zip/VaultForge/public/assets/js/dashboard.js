/* Dashboard: statistics, recent entries, quick generator. */
(() => {
  'use strict';
  const VF = window.VF;

  document.addEventListener('DOMContentLoaded', () => {
    const total = VF.$('#stat-total');
    if (!total) return;
    const quickOut = VF.$('#quick-output');
    let quick = '';
    VF.wipers.push(() => { quick = ''; });

    async function loadStats() {
      try {
        const s = await VF.api('GET', '/api/stats');
        total.textContent = s.total;
        VF.$('#stat-favorites').textContent = s.favorites;
        VF.$('#stat-categories').textContent = Object.keys(s.categories).length;
        for (const key of ['weak', 'reused']) {
          const el = VF.$('#stat-' + key);
          el.textContent = s[key];
          el.classList.toggle('nonzero', s[key] > 0);
        }

        const recent = VF.$('#recent-list');
        recent.replaceChildren(...s.recent.map((e) => VF.h('li', {},
          VF.h('div', { class: 'avatar', 'aria-hidden': 'true', text: Array.from(e.name.trim())[0] || '?' }),
          VF.h('div', { class: 'meta' }, VF.h('strong', { text: e.name }), VF.h('span', { text: e.username || e.category })),
          e.favorite ? VF.icon('star', 'icon icon-sm') : null)));
        VF.$('#recent-empty').hidden = s.total > 0;
        recent.hidden = s.total === 0;

        const chips = VF.$('#category-chips');
        const cats = Object.entries(s.categories);
        chips.replaceChildren(...cats.map(([name, n]) =>
          VF.h('a', { class: 'chip', href: '/vault?category=' + encodeURIComponent(name) }, name, VF.h('b', { text: n }))));
        VF.$('#category-empty').hidden = cats.length > 0;
      } catch (e) {
        VF.toast(e.message, 'error');
      }
    }

    async function regen() {
      try {
        const r = await VF.api('POST', '/api/generate/password', { length: 20, upper: true, lower: true, digits: true, symbols: true });
        quick = r.password;
        if (VF.renderGenerated) VF.renderGenerated(quickOut, quick); else quickOut.textContent = quick;
        VF.renderStrength(VF.$('#quick-strength'), r.strength, 'generated');
      } catch (e) { VF.toast(e.message, 'error'); }
    }

    VF.$('#quick-regen').addEventListener('click', regen);
    VF.$('#quick-copy').addEventListener('click', () => { if (quick) VF.copy(quick, { sensitive: true, label: 'Password copied' }); });
    VF.$('#quick-save').addEventListener('click', async () => {
      if (quick && await VF.entryDialog.open({ password: quick })) { loadStats(); regen(); }
    });
    VF.$('#dash-add').addEventListener('click', async () => { if (await VF.entryDialog.open()) loadStats(); });

    loadStats();
    regen();
  });
})();
