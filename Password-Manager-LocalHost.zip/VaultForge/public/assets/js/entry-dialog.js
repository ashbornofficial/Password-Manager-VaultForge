/* Create / edit entry dialog, shared by the dashboard, generator and vault pages. */
(() => {
  'use strict';
  const VF = window.VF;

  document.addEventListener('DOMContentLoaded', () => {
    const dlg = VF.$('#entry-dialog');
    if (!dlg) return;
    const form = VF.$('#entry-form', dlg);
    const title = VF.$('#entry-dialog-title', dlg);
    const fields = {
      name: VF.$('#entry-name', dlg),
      url: VF.$('#entry-url', dlg),
      username: VF.$('#entry-username', dlg),
      password: VF.$('#entry-password', dlg),
      category: VF.$('#entry-category', dlg),
      notes: VF.$('#entry-notes', dlg),
      favorite: VF.$('#entry-favorite', dlg),
    };
    fields.notes.dataset.secret = '1';
    const datalist = VF.$('#entry-categories', dlg);
    const submit = VF.$('#entry-submit', dlg);
    const meter = VF.$('[data-strength-for="entry-password"]', dlg);
    let editingId = null;
    let resolver = null;

    const clearErrors = () => {
      VF.$$('[data-error-for]', dlg).forEach((el) => { el.textContent = ''; });
      Object.values(fields).forEach((f) => f.removeAttribute('aria-invalid'));
    };
    const reset = () => {
      form.reset();
      clearErrors();
      fields.password.type = 'password';
      if (meter) meter.replaceChildren();
    };
    const finish = (value) => {
      const r = resolver;
      resolver = null;
      reset();
      if (r) r(value);
    };

    VF.$$('[data-close]', dlg).forEach((b) => b.addEventListener('click', () => dlg.close()));
    dlg.addEventListener('close', () => finish(null));
    VF.wipers.push(() => { if (dlg.open) dlg.close(); reset(); });

    VF.$('#entry-generate', dlg).addEventListener('click', async () => {
      try {
        const res = await VF.api('POST', '/api/generate/password',
          { length: 20, upper: true, lower: true, digits: true, symbols: true, exclude_ambiguous: false });
        fields.password.value = res.password;
        fields.password.type = 'text';
        if (meter) VF.renderStrength(meter, res.strength, 'generated');
      } catch (e) { VF.toast(e.message, 'error'); }
    });

    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      clearErrors();
      const payload = {
        name: fields.name.value,
        url: fields.url.value,
        username: fields.username.value,
        password: fields.password.value,
        category: fields.category.value,
        notes: fields.notes.value,
        favorite: fields.favorite.checked,
      };
      submit.disabled = true;
      try {
        const res = editingId === null
          ? await VF.api('POST', '/api/entries', payload)
          : await VF.api('PUT', `/api/entries/${editingId}`, payload);
        VF.toast(editingId === null ? 'Entry saved to vault.' : 'Entry updated.', 'success');
        const r = resolver;
        resolver = null;
        dlg.close();
        if (r) r(res.entry);
      } catch (e) {
        if (e.errors && Object.keys(e.errors).length) {
          for (const [key, msg] of Object.entries(e.errors)) {
            const slot = VF.$(`[data-error-for="${CSS.escape(key)}"]`, dlg);
            if (slot) slot.textContent = msg;
            if (fields[key]) fields[key].setAttribute('aria-invalid', 'true');
          }
          const first = Object.keys(e.errors).find((k) => fields[k]);
          if (first) fields[first].focus();
        }
        VF.toast(e.message, 'error');
      } finally {
        submit.disabled = false;
      }
    });

    VF.entryDialog = {
      /** open({entry?, secret?, password?, categories?}) → Promise<entry|null> */
      open({ entry = null, secret = null, password = '', categories = null } = {}) {
        if (resolver) return Promise.resolve(null);
        reset();
        editingId = entry ? entry.id : null;
        title.textContent = entry ? 'Edit entry' : 'New entry';
        if (entry) {
          fields.name.value = entry.name;
          fields.url.value = entry.url;
          fields.username.value = entry.username;
          fields.category.value = entry.category;
          fields.favorite.checked = !!entry.favorite;
        }
        if (secret) {
          fields.password.value = secret.password;
          fields.notes.value = secret.notes;
        } else if (password) {
          fields.password.value = password;
          fields.password.type = 'text';
        }
        if (fields.password.value && meter) VF.renderStrength(meter, VF.strength(fields.password.value));
        const fill = (list) => datalist.replaceChildren(...list.map((c) => VF.h('option', { value: c })));
        if (categories) fill(categories);
        else VF.api('GET', '/api/entries?sort=name').then((r) => fill(r.categories)).catch(() => {});
        return new Promise((resolve) => {
          resolver = resolve;
          dlg.showModal();
          fields.name.focus();
        });
      },
    };
  });
})();
