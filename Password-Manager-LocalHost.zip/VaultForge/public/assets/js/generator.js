/* Generator page: passwords and passphrases are generated server-side with random_int(). */
(() => {
  'use strict';
  const VF = window.VF;

  /** Render a generated value with digits/symbols coloured (textContent only). */
  VF.renderGenerated = (container, value) => {
    container.replaceChildren();
    const frag = document.createDocumentFragment();
    let run = '';
    let runClass = '';
    const flush = () => {
      if (!run) return;
      frag.append(runClass ? VF.h('span', { class: runClass, text: run }) : document.createTextNode(run));
      run = '';
    };
    for (const ch of Array.from(value)) {
      const cls = /[0-9]/.test(ch) ? 'ch-digit' : /[A-Za-z]/.test(ch) || ch === ' ' ? '' : 'ch-symbol';
      if (cls !== runClass) { flush(); runClass = cls; }
      run += ch;
    }
    flush();
    container.append(frag);
  };

  document.addEventListener('DOMContentLoaded', () => {
    const out = VF.$('#gen-output');
    if (!out) return;
    const strength = VF.$('#gen-strength');
    const errorBox = VF.$('#gen-error');
    const tabs = { password: VF.$('#tab-password'), passphrase: VF.$('#tab-passphrase') };
    const panels = { password: VF.$('#panel-password'), passphrase: VF.$('#panel-passphrase') };
    const o = (id) => VF.$('#' + id);
    let mode = 'password';
    let current = '';
    let timer = null;
    let seq = 0;
    VF.wipers.push(() => { current = ''; });

    const length = o('opt-length');
    const lengthNum = o('opt-length-num');
    const customOn = o('opt-custom-on');
    const custom = o('opt-custom');
    const classBoxes = ['opt-upper', 'opt-lower', 'opt-digits', 'opt-symbols'].map(o);

    const syncLength = (src) => {
      let v = parseInt(src.value, 10);
      if (Number.isNaN(v)) return;
      v = Math.min(Number(length.max), Math.max(Number(length.min), v));
      length.value = v;
      if (src !== lengthNum || String(v) === lengthNum.value) lengthNum.value = v;
      o('opt-length-value').textContent = v;
    };
    length.addEventListener('input', () => { syncLength(length); schedule(); });
    lengthNum.addEventListener('change', () => { syncLength(lengthNum); lengthNum.value = length.value; schedule(); });
    customOn.addEventListener('change', () => {
      custom.disabled = !customOn.checked;
      classBoxes.forEach((b) => { b.disabled = customOn.checked; });
      if (customOn.checked) custom.focus();
      schedule();
    });
    o('opt-words').addEventListener('input', () => { o('opt-words-value').textContent = o('opt-words').value; schedule(); });
    VF.$$('#password-options input, #passphrase-options input, #passphrase-options select').forEach((el) => {
      if (![length, lengthNum].includes(el) && el.id !== 'opt-words') {
        el.addEventListener(el.type === 'text' ? 'input' : 'change', schedule);
      }
    });

    function schedule() {
      clearTimeout(timer);
      timer = setTimeout(generate, 120);
    }

    async function generate() {
      const mine = ++seq;
      let url, body;
      if (mode === 'password') {
        url = '/api/generate/password';
        body = {
          length: Number(length.value),
          upper: o('opt-upper').checked,
          lower: o('opt-lower').checked,
          digits: o('opt-digits').checked,
          symbols: o('opt-symbols').checked,
          exclude_ambiguous: o('opt-ambiguous').checked,
          custom: customOn.checked ? custom.value : '',
        };
      } else {
        url = '/api/generate/passphrase';
        body = {
          words: Number(o('opt-words').value),
          separator: o('opt-separator').value,
          capitalize: o('opt-capitalize').checked,
          number: o('opt-number').checked,
        };
      }
      try {
        const res = await VF.api('POST', url, body);
        if (mine !== seq) return;
        errorBox.hidden = true;
        current = res.password;
        VF.renderGenerated(out, current);
        const note = mode === 'password' ? `pool of ${res.pool_size} characters` : `${res.word_count} words from ${res.list_size}`;
        VF.renderStrength(strength, res.strength, note);
      } catch (e) {
        if (mine !== seq) return;
        current = '';
        out.replaceChildren();
        strength.replaceChildren();
        errorBox.textContent = e.message;
        errorBox.hidden = false;
      }
    }

    const selectTab = (name) => {
      mode = name;
      for (const [key, tab] of Object.entries(tabs)) {
        const on = key === name;
        tab.classList.toggle('active', on);
        tab.setAttribute('aria-selected', String(on));
        tab.tabIndex = on ? 0 : -1;
        panels[key].hidden = !on;
      }
      generate();
    };
    tabs.password.addEventListener('click', () => selectTab('password'));
    tabs.passphrase.addEventListener('click', () => selectTab('passphrase'));
    VF.$('.tabs').addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        const next = mode === 'password' ? 'passphrase' : 'password';
        selectTab(next);
        tabs[next].focus();
      }
    });

    o('gen-regen').addEventListener('click', generate);
    o('gen-copy').addEventListener('click', () => { if (current) VF.copy(current, { sensitive: true, label: 'Password copied' }); });
    o('gen-save').addEventListener('click', async () => {
      if (!current || !VF.entryDialog) return;
      await VF.entryDialog.open({ password: current });
    });

    generate();
  });
})();
