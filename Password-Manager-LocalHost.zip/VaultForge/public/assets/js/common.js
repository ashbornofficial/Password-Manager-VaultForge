/* VaultForge shared front-end code. No external dependencies, no storage APIs.
 * Untrusted data is only ever inserted with textContent / attributes, never innerHTML. */
(() => {
  'use strict';

  const VF = (window.VF = {});
  VF.csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
  VF.$ = (sel, root = document) => root.querySelector(sel);
  VF.$$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  /** Tiny element builder: h('div', {class: 'x', text: 'y', onclick: fn}, child, ...) */
  VF.h = (tag, attrs = {}, ...children) => {
    const el = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs || {})) {
      if (value === null || value === undefined || value === false) continue;
      if (key === 'class') el.className = value;
      else if (key === 'text') el.textContent = value;
      else if (key === 'dataset') Object.assign(el.dataset, value);
      else if (key.startsWith('on') && typeof value === 'function') el.addEventListener(key.slice(2), value);
      else el.setAttribute(key, value === true ? '' : String(value));
    }
    for (const child of children.flat()) {
      if (child === null || child === undefined || child === false) continue;
      el.append(child instanceof Node ? child : document.createTextNode(String(child)));
    }
    return el;
  };

  VF.icon = (name, cls = 'icon') => {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('class', cls);
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    const use = document.createElementNS(ns, 'use');
    use.setAttribute('href', '#i-' + name);
    svg.append(use);
    return svg;
  };

  // ------------------------------------------------------------ toasts
  VF.toast = (message, type = 'info', timeout = 4000) => {
    const box = VF.$('#toasts');
    if (!box) return;
    const icon = type === 'success' ? 'check' : type === 'error' ? 'alert' : 'info';
    const toast = VF.h('div', { class: `toast toast-${type}`, role: type === 'error' ? 'alert' : null },
      VF.icon(icon), VF.h('span', { text: message }));
    box.append(toast);
    setTimeout(() => {
      toast.classList.add('out');
      setTimeout(() => toast.remove(), 250);
    }, type === 'error' ? Math.max(timeout, 6500) : timeout);
  };

  // ------------------------------------------------------------ API
  VF.api = async (method, url, body) => {
    const headers = { 'X-CSRF-Token': VF.csrf, Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    let res;
    try {
      res = await fetch(url, {
        method, headers, credentials: 'same-origin', cache: 'no-store', redirect: 'error',
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (e) {
      throw new Error('Could not reach the local VaultForge server. Is it still running?');
    }
    let data = {};
    try { data = await res.json(); } catch (e) { /* non-JSON */ }
    if (res.status === 401 && data.locked) {
      VF.wipe();
      window.location.assign('/unlock');
      throw new Error('The vault is locked.');
    }
    if (!res.ok) {
      const err = new Error(data.error || `Request failed (${res.status}).`);
      err.status = res.status;
      err.errors = data.errors || {};
      throw err;
    }
    return data;
  };

  // ------------------------------------------------------------ clipboard
  let clipboardTimer = null;
  let clipboardDirty = false;
  VF.copy = async (text, { sensitive = false, label = 'Copied' } = {}) => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        const ta = VF.h('textarea', { class: 'sr-only', 'aria-hidden': 'true' });
        ta.value = text;
        document.body.append(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
      }
    } catch (e) {
      VF.toast('Copy failed. Your browser blocked clipboard access.', 'error');
      return false;
    }
    const seconds = Number(document.body.dataset.clipboardSeconds || 0);
    if (sensitive && seconds > 0) {
      clipboardDirty = true;
      clearTimeout(clipboardTimer);
      clipboardTimer = setTimeout(VF.clearClipboard, seconds * 1000);
      VF.toast(`${label}. Clipboard clears in ${seconds}s.`, 'success', 2500);
    } else {
      VF.toast(label + '.', 'success', 2000);
    }
    return true;
  };
  VF.clearClipboard = () => {
    if (!clipboardDirty) return;
    clipboardDirty = false;
    clearTimeout(clipboardTimer);
    if (navigator.clipboard && document.hasFocus()) navigator.clipboard.writeText('').catch(() => {});
  };

  // ------------------------------------------------------------ dialogs
  VF.confirm = ({ title, message, confirmText = 'Confirm', danger = false }) => new Promise((resolve) => {
    const ok = VF.h('button', { type: 'button', class: danger ? 'btn btn-danger' : 'btn btn-primary', text: confirmText });
    const cancel = VF.h('button', { type: 'button', class: 'btn btn-ghost', text: 'Cancel' });
    const dlg = VF.h('dialog', { class: 'dialog confirm-dialog', 'aria-labelledby': 'confirm-title' },
      VF.h('div', { class: 'dialog-head' }, VF.h('h2', { id: 'confirm-title', text: title })),
      VF.h('div', { class: 'dialog-body' }, VF.h('p', { text: message })),
      VF.h('div', { class: 'dialog-foot' }, cancel, ok));
    let result = false;
    ok.addEventListener('click', () => { result = true; dlg.close(); });
    cancel.addEventListener('click', () => dlg.close());
    dlg.addEventListener('close', () => { dlg.remove(); resolve(result); });
    document.body.append(dlg);
    dlg.showModal();
    cancel.focus();
  });

  // ------------------------------------------------------------ strength (mirror of StrengthEstimator.php)
  const COMMON = ['password', 'passw0rd', 'qwerty', 'letmein', 'welcome', 'admin', 'iloveyou', 'monkey', 'dragon',
    'football', 'baseball', 'master', 'login', 'abc123', '123456', '111111', '000000', 'sunshine',
    'princess', 'trustno1', 'superman', 'starwars', 'shadow', 'secret', 'hello', 'freedom',
    'whatever', 'qazwsx', 'asdf', 'zxcv', '1234', 'test', 'changeme'];
  const LABELS = ['Very weak', 'Weak', 'Fair', 'Strong', 'Very strong'];

  VF.strengthFromBits = (bits) => {
    const score = bits < 28 ? 0 : bits < 36 ? 1 : bits < 60 ? 2 : bits < 80 ? 3 : 4;
    return { bits, score, label: LABELS[score] };
  };

  VF.strength = (pw) => {
    const chars = Array.from(pw);
    const n = chars.length;
    if (n === 0) return { bits: 0, score: 0, label: LABELS[0] };
    let pool = 0;
    if (/[a-z]/.test(pw)) pool += 26;
    if (/[A-Z]/.test(pw)) pool += 26;
    if (/[0-9]/.test(pw)) pool += 10;
    if (/[\x20-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E]/.test(pw)) pool += 33;
    if (/[^\x00-\x7F]/.test(pw)) pool += 100;
    pool = Math.max(pool, 2);
    let penalty = 0;
    for (let i = 1; i < n; i++) {
      const a = chars[i - 1].codePointAt(0), b = chars[i].codePointAt(0);
      if (a === b) penalty += 1; else if (Math.abs(a - b) === 1) penalty += 0.5;
    }
    const lower = pw.replace(/[A-Z]/g, (c) => c.toLowerCase());
    for (const w of COMMON) if (lower.includes(w)) penalty += w.length - 1;
    const perChar = Math.log2(pool);
    let bits = Math.max(1, n - penalty) * perChar;
    bits = Math.min(bits, new Set(chars).size * 2 * perChar);
    return VF.strengthFromBits(Math.round(bits * 10) / 10);
  };

  VF.renderStrength = (container, result, note = '') => {
    if (!container) return;
    container.replaceChildren();
    container.className = `strength s${result.score}`;
    const bar = VF.h('div', { class: 'strength-bar', 'aria-hidden': 'true' });
    for (let i = 0; i < 5; i++) bar.append(VF.h('span', { class: i <= result.score ? 'on' : '' }));
    container.append(bar, VF.h('div', { class: 'strength-text' },
      VF.h('span', { class: 'strength-label', text: result.label }),
      VF.h('span', { text: `≈ ${Math.round(result.bits)} bits${note ? ' · ' + note : ''}` })));
  };

  // ------------------------------------------------------------ wipe sensitive UI state
  VF.wipers = [];
  VF.wipe = () => {
    VF.clearClipboard();
    VF.$$('[data-sensitive]').forEach((el) => { el.textContent = ''; });
    VF.$$('input[type="password"], input[data-secret]').forEach((el) => { el.value = ''; });
    VF.wipers.forEach((fn) => { try { fn(); } catch (e) { /* ignore */ } });
  };

  // ------------------------------------------------------------ generic behaviours
  function initGeneric() {
    VF.$$('.flash-data').forEach((el) => VF.toast(el.dataset.message, el.dataset.type || 'info', 6000));

    VF.$$('[data-toggle-visibility]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const input = document.getElementById(btn.dataset.toggleVisibility);
        if (!input) return;
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        btn.replaceChildren(VF.icon(show ? 'eye-off' : 'eye'));
      });
    });

    VF.$$('[data-strength-for]').forEach((meter) => {
      const input = document.getElementById(meter.dataset.strengthFor);
      if (!input) return;
      const update = () => (input.value ? VF.renderStrength(meter, VF.strength(input.value)) : meter.replaceChildren());
      input.addEventListener('input', update);
      meter.vfUpdate = update;
    });

    VF.$$('[data-match]').forEach((input) => {
      const other = document.getElementById(input.dataset.match);
      const hint = input.parentElement.querySelector('.match-hint');
      const check = () => {
        if (!hint) return;
        if (!input.value) { hint.textContent = ''; return; }
        const same = input.value === other.value;
        hint.textContent = same ? 'Passwords match.' : 'Passwords do not match.';
        hint.className = 'help match-hint ' + (same ? '' : 'warn');
        input.setCustomValidity(same ? '' : 'Passwords do not match.');
      };
      input.addEventListener('input', check);
      other.addEventListener('input', check);
    });

    VF.$$('form[data-loading]').forEach((form) => {
      form.addEventListener('submit', async (ev) => {
        if (form.dataset.confirmWhen) {
          const trigger = VF.$(form.dataset.confirmWhen);
          if (trigger && trigger.checked && form.dataset.confirmed !== '1') {
            ev.preventDefault();
            const ok = await VF.confirm({
              title: form.dataset.confirmTitle, message: form.dataset.confirmMessage,
              confirmText: form.dataset.confirmOk || 'Confirm', danger: true,
            });
            if (ok) { form.dataset.confirmed = '1'; form.requestSubmit(); }
            return;
          }
        }
        const btn = form.querySelector('button[type="submit"]');
        if (!btn) return;
        const label = btn.querySelector('span');
        const original = label ? label.textContent : '';
        setTimeout(() => { btn.disabled = true; }, 0);
        btn.classList.add('loading');
        if (label) label.textContent = form.dataset.loading;
        if (form.dataset.loadingReset) {
          setTimeout(() => {
            btn.disabled = false; btn.classList.remove('loading');
            if (label) label.textContent = original;
            form.dataset.confirmed = '';
            VF.$$('input[type="password"]', form).forEach((i) => { i.value = ''; });
            VF.$$('[data-strength-for]', form).forEach((m) => m.replaceChildren());
          }, Number(form.dataset.loadingReset));
        }
      });
    });

    // Retry countdown on the unlock page while throttled.
    VF.$$('[data-retry-after]').forEach((btn) => {
      let left = Number(btn.dataset.retryAfter);
      const label = btn.querySelector('span');
      const tick = () => {
        if (left <= 0) { btn.disabled = false; if (label) label.textContent = 'Unlock'; return; }
        if (label) label.textContent = `Try again in ${left}s`;
        left -= 1;
        setTimeout(tick, 1000);
      };
      tick();
    });

    // Restore form: show the overwrite warning only for "replace" mode.
    const replace = VF.$('#mode-replace');
    if (replace) {
      const warn = VF.$('#replace-warning');
      const confirmBox = VF.$('#confirm-replace');
      const sync = () => { warn.hidden = !replace.checked; confirmBox.required = replace.checked; };
      VF.$$('input[name="mode"]').forEach((r) => r.addEventListener('change', sync));
      sync();
    }

    // Pages restored from the back/forward cache must not show stale vault data.
    window.addEventListener('pageshow', (ev) => { if (ev.persisted) window.location.reload(); });
  }

  // ------------------------------------------------------------ sidebar
  function initSidebar() {
    const sidebar = VF.$('#sidebar');
    const btn = VF.$('#menu-btn');
    const backdrop = VF.$('#sidebar-backdrop');
    if (!sidebar || !btn) return;
    const set = (open) => {
      sidebar.classList.toggle('open', open);
      backdrop.hidden = !open;
      btn.setAttribute('aria-expanded', String(open));
    };
    btn.addEventListener('click', () => set(!sidebar.classList.contains('open')));
    backdrop.addEventListener('click', () => set(false));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') set(false); });
  }

  // ------------------------------------------------------------ auto-lock
  function initAutoLock() {
    if (document.body.dataset.unlocked !== '1') return;
    const idle = Math.max(10, Number(document.body.dataset.idleSeconds || 300));
    const pingEvery = Math.min(60, idle / 4) * 1000;
    const out = VF.$('#autolock-remaining');
    const box = out ? out.closest('.autolock') : null;
    let last = Date.now();
    let lastPing = Date.now();
    let locking = false;
    let warned = false;

    const activity = () => {
      last = Date.now();
      warned = false;
      if (Date.now() - lastPing > pingEvery) {
        lastPing = Date.now();
        VF.api('POST', '/api/ping').catch(() => {});
      }
    };
    ['pointerdown', 'keydown', 'mousemove', 'wheel', 'touchstart', 'input'].forEach((ev) =>
      window.addEventListener(ev, activity, { passive: true, capture: true }));

    VF.lockNow = (reason = 'manual') => {
      if (locking) return;
      locking = true;
      VF.wipe();
      const form = VF.$('#lock-form');
      VF.$('#lock-reason').value = reason;
      form.submit();
    };
    const lockForm = VF.$('#lock-form');
    if (lockForm) lockForm.addEventListener('submit', () => { locking = true; VF.wipe(); });

    const tick = () => {
      const remaining = Math.ceil(idle - (Date.now() - last) / 1000);
      if (out) {
        const r = Math.max(0, remaining);
        out.textContent = `${Math.floor(r / 60)}:${String(r % 60).padStart(2, '0')}`;
        box.classList.toggle('soon', r <= 30);
      }
      if (remaining <= 30 && !warned && idle > 45) {
        warned = true;
        VF.toast('VaultForge will lock in 30 seconds due to inactivity.', 'info', 5000);
      }
      if (remaining <= 0) VF.lockNow('idle');
    };
    tick();
    setInterval(tick, 1000);
  }

  document.addEventListener('DOMContentLoaded', () => {
    initGeneric();
    initSidebar();
    initAutoLock();
  });
})();
