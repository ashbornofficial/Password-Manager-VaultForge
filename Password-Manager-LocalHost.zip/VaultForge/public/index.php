<?php

/*
 * VaultForge front controller AND router script for PHP's built-in server:
 *
 *   php -S 127.0.0.1:8080 -t public public/index.php
 *
 * Every request (including /assets/*) is handled by the application, so the built-in
 * server never serves a file on its own. The storage/ directory is outside public/.
 */

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

VaultForge\App::create()->run();
