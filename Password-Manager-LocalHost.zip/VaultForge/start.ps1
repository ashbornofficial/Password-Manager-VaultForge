<#
.SYNOPSIS
  Start VaultForge on http://127.0.0.1:8080 (loopback only).
.PARAMETER Foreground
  Run in this console window (Ctrl+C to stop) instead of in the background.
.PARAMETER NoBrowser
  Do not open the browser automatically.
#>
param(
    [switch]$Foreground,
    [switch]$NoBrowser,
    [int]$Port = 8080
)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
. (Join-Path $Root 'scripts\php-env.ps1')

$php = Get-VFPhp
$phpArgs = Get-VFPhpArgs -Php $php -Root $Root
$storage = Join-Path $Root 'storage'
$logs = Join-Path $storage 'logs'
$pidFile = Join-Path $storage 'server.pid'
New-Item -ItemType Directory -Force -Path $logs | Out-Null

Write-Host "VaultForge - environment check" -ForegroundColor Cyan
& $php @phpArgs (Join-Path $Root 'bin\check.php')
if ($LASTEXITCODE -ne 0) { Write-Host 'Environment check failed; fix the items marked FAIL above.' -ForegroundColor Red; exit 1 }

if (Test-Path -LiteralPath $pidFile) {
    $old = Get-Process -Id ([int](Get-Content -LiteralPath $pidFile -Raw)) -ErrorAction SilentlyContinue
    if ($old -and $old.ProcessName -like 'php*') {
        Write-Host "VaultForge already appears to be running (PID $($old.Id)) at http://127.0.0.1:$Port" -ForegroundColor Yellow
        exit 0
    }
    Remove-Item -LiteralPath $pidFile -Force
}
$busy = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($busy) { Write-Host "Port $Port is already in use by PID $($busy[0].OwningProcess). Stop that program or use -Port." -ForegroundColor Red; exit 1 }

$env:VAULTFORGE_PORT = "$Port"
$public = Join-Path $Root 'public'
$router = Join-Path $public 'index.php'
$errorLog = Join-Path $logs 'php-error.log'
# Bind to 127.0.0.1 only - never 0.0.0.0.
$serverArgs = $phpArgs + @('-d', "error_log=$errorLog", '-S', "127.0.0.1:$Port", '-t', $public, $router)
$url = "http://127.0.0.1:$Port/"

if ($Foreground) {
    Write-Host "Serving $url  (Ctrl+C to stop)" -ForegroundColor Green
    if (-not $NoBrowser) { Start-Process $url }
    & $php @serverArgs
    exit $LASTEXITCODE
}

$argLine = ($serverArgs | ForEach-Object { Format-VFArg $_ }) -join ' '
$proc = Start-Process -FilePath $php -ArgumentList $argLine -WorkingDirectory $Root -WindowStyle Hidden -PassThru `
    -RedirectStandardOutput (Join-Path $logs 'server.out.log') -RedirectStandardError (Join-Path $logs 'server.log')
Set-Content -LiteralPath $pidFile -Value $proc.Id -Encoding ascii

$ready = $false
for ($i = 0; $i -lt 40; $i++) {
    Start-Sleep -Milliseconds 250
    if ($proc.HasExited) { break }
    if (Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) { $ready = $true; break }
}
if (-not $ready) {
    Write-Host 'The server did not start. See storage\logs\server.log' -ForegroundColor Red
    Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
    exit 1
}
Write-Host "VaultForge is running at $url (PID $($proc.Id)). Stop it with stop.ps1 or stop.bat." -ForegroundColor Green
if (-not $NoBrowser) { Start-Process $url }
