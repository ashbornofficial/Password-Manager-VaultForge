# VaultForge — private localhost password manager

VaultForge is a password generator and encrypted password vault that runs entirely on your
Windows PC. It is plain PHP 8.3+ with SQLite and libsodium, served by PHP's built-in server
on `http://127.0.0.1:8080`. No framework, no Node.js, no MySQL, no cloud, no CDN, no telemetry.

> **There is no password recovery.** The master password is never stored. If you forget it,
> the vault cannot be decrypted by anyone. Keep an encrypted backup and remember both passwords.


> **Repository hygiene:** This repository contains application source code and automated test source code. Runtime server logs, local vault databases, sessions, and backup files are intentionally excluded. Running the app creates local data under `storage/`; do not commit your real vault or backups.

---

## Requirements

| Requirement | Notes |
|---|---|
| Windows 10/11 | PowerShell 5.1+ (built in) |
| PHP 8.3 or newer | `php` on PATH, or set `VAULTFORGE_PHP` to the full path of `php.exe` |
| `sodium` extension | Argon2id + XChaCha20-Poly1305 (bundled with Windows PHP builds as `php_sodium.dll`) |
| `pdo_sqlite` extension | bundled as `php_pdo_sqlite.dll` |
| `mbstring` (optional) | Unicode-aware case-insensitive search |
| ~300 MB free RAM | Argon2id uses 256 MiB during unlock |
| Chrome, Edge or Firefox | |

The scripts start PHP with VaultForge's own `config/php-server.ini` (`php -c ...`) and only
the extensions it needs, so problems in your global `php.ini` (e.g. Herd's missing DLL
warnings) do not affect it.

## Quick start

```bash
start.bat
```

That runs the environment check, starts the server in the background on `127.0.0.1:8080`
and opens your browser. On first run you create the master password.

Stop the server:

```bash
stop.bat
```

PowerShell equivalents (the `.bat` files just call these with `-ExecutionPolicy Bypass` for that one process):

```bash
powershell -ExecutionPolicy Bypass -File .\start.ps1
```

```bash
powershell -ExecutionPolicy Bypass -File .\start.ps1 -Foreground
```

```bash
powershell -ExecutionPolicy Bypass -File .\stop.ps1
```

`start.ps1` options: `-Foreground` (run in the console, Ctrl+C to stop), `-NoBrowser`, `-Port <n>`.

Manual start without the scripts (from the project folder, with sodium and pdo_sqlite enabled in your php.ini):

```bash
php -S 127.0.0.1:8080 -t public public/index.php
```

Always bind to `127.0.0.1`, never `0.0.0.0`. Even if you do, the app refuses non-loopback
clients and unknown `Host` headers.

Environment check only:

```bash
php bin/check.php
```

> PHP's built-in server is a development server. It is fine for a single local user on
> loopback, which is the only way VaultForge is meant to run. Do not expose it to a network.

## Features

- **Generator**: 8–128 characters; uppercase / lowercase / digits / symbols; exclude
  ambiguous characters (`I l 1 | O 0 o ` ' " . , : ;`); custom character set; passphrases
  (3–20 words from a 2,797-word list, separators, capitalisation, number); exact entropy and
  strength meter; one-click copy; save straight to the vault. Generation happens server-side
  with `random_int()` (OS CSPRNG) and guarantees at least one character of every selected class.
- **Vault**: name, URL, username/email, password, notes, category, favourite, created/updated
  timestamps. Create, edit, delete (with confirmation), search, category filter, favourites,
  sort, reveal/hide (auto-hides after 30 s), copy username/password.
- **Dashboard**: total entries, favourites, categories, weak and reused password counts,
  recently updated entries, quick generator.
- **Auto-lock** after configurable inactivity (1–60 min), enforced by the server and the
  browser, plus a manual **Lock** button and a 12-hour absolute session limit.
- **Clipboard clearing** after N seconds (best effort, see limitations).
- **Change master password** (also rotates the data key and re-encrypts all entries).
- **Encrypted backup & restore** with a separate backup password, merge or replace modes,
  integrity verification before anything changes, and an automatic safety snapshot before replace.

## Security design

### Key hierarchy

```
master password ──Argon2id (random 16-byte salt, 3 passes, 256 MiB)──► KEK   (never stored)
KEK ──XChaCha20-Poly1305──► wrapped DEK                                      (vault_meta)
DEK (random 256-bit) ──XChaCha20-Poly1305──► every encrypted entry field     (entries)
```

- The master password is verified **cryptographically**: unwrapping the DEK only succeeds
  (Poly1305 tag check) with the right KEK. No password hash or verifier is stored.
- KDF parameters and salt are bound into the wrapped key's associated data.
- Every ciphertext is `"VF1" || 24-byte random nonce || ciphertext+tag`, and its associated
  data binds it to the entry's random uid and field name, so ciphertexts cannot be swapped
  between rows or fields without detection.
- No hard-coded keys, no fixed salts, no recovery key, no backdoor.

### What is encrypted, what is not

| Encrypted (per field, authenticated) | Plaintext metadata |
|---|---|
| name, URL, username, category (one JSON blob) | number of entries, row ids, random uids |
| password | favourite flag |
| notes (always present, so "has notes" is not revealed) | created / updated timestamps |
| | KDF parameters + salt, preferences, login-throttle counters |

**SQLite itself is not encrypted.** Individual sensitive fields are encrypted by the application.
SQLite CHECK constraints refuse anything other than a `VF1…` BLOB in secret columns, as a
last line of defence against accidental plaintext writes. `PRAGMA secure_delete` overwrites
deleted content.

### While unlocked

The DEK must survive between requests. It is split so neither half is useful alone:

- the PHP session file (in `storage/sessions/`) holds the DEK encrypted with a random per-unlock key;
- that key lives only in the `VFKEY` cookie (HttpOnly, SameSite=Strict, never in JS, URLs or Web Storage).

Locking (manual, idle, absolute timeout) wipes the session, deletes the session file,
regenerates the session ID and expires the cookie. Replaying old cookies does not work.

### Web hardening

- Loopback-only and `Host` header allow-list (blocks LAN access and DNS rebinding).
- CSRF token on every state-changing request and on all API calls; `Origin` and
  `Sec-Fetch-Site` checks (this also blocks other websites on other localhost ports).
- Strict CSP: `default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; ...`.
  No inline scripts or styles anywhere. Plus `X-Frame-Options: DENY`, `nosniff`,
  `Referrer-Policy: same-origin`, COOP/CORP/COEP, `Cache-Control: no-store`.
- Sessions: strict mode, cookies only, HttpOnly, SameSite=Strict, ID regenerated on unlock,
  lock and password change. The `Secure` flag is set automatically when served over HTTPS; on
  plain `http://127.0.0.1` it cannot be set, which is acceptable because traffic never leaves the machine.
- Output escaping in templates (`e()`); the front-end only inserts data with `textContent`.
- Server-side validation of every input (types, lengths, UTF-8, URL schemes limited to http/https).
- Master-password throttling: after 5 consecutive failures, lockout of 30 s doubling up to
  15 min, shared by unlock, backup export and password change, persisted in SQLite.
- PDO prepared statements for every query with user input; transactions for multi-step changes.
- Logs (`storage/logs/app.log`) contain event names only, never passwords, keys or vault data.
  `zend.exception_ignore_args` and `#[\SensitiveParameter]` keep secrets out of stack traces.
- The router (`public/index.php`) handles every request, so the built-in server never serves
  files itself; assets come only from `public/assets` with an extension allow-list; `storage/`
  is outside the web root.

### Backups

`.vfbackup` files are JSON: a plaintext header (format, version, date, entry count, cipher,
Argon2id parameters and salt) and the XChaCha20-Poly1305 ciphertext of all entries. The key
comes from a **separate backup password** (at least 12 characters, must differ from the master
password). The whole header is authenticated, so modifying any byte is detected. On restore
the file is size-checked, structure-checked, KDF parameters are range-checked (so a malicious
file cannot demand absurd memory), fully decrypted and every entry is validated **before**
anything is written. Plaintext export is not offered at all.

To move to a new PC: install, create a new vault, restore the backup (merge or replace).

### Limitations (read these)

- Anyone who can run code as your Windows user while the vault is unlocked can read it
  (malware, a malicious browser extension). VaultForge protects data at rest and in the browser
  sandbox, not against a compromised OS.
- An attacker with a copy of `vault.sqlite` can attempt an offline guessing attack; Argon2id
  makes each guess expensive, but a weak master password is still weak.
- The login throttle only protects the running app.
- Clipboard clearing is best effort: browsers only allow writing the clipboard while the
  VaultForge tab has focus, and clipboard-history tools (Win+V) may keep copies.
- PHP strings cannot be reliably wiped from memory; keys are zeroed with `sodium_memzero`
  where practical.

## Security checklist

- [x] Server bound to 127.0.0.1 only; non-loopback clients and foreign Host headers refused
- [x] No external requests: no CDNs, remote fonts, analytics or update checks (CSP `connect-src 'self'`)
- [x] Database in `storage/`, outside `public/`; never downloadable (tested with traversal attempts)
- [x] Master password never stored; Argon2id with random salt; separate random DEK
- [x] XChaCha20-Poly1305 authenticated encryption with context-bound associated data
- [x] Cryptographic master-password verification; no recovery key or backdoor
- [x] CHECK constraints block plaintext in secret columns; raw DB scanned in tests
- [x] Prepared statements everywhere; transactions for multi-step changes; versioned migrations
- [x] Corrupted / inaccessible / newer-version databases detected and never overwritten
- [x] Secure sessions; ID regeneration; CSRF + Origin + Fetch-Metadata checks
- [x] Strict CSP and security headers; no inline JS/CSS; output escaping
- [x] Server-side validation of all input
- [x] Login throttling with exponential lockout
- [x] Server- and client-enforced auto-lock; manual lock wipes session and key cookie
- [x] No secrets in URLs, localStorage, sessionStorage or logs
- [x] Encrypted, integrity-checked backups with separate password; tampered files rejected
- [ ] **You**: choose a strong master password (5+ random words) and keep an offline backup
- [ ] **You**: keep Windows, your browser and PHP updated; use full-disk encryption (BitLocker)

## Tests

```bash
powershell -ExecutionPolicy Bypass -File .\run-tests.ps1
```

Run a subset by name: `.\run-tests.ps1 backup`.

The suite (no PHPUnit or Composer needed) has unit tests and an end-to-end HTTP suite that
starts real servers on `127.0.0.1:8099` / `8098` with temporary storage and the production
KDF parameters. It covers:

- PHP version / extensions (`bin/check.php`), migrations, corrupted database handling
- first-run setup, correct and incorrect master passwords, password policy, session-ID regeneration
- generator rules (2,000 random configurations, custom sets, passphrases, bias check)
- CRUD, search, category filter, favourites, validation, XSS payloads
- **raw database and session files scanned for plaintext** (passwords, notes, names, usernames, master password)
- ciphertext swapping between rows/fields detected; key rotation on master-password change
- CSRF, Origin, Sec-Fetch-Site, Host-header and loopback guards; security headers; path traversal
- manual lock, replay of old cookies, missing key cookie, idle auto-lock and keep-alive, login throttling
- encrypted backup export/restore, wrong password, tampered ciphertext/header/structure, merge/replace
- no external URLs in shipped HTML/CSS/JS; source files UTF-8 without BOM

Inspect the database yourself:

```bash
php bin/inspect-db.php
```

```bash
php bin/inspect-db.php --find "a password you saved"
```

(Run these with the same PHP flags the scripts use if your global php.ini lacks sodium/pdo_sqlite.)

## Project structure

```
public/            web root: index.php (router + front controller), assets/{css,js,img}
src/
  App.php          request pipeline, routing, access guards
  Auth/            key hierarchy (VaultKeyService), password policy, throttled verification
  Vault/           entry repository (SQL), service (encryption, search, import), validator
  Generator/       password + passphrase generators, strength estimator, word list
  Backup/          encrypted backup format
  Security/        Crypto (libsodium), sessions, CSRF, rate limiter, headers, host guard
  Database/        connection checks, migrator, migrations/
  Http/ Controllers/ Settings/ Support/
templates/         PHP templates (layouts, pages, partials)
config/            config.php, php-server.ini
storage/           vault.sqlite, sessions/, logs/, backups/  (created at runtime, git-ignored)
bin/               check.php, inspect-db.php
scripts/           php-env.ps1 (shared by the PowerShell scripts)
tests/             run.php, lib/, Unit/, Integration/
start.ps1 stop.ps1 start.bat stop.bat run-tests.ps1
```

## Troubleshooting

| Problem | Fix |
|---|---|
| "PHP was not found" | Add PHP to PATH or set `VAULTFORGE_PHP=C:\path\to\php.exe` |
| Extension missing | Ensure `ext\php_sodium.dll` and `ext\php_pdo_sqlite.dll` exist next to `php.exe` |
| Port 8080 in use | `start.ps1 -Port 8081` (then open `http://127.0.0.1:8081`) |
| "Storage problem" page | Read the message; it never overwrites a damaged database. Check `storage/` permissions |
| Locked out after failed attempts | Wait for the countdown (max 15 minutes) |
| Forgot master password | Not recoverable. Restore an encrypted backup into a new vault (move `storage/vault.sqlite` aside first) |

Icons adapted from Feather Icons (MIT licence).
