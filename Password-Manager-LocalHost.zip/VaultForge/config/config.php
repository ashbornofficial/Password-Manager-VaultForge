<?php

declare(strict_types=1);

/*
 * VaultForge configuration. Nothing in this file is secret.
 *
 * Environment overrides (used by the test-suite; normally leave unset):
 *   VAULTFORGE_STORAGE       absolute path of the data directory
 *   VAULTFORGE_PORT          port of the local server (default 8080)
 *   VAULTFORGE_IDLE_SECONDS  force the auto-lock timeout in seconds
 */

$port = (int) (getenv('VAULTFORGE_PORT') ?: 8080);
$idleOverride = getenv('VAULTFORGE_IDLE_SECONDS');

return [
    'app_name' => 'VaultForge',
    'version' => '1.0.0',

    'host' => '127.0.0.1',
    'port' => $port,
    // Host headers the app answers to. Anything else is refused (DNS-rebinding protection).
    'allowed_hosts' => ["127.0.0.1:$port", "localhost:$port"],

    // Data directory: must live outside public/.
    'storage_path' => getenv('VAULTFORGE_STORAGE') ?: dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage',

    // Argon2id parameters for newly derived keys (libsodium "MODERATE": 3 passes, 256 MiB).
    // Existing vaults keep the parameters stored with them until the master password is changed.
    'kdf' => [
        'opslimit' => 3,
        'memlimit' => 268435456,
    ],

    'session' => [
        // Hard limit on how long one unlock lasts, regardless of activity.
        'absolute_lifetime' => 12 * 3600,
        'idle_override_seconds' => ($idleOverride !== false && ctype_digit($idleOverride)) ? (int) $idleOverride : null,
    ],

    'auto_lock' => ['default_minutes' => 5, 'min_minutes' => 1, 'max_minutes' => 60],
    'clipboard' => ['default_seconds' => 30, 'max_seconds' => 300],

    // Master password throttling: after max_attempts consecutive failures, lock out for
    // base_lockout * 2^(n - max_attempts) seconds, capped at max_lockout.
    'login' => ['max_attempts' => 5, 'base_lockout' => 30, 'max_lockout' => 900],

    'passwords' => ['master_min_length' => 12, 'master_min_bits' => 50, 'backup_min_length' => 12],

    'backup' => ['max_bytes' => 16 * 1024 * 1024],
];
