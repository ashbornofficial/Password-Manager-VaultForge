# CLAUDE.md — VaultForge

Private localhost password manager: PHP 8.3+, SQLite (PDO), libsodium, vanilla JS. Runs only
on `http://127.0.0.1:8080` through PHP's built-in server. See README.md for user docs and the
full security design.

## Commands (Windows PowerShell)

- Start: `.\start.ps1` (`-Foreground`, `-NoBrowser`, `-Port n`). Stop: `.\stop.ps1`.
- Tests: `.\run-tests.ps1 [filter]`. Must stay green; run before declaring work done.
- Env check: run `bin/check.php` with the args from `scripts\php-env.ps1` (`Get-VFPhpArgs`).
- Always run PHP through `Get-VFPhpArgs`: the global (Herd) php.ini prints missing-DLL warnings;
  VaultForge uses `config/php-server.ini` via `-c` plus only `sodium`, `pdo_sqlite`, `mbstring`.
- UI testing: use a throwaway instance, never the user's real `storage/`:
  `$env:VAULTFORGE_STORAGE = '<scratch dir>'; .\start.ps1 -Port 8090 -NoBrowser`, then `.\stop.ps1 -Port 8090`.

## Architecture

- `public/index.php` is both router script and front controller; every request (assets too)
  goes through `VaultForge\App::handle()`: HostGuard → assets → DB open + migrate → session →
  auto-lock check → CSRF/Origin/Sec-Fetch-Site → route table with access guards
  (`setup` | `locked` | `unlocked` | `any`).
- Keys: master password → Argon2id → KEK → unwraps random DEK (`Auth/VaultKeyService`).
  DEK encrypts entry fields (`Vault/EntryService`); AEAD context strings bind ciphertext to
  `entry:v1:<uid>:<field>`. While unlocked, DEK is in the session encrypted with a key that lives
  only in the `VFKEY` HttpOnly cookie (`Security/SessionManager`).
- All master-password checks go through `Auth/MasterPasswordGate` (shared throttle).
- API: JSON under `/api/*`, always requires `X-CSRF-Token`. Forms post with `_csrf` and
  redirect with flash messages.

## Rules when changing code

- Never store or log plaintext secrets, keys or the master password. Logger takes scalar
  context only; mark password parameters `#[\SensitiveParameter]`.
- Secret columns must only receive `Crypto::encrypt()` output bound with `PDO::PARAM_LOB`
  (CHECK constraints enforce a `VF1` BLOB). Add new sensitive fields inside the encrypted meta
  JSON, not as plaintext columns.
- Schema changes: add `src/Database/migrations/NNN_name.php`; never edit shipped migrations.
- Changing the crypto format: bump the context/version strings (`v1`) and keep reading old data.
- No external URLs/CDNs/fonts; CSP forbids inline `<script>`/`style=""`. Insert data in JS
  with `textContent` / `VF.h()` only, never `innerHTML`.
- `StrengthEstimator.php` and `VF.strength()` in `public/assets/js/common.js` must stay in sync.
- Keep `Referrer-Policy: same-origin`: `no-referrer` makes Chromium send `Origin: null` on form
  POSTs, which the Origin check rejects (found during browser testing).
- Do not edit source files with PowerShell `Get-Content`/`Set-Content` (5.1 corrupts UTF-8 and
  adds a BOM); use the editor tools. `tests/Unit/SourceHygieneTest.php` guards against this.
