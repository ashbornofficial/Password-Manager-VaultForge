@echo off
rem Start VaultForge at http://127.0.0.1:8080 (execution policy bypass applies to this process only)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1" %*
