<?php

declare(strict_types=1);

use VaultForge\Generator\PassphraseGenerator;
use VaultForge\Generator\PasswordGenerator;
use VaultForge\Generator\StrengthEstimator;
use VaultForge\Support\Str;
use function VaultForge\Tests\{eq, ok, test, throws};

test('generated passwords always satisfy the selected rules (2000 random configurations)', function () {
    $gen = new PasswordGenerator();
    $sets = PasswordGenerator::SETS;
    $ambiguous = str_split(PasswordGenerator::AMBIGUOUS);
    for ($i = 0; $i < 2000; $i++) {
        $opts = [
            'length' => random_int(8, 128),
            'upper' => (bool) random_int(0, 1),
            'lower' => (bool) random_int(0, 1),
            'digits' => (bool) random_int(0, 1),
            'symbols' => (bool) random_int(0, 1),
            'exclude_ambiguous' => (bool) random_int(0, 1),
        ];
        if (!$opts['upper'] && !$opts['lower'] && !$opts['digits'] && !$opts['symbols']) {
            $opts['lower'] = true;
        }
        $pw = $gen->generate($opts)['password'];
        eq($opts['length'], strlen($pw), 'length');
        $allowed = '';
        foreach ($sets as $name => $chars) {
            if ($opts[$name]) {
                $allowed .= $chars;
                ok(strpbrk($pw, $opts['exclude_ambiguous'] ? str_replace($ambiguous, '', $chars) : $chars) !== false, "missing required class $name in $pw");
            }
        }
        foreach (str_split($pw) as $c) {
            ok(str_contains($allowed, $c), "character outside pool: $c");
            ok(!$opts['exclude_ambiguous'] || !in_array($c, $ambiguous, true), "ambiguous char $c present");
        }
    }
});

test('custom character set is respected (including Unicode)', function () {
    $gen = new PasswordGenerator();
    for ($i = 0; $i < 200; $i++) {
        $r = $gen->generate(['length' => 40, 'custom' => 'ab c€é']);
        $chars = Str::chars($r['password']);
        eq(40, count($chars));
        foreach ($chars as $c) {
            ok(in_array($c, ['a', 'b', 'c', '€', 'é'], true), "unexpected $c");
        }
    }
    eq(6, $gen->generate(['length' => 8, 'custom' => 'aabbccdd€é '])['pool_size'], 'a b c d € é (dupes and space removed)');
    throws(\InvalidArgumentException::class, fn () => $gen->generate(['length' => 12, 'custom' => 'aaaa']));
    throws(\InvalidArgumentException::class, fn () => $gen->generate(['length' => 12, 'custom' => 'Il1', 'exclude_ambiguous' => true]));
});

test('invalid generator options are rejected', function () {
    $gen = new PasswordGenerator();
    throws(\InvalidArgumentException::class, fn () => $gen->generate(['length' => 7, 'lower' => true]));
    throws(\InvalidArgumentException::class, fn () => $gen->generate(['length' => 129, 'lower' => true]));
    throws(\InvalidArgumentException::class, fn () => $gen->generate(['length' => 16]));
    eq(8, strlen($gen->generate(['length' => 8, 'upper' => true, 'lower' => true, 'digits' => true, 'symbols' => true])['password']));
    eq(128, strlen($gen->generate(['length' => 128, 'digits' => true])['password']));
});

test('generated passwords are not repeated and use the whole pool', function () {
    $gen = new PasswordGenerator();
    $seen = [];
    $counts = array_fill_keys(str_split('0123456789'), 0);
    for ($i = 0; $i < 500; $i++) {
        $pw = $gen->generate(['length' => 20, 'digits' => true])['password'];
        $seen[$pw] = true;
        foreach (str_split($pw) as $c) {
            $counts[$c]++;
        }
    }
    eq(500, count($seen));
    foreach ($counts as $digit => $n) {
        ok($n > 800 && $n < 1200, "digit $digit frequency $n looks biased");
    }
});

test('passphrases follow word count, separator and options', function () {
    $gen = new PassphraseGenerator();
    $words = PassphraseGenerator::wordlist();
    ok(count($words) >= 1024, 'word list size');
    eq(count($words), count(array_unique($words)), 'word list unique');
    $r = $gen->generate(6, 'hyphen');
    $parts = explode('-', $r['password']);
    eq(6, count($parts));
    foreach ($parts as $p) {
        ok(in_array($p, $words, true), "unknown word $p");
    }
    ok($r['entropy'] > 60);
    $c = $gen->generate(4, 'space', true, true);
    $parts = explode(' ', $c['password']);
    eq(4, count($parts));
    ok(preg_match('/^[A-Z]/', $parts[0]) === 1, 'capitalised');
    eq(1, preg_match_all('/\d/', $c['password']), 'exactly one digit');
    eq(1, count(explode('-', $gen->generate(3, 'none')['password'])));
    ok(preg_match('/^[a-z]+\d[a-z]+\d[a-z]+$/', $gen->generate(3, 'digit')['password']) === 1);
    throws(\InvalidArgumentException::class, fn () => $gen->generate(2));
    throws(\InvalidArgumentException::class, fn () => $gen->generate(21));
    throws(\InvalidArgumentException::class, fn () => $gen->generate(5, 'emoji'));
});

test('strength estimator ranks obvious cases sensibly', function () {
    ok(StrengthEstimator::estimate('password')['score'] === 0);
    ok(StrengthEstimator::estimate('12345678')['score'] === 0);
    ok(StrengthEstimator::estimate('aaaaaaaaaaaaaaaaaaaa')['score'] === 0);
    ok(StrengthEstimator::estimate('Tr0ub4dor&3')['score'] >= 2);
    $gen = (new PasswordGenerator())->generate(['length' => 24, 'upper' => true, 'lower' => true, 'digits' => true, 'symbols' => true]);
    eq(4, StrengthEstimator::estimate($gen['password'])['score']);
    eq(0.0, StrengthEstimator::estimate('')['bits']);
});
