<?php

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

use VaultForge\Auth\InvalidMasterPasswordException;
use VaultForge\Auth\PasswordPolicy;
use VaultForge\Database\Migrator;
use VaultForge\Database\StorageException;
use VaultForge\Database\Connection;
use VaultForge\Security\RateLimiter;
use function VaultForge\Tests\{contains, eq, freshDb, keys, notContains, ok, tempDir, test, throws};

test('first-run setup creates a vault that unlocks only with the correct password', function () {
    [$db, $path] = freshDb();
    $keys = keys($db);
    ok(!$keys->isInitialized());
    $dek = $keys->initialize('Correct-Horse-Battery-42');
    ok($keys->isInitialized());
    eq(32, strlen($dek));
    eq($dek, $keys->unlock('Correct-Horse-Battery-42'), 'correct password returns the same DEK');
    throws(InvalidMasterPasswordException::class, fn () => $keys->unlock('Correct-Horse-Battery-43'));
    throws(InvalidMasterPasswordException::class, fn () => $keys->unlock(''));
    throws(\LogicException::class, fn () => $keys->initialize('Another-Password-123'), 'second setup refused');

    $raw = file_get_contents($path);
    notContains('Correct-Horse-Battery-42', $raw, 'master password must not be stored');
    notContains($dek, $raw, 'raw DEK must not be stored');
    notContains(bin2hex($dek), $raw);
});

test('every vault gets a unique random salt and wrapped key', function () {
    [$db1] = freshDb();
    [$db2] = freshDb();
    keys($db1)->initialize('Same-Password-For-Both-1');
    keys($db2)->initialize('Same-Password-For-Both-1');
    $m1 = $db1->query('SELECT kdf_salt, wrapped_dek FROM vault_meta')->fetch();
    $m2 = $db2->query('SELECT kdf_salt, wrapped_dek FROM vault_meta')->fetch();
    eq(16, strlen($m1['kdf_salt']));
    ok($m1['kdf_salt'] !== $m2['kdf_salt']);
    ok($m1['wrapped_dek'] !== $m2['wrapped_dek']);
});

test('tampering with stored KDF parameters breaks unlocking', function () {
    [$db] = freshDb();
    $keys = keys($db);
    $keys->initialize('Tamper-Test-Password-9');
    $db->exec('UPDATE vault_meta SET kdf_opslimit = 3');
    throws(InvalidMasterPasswordException::class, fn () => $keys->unlock('Tamper-Test-Password-9'));
    $db->exec('UPDATE vault_meta SET kdf_opslimit = 99');
    throws(StorageException::class, fn () => $keys->unlock('Tamper-Test-Password-9'));
});

test('rewrap changes salt and keeps the DEK', function () {
    [$db] = freshDb();
    $keys = keys($db);
    $dek = $keys->initialize('Old-Master-Password-1');
    $saltBefore = $db->query('SELECT kdf_salt FROM vault_meta')->fetchColumn();
    $keys->rewrap('New-Master-Password-2', $dek);
    ok($saltBefore !== $db->query('SELECT kdf_salt FROM vault_meta')->fetchColumn());
    eq($dek, $keys->unlock('New-Master-Password-2'));
    throws(InvalidMasterPasswordException::class, fn () => $keys->unlock('Old-Master-Password-1'));
});

test('master password policy', function () {
    $p = new PasswordPolicy(12, 50, 12);
    ok($p->checkMaster('short', 'short') !== null, 'too short');
    ok($p->checkMaster('aaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaa') !== null, 'repetitive');
    ok($p->checkMaster('Password1234', 'Password1234') !== null, 'common');
    ok($p->checkMaster('river-copper-violin-42', 'river-copper-violin-43') !== null, 'mismatch');
    eq(null, $p->checkMaster('river-copper-violin-42', 'river-copper-violin-42'));
    contains('different', (string) $p->checkBackup('river-copper-violin-42', 'river-copper-violin-42', 'river-copper-violin-42'));
});

test('rate limiter locks out with exponential backoff and resets', function () {
    [$db] = freshDb();
    $l = new RateLimiter($db, 3, 30, 900);
    $l->recordFailure();
    $l->recordFailure();
    eq(0, $l->retryAfter(), 'no lockout before the limit');
    $l->recordFailure();
    ok($l->retryAfter() > 25 && $l->retryAfter() <= 30, 'first lockout ~30s');
    $l->recordFailure();
    ok($l->retryAfter() > 55, 'second lockout ~60s');
    for ($i = 0; $i < 10; $i++) {
        $l->recordFailure();
    }
    ok($l->retryAfter() <= 900, 'capped at max lockout');
    $l->reset();
    eq(0, $l->retryAfter());
    eq(0, $l->failures());
});

test('migrations are idempotent and newer schemas are refused', function () {
    [$db] = freshDb();
    $m = new Migrator($db, VF_ROOT . '/src/Database/migrations');
    eq([], $m->migrate(), 'second run applies nothing');
    eq(1, $m->currentVersion());
    $db->exec("INSERT INTO schema_migrations (version, name, applied_at) VALUES (999, 'future', '2030-01-01T00:00:00Z')");
    throws(StorageException::class, fn () => $m->migrate());
});

test('corrupted or non-SQLite database files are refused, not overwritten', function () {
    $dir = tempDir('vf-corrupt');
    $path = $dir . DIRECTORY_SEPARATOR . 'vault.sqlite';
    $junk = random_bytes(4096);
    file_put_contents($path, $junk);
    $e = throws(StorageException::class, fn () => Connection::open($path));
    eq('db_corrupt', $e->kind);
    eq($junk, file_get_contents($path), 'file left untouched');
});

test('database CHECK constraints reject plaintext in secret columns', function () {
    [$db] = freshDb();
    $stmt = $db->prepare("INSERT INTO entries (uid, meta_ct, password_ct, notes_ct, favorite, created_at, updated_at)
        VALUES (:uid, :m, :p, :n, 0, 'x', 'x')");
    throws(\PDOException::class, fn () => $stmt->execute([
        ':uid' => str_repeat('a', 32), ':m' => 'plain meta', ':p' => 'hunter2-plaintext-password', ':n' => 'notes',
    ]), 'TEXT values must be rejected');
    $long = 'VF1' . str_repeat('x', 60); // right prefix but bound as TEXT
    throws(\PDOException::class, fn () => $stmt->execute([':uid' => str_repeat('b', 32), ':m' => $long, ':p' => $long, ':n' => $long]));
    eq(0, (int) $db->query('SELECT COUNT(*) FROM entries')->fetchColumn());
});
