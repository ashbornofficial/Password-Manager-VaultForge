<?php

declare(strict_types=1);

use VaultForge\Security\Crypto;
use VaultForge\Security\DecryptionException;
use function VaultForge\Tests\{eq, ok, test, throws};

test('encrypt/decrypt round trip with fresh nonces', function () {
    $key = Crypto::newKey();
    $a = Crypto::encrypt('secret value', $key, 'ctx');
    $b = Crypto::encrypt('secret value', $key, 'ctx');
    ok($a !== $b, 'two encryptions of the same plaintext must differ (random nonce)');
    ok(str_starts_with($a, 'VF1'), 'magic prefix');
    eq(3 + 24 + strlen('secret value') + 16, strlen($a), 'ciphertext layout');
    eq('secret value', Crypto::decrypt($a, $key, 'ctx'));
});

test('tampered ciphertext, wrong key and wrong context are rejected', function () {
    $key = Crypto::newKey();
    $blob = Crypto::encrypt('top secret', $key, 'entry:1:password');
    for ($i = 3; $i < strlen($blob); $i += 7) {
        $t = $blob;
        $t[$i] = chr(ord($t[$i]) ^ 0x01);
        throws(DecryptionException::class, fn () => Crypto::decrypt($t, $key, 'entry:1:password'), "flip at byte $i");
    }
    throws(DecryptionException::class, fn () => Crypto::decrypt($blob, Crypto::newKey(), 'entry:1:password'));
    throws(DecryptionException::class, fn () => Crypto::decrypt($blob, $key, 'entry:2:password'));
    throws(DecryptionException::class, fn () => Crypto::decrypt(substr($blob, 0, 30), $key, 'entry:1:password'));
    throws(DecryptionException::class, fn () => Crypto::decrypt('XX1' . substr($blob, 3), $key, 'entry:1:password'));
});

test('Argon2id derivation is deterministic per salt and differs across salts', function () {
    $salt = Crypto::newSalt();
    $k1 = Crypto::deriveKey('correct horse', $salt, 2, 64 * 1024 * 1024);
    $k2 = Crypto::deriveKey('correct horse', $salt, 2, 64 * 1024 * 1024);
    $k3 = Crypto::deriveKey('correct horse', Crypto::newSalt(), 2, 64 * 1024 * 1024);
    $k4 = Crypto::deriveKey('correct horsf', $salt, 2, 64 * 1024 * 1024);
    eq(32, strlen($k1));
    eq($k1, $k2);
    ok($k1 !== $k3 && $k1 !== $k4);
});

test('KDF parameters outside safe bounds are refused', function () {
    throws(\InvalidArgumentException::class, fn () => Crypto::deriveKey('x', Crypto::newSalt(), 50, 64 * 1024 * 1024));
    throws(\InvalidArgumentException::class, fn () => Crypto::deriveKey('x', Crypto::newSalt(), 2, 8 * 1024 * 1024 * 1024));
    throws(\InvalidArgumentException::class, fn () => Crypto::deriveKey('x', 'short', 2, 64 * 1024 * 1024));
});
