<?php

declare(strict_types=1);

namespace VaultForge\Tests;

use PDO;
use VaultForge\Auth\VaultKeyService;
use VaultForge\Database\Connection;
use VaultForge\Database\Migrator;

const FAST_OPS = 2;
const FAST_MEM = 67108864; // 64 MiB keeps unit tests fast; HTTP tests use the real parameters.

/** @return array{PDO, string} migrated database and its file path */
function freshDb(): array
{
    $path = tempDir('vf-unit') . DIRECTORY_SEPARATOR . 'vault.sqlite';
    $db = Connection::open($path);
    (new Migrator($db, VF_ROOT . '/src/Database/migrations'))->migrate();
    return [$db, $path];
}

function keys(PDO $db): VaultKeyService
{
    return new VaultKeyService($db, FAST_OPS, FAST_MEM);
}
