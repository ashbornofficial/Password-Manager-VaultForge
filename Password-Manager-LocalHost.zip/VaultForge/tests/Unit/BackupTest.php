<?php

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

use VaultForge\Backup\BackupException;
use VaultForge\Backup\BackupService;
use VaultForge\Vault\EntryRepository;
use VaultForge\Vault\EntryService;
use function VaultForge\Tests\{contains, eq, freshDb, keys, notContains, ok, test, throws};

const BK_OPS = 2;
const BK_MEM = 67108864;

function sampleEntries(): array
{
    [$db] = freshDb();
    $svc = new EntryService(new EntryRepository($db), keys($db)->initialize('Backup-Test-Master-1'));
    $svc->create(['name' => 'Mail', 'username' => 'me@example.com', 'password' => 'BackupCanary-77!', 'notes' => 'line1' . "\n" . 'line2', 'category' => 'Email', 'favorite' => true]);
    $svc->create(['name' => 'Ünïcødé ✓', 'password' => 'pässwörd-€', 'category' => 'Other']);
    return $svc->exportAll();
}

test('backup round trip restores identical data', function () {
    $entries = sampleEntries();
    $bs = new BackupService(BK_OPS, BK_MEM, 1 << 24);
    $file = $bs->create($entries, 'backup-password-123');
    notContains('BackupCanary-77!', $file, 'no plaintext in backup');
    notContains('me@example.com', $file);
    contains('"format": "vaultforge-backup"', $file);
    $restored = $bs->decrypt($bs->parse($file), 'backup-password-123');
    eq($entries, $restored);
});

test('wrong backup password is rejected', function () {
    $bs = new BackupService(BK_OPS, BK_MEM, 1 << 24);
    $file = $bs->create(sampleEntries(), 'backup-password-123');
    $e = throws(BackupException::class, fn () => $bs->decrypt($bs->parse($file), 'backup-password-124'));
    contains('Wrong backup password', $e->getMessage());
});

test('tampered backups are rejected (ciphertext, header fields, structure)', function () {
    $bs = new BackupService(BK_OPS, BK_MEM, 1 << 24);
    $file = $bs->create(sampleEntries(), 'backup-password-123');
    $doc = json_decode($file, true);
    $try = static function (array $d) use ($bs): void {
        $bs->decrypt($bs->parse(json_encode($d)), 'backup-password-123');
    };

    $ct = base64_decode($doc['ciphertext']);
    $ct[40] = chr(ord($ct[40]) ^ 0x80);
    throws(BackupException::class, fn () => $try(['ciphertext' => base64_encode($ct)] + $doc), 'flipped ciphertext bit');

    throws(BackupException::class, fn () => $try(['entry_count' => 1] + $doc), 'header entry_count changed');
    throws(BackupException::class, fn () => $try(['created_at' => '2001-01-01T00:00:00Z'] + $doc), 'header date changed');
    $kdf = $doc['kdf'];
    $kdf['opslimit'] = 3;
    throws(BackupException::class, fn () => $try(['kdf' => $kdf] + $doc), 'kdf params changed');
    $kdf = $doc['kdf'];
    $kdf['memlimit'] = 8 * 1024 * 1024 * 1024;
    throws(BackupException::class, fn () => $try(['kdf' => $kdf] + $doc), 'absurd memlimit refused before derivation');
    throws(BackupException::class, fn () => $try($doc + ['extra' => 1]), 'unexpected key');
    throws(BackupException::class, fn () => $try(['version' => 2] + $doc));
    throws(BackupException::class, fn () => $try(['format' => 'other'] + $doc));
    throws(BackupException::class, fn () => $try(['ciphertext' => '!!!notbase64'] + $doc));
    throws(BackupException::class, fn () => $bs->parse('not json at all'));
    throws(BackupException::class, fn () => $bs->parse(''));
    throws(BackupException::class, fn () => $bs->parse(substr($file, 0, 100)), 'truncated');
    throws(BackupException::class, fn () => (new BackupService(BK_OPS, BK_MEM, 50))->parse($file), 'too large');
});

test('backup with invalid entries inside is rejected', function () {
    $bs = new BackupService(BK_OPS, BK_MEM, 1 << 24);
    $bad = [['name' => '', 'url' => '', 'username' => '', 'password' => 'x', 'notes' => '', 'category' => 'General', 'favorite' => false,
        'created_at' => '2026-01-01T00:00:00Z', 'updated_at' => '2026-01-01T00:00:00Z']];
    $file = $bs->create($bad, 'backup-password-123');
    $e = throws(BackupException::class, fn () => $bs->decrypt($bs->parse($file), 'backup-password-123'));
    contains('entry #1', $e->getMessage());
});

test('import merge skips duplicates; replace overwrites', function () {
    [$db] = freshDb();
    $svc = new EntryService(new EntryRepository($db), keys($db)->initialize('Import-Test-Master-1'));
    $svc->create(['name' => 'Mail', 'username' => 'me@example.com', 'password' => 'BackupCanary-77!']);
    $svc->create(['name' => 'Local only', 'password' => 'x']);
    $entries = sampleEntries();
    eq(['added' => 1, 'skipped' => 1, 'removed' => 0], $svc->import($entries, 'merge'));
    eq(3, count($svc->list()));
    eq(['added' => 2, 'skipped' => 0, 'removed' => 3], $svc->import($entries, 'replace'));
    eq(['Mail', 'Ünïcødé ✓'], array_column($svc->list(), 'name'));
    ok($svc->list('mail')[0]['favorite']);
    eq($entries[0]['created_at'], $svc->list('mail')[0]['created_at'], 'timestamps preserved');
});
