<?php

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

use VaultForge\Security\Crypto;
use VaultForge\Vault\EntryRepository;
use VaultForge\Vault\EntryService;
use VaultForge\Vault\ValidationException;
use function VaultForge\Tests\{eq, freshDb, keys, notContains, ok, test, throws};

function service(): array
{
    [$db, $path] = freshDb();
    $dek = keys($db)->initialize('Unit-Test-Master-Pass-1');
    return [new EntryService(new EntryRepository($db), $dek), $db, $path, $dek];
}

test('CRUD operations', function () {
    [$svc] = service();
    $e = $svc->create(['name' => 'GitHub', 'url' => 'github.com', 'username' => 'octo@example.com', 'password' => 'gh-Secret-1!', 'notes' => '2FA on', 'category' => 'Development', 'favorite' => true]);
    eq('GitHub', $e['name']);
    eq('https://github.com', $e['url'], 'scheme added');
    ok($e['favorite']);
    ok(!isset($e['password']), 'summaries never include the password');
    eq(['password' => 'gh-Secret-1!', 'notes' => '2FA on'], $svc->secret($e['id']));

    $u = $svc->update($e['id'], ['name' => 'GitHub Work', 'url' => '', 'username' => 'octo', 'password' => 'new-Pass-2', 'notes' => '', 'category' => 'Work', 'favorite' => false]);
    eq('GitHub Work', $u['name']);
    eq('new-Pass-2', $svc->secret($e['id'])['password']);
    ok(!$u['favorite']);
    eq(null, $svc->update(9999, ['name' => 'x', 'password' => 'y']));

    ok($svc->setFavorite($e['id'], true)['favorite']);
    ok($svc->delete($e['id']));
    ok(!$svc->delete($e['id']));
    eq(null, $svc->get($e['id']));
});

test('search, category filter, favorites and sorting', function () {
    [$svc] = service();
    $svc->create(['name' => 'Netflix', 'username' => 'movie@fan.tv', 'password' => 'a1', 'category' => 'Entertainment']);
    $svc->create(['name' => 'Bank of Tests', 'username' => 'saver', 'password' => 'a2', 'category' => 'Finance', 'favorite' => true]);
    $svc->create(['name' => 'amazon', 'url' => 'https://amazon.example', 'password' => 'a3', 'category' => 'Shopping']);
    eq(['amazon', 'Bank of Tests', 'Netflix'], array_column($svc->list(), 'name'), 'natural case-insensitive sort');
    eq(['Netflix'], array_column($svc->list('FAN.tv'), 'name'), 'search username, case-insensitive');
    eq(['amazon'], array_column($svc->list('amazon.example'), 'name'), 'search URL');
    eq(['Bank of Tests'], array_column($svc->list('', 'finance'), 'name'), 'category filter');
    eq(['Bank of Tests'], array_column($svc->list('', '', true), 'name'), 'favorites');
    eq([], $svc->list('does-not-exist'));
    eq('amazon', $svc->list('', '', false, 'created')[0]['name'], 'newest first');
    ok(in_array('Finance', $svc->categories(), true));
});

test('validation rejects bad input', function () {
    [$svc] = service();
    $e = throws(ValidationException::class, fn () => $svc->create(['name' => '', 'password' => '']));
    ok(isset($e->errors['name'], $e->errors['password']));
    $e = throws(ValidationException::class, fn () => $svc->create(['name' => 'x', 'password' => 'y', 'url' => 'javascript:alert(1)']));
    ok(isset($e->errors['url']), 'javascript: URLs rejected');
    throws(ValidationException::class, fn () => $svc->create(['name' => ['array'], 'password' => 'y']));
    throws(ValidationException::class, fn () => $svc->create(['name' => 'x', 'password' => 'y', 'favorite' => 'yes']));
    throws(ValidationException::class, fn () => $svc->create(['name' => str_repeat('n', 201), 'password' => 'y']));
    throws(ValidationException::class, fn () => $svc->create(['name' => "bad\x01name", 'password' => 'y']));
    throws(ValidationException::class, fn () => $svc->create(['name' => "x", 'password' => "\xff\xfe"]));
});

test('no plaintext of any sensitive field is stored in the database file', function () {
    [$svc, $db, $path] = service();
    $svc->create(['name' => 'CanaryName-71a', 'url' => 'https://canary-host-55.example', 'username' => 'canary-user-93',
        'password' => 'CanaryPassword-x9!', 'notes' => 'CanaryNotes-q4', 'category' => 'CanaryCategory-z2']);
    $db->exec('PRAGMA wal_checkpoint');
    $raw = '';
    foreach (glob($path . '*') as $f) {
        $raw .= file_get_contents($f);
    }
    foreach (['CanaryName-71a', 'canary-host-55', 'canary-user-93', 'CanaryPassword-x9!', 'CanaryNotes-q4', 'CanaryCategory-z2'] as $needle) {
        notContains($needle, $raw, 'plaintext found in DB');
        notContains(base64_encode($needle), $raw);
    }
    $row = $db->query('SELECT * FROM entries')->fetch();
    foreach (['meta_ct', 'password_ct', 'notes_ct'] as $col) {
        ok(str_starts_with($row[$col], 'VF1'), "$col is ciphertext");
    }
});

test('ciphertexts cannot be swapped between rows or fields', function () {
    [$svc, $db] = service();
    $a = $svc->create(['name' => 'A', 'password' => 'password-A']);
    $b = $svc->create(['name' => 'B', 'password' => 'password-B']);
    $pwA = $db->query('SELECT password_ct FROM entries WHERE id = ' . $a['id'])->fetchColumn();
    $stmt = $db->prepare('UPDATE entries SET password_ct = :p WHERE id = :id');
    $stmt->bindValue(':p', $pwA, PDO::PARAM_LOB);
    $stmt->bindValue(':id', $b['id'], PDO::PARAM_INT);
    $stmt->execute();
    throws(\VaultForge\Security\DecryptionException::class, fn () => $svc->secret($b['id']));
    $notesA = $db->query('SELECT notes_ct FROM entries WHERE id = ' . $a['id'])->fetchColumn();
    $stmt = $db->prepare('UPDATE entries SET meta_ct = :p WHERE id = :id');
    $stmt->bindValue(':p', $notesA, PDO::PARAM_LOB);
    $stmt->bindValue(':id', $a['id'], PDO::PARAM_INT);
    $stmt->execute();
    ok($svc->get($a['id'])['corrupt'], 'swapped field reported as unreadable, not misread');
});

test('stats count weak and reused passwords', function () {
    [$svc] = service();
    $svc->create(['name' => 'a', 'password' => 'password', 'favorite' => true]);
    $svc->create(['name' => 'b', 'password' => 'password']);
    $svc->create(['name' => 'c', 'password' => 'Vq7#kP2$wZ9!mL4@xR8&']);
    $s = $svc->stats();
    eq(3, $s['total']);
    eq(1, $s['favorites']);
    eq(2, $s['weak']);
    eq(2, $s['reused']);
    eq(3, count($s['recent']));
});

test('key rotation re-encrypts everything in a transaction', function () {
    [$svc, $db, , $dek] = service();
    $e = $svc->create(['name' => 'Rotate', 'password' => 'rotate-me', 'notes' => 'n']);
    $before = $db->query('SELECT password_ct FROM entries')->fetchColumn();
    $newDek = Crypto::newKey();
    throws(\LogicException::class, fn () => $svc->reencryptAll($newDek), 'must be inside a transaction');
    $db->beginTransaction();
    eq(1, $svc->reencryptAll($newDek));
    $db->commit();
    ok($before !== $db->query('SELECT password_ct FROM entries')->fetchColumn());
    $rotated = new EntryService(new EntryRepository($db), $newDek);
    eq('rotate-me', $rotated->secret($e['id'])['password']);
    throws(\VaultForge\Security\DecryptionException::class, fn () => $svc->secret($e['id']), 'old key no longer works');
});
