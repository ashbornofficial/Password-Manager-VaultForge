<?php

declare(strict_types=1);

use function VaultForge\Tests\{ok, test};

test('source files are UTF-8 without BOM (a BOM before <?php breaks output and strict_types)', function () {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(VF_ROOT, FilesystemIterator::SKIP_DOTS));
    $checked = 0;
    foreach ($it as $file) {
        $path = str_replace('\\', '/', $file->getPathname());
        if (preg_match('#/(storage|\.git)/#', $path) || !preg_match('/\.(php|js|css|ini|md|txt)$/', $path)) {
            continue;
        }
        $content = (string) file_get_contents($path);
        ok(!str_starts_with($content, "\xEF\xBB\xBF"), "BOM in $path");
        ok(preg_match('//u', $content) === 1, "invalid UTF-8 in $path");
        ok(!str_contains($content, "\xC3\x82\xC2\xB7") && !str_contains($content, "\xC3\xA2\xE2\x82\xAC"), "mojibake in $path");
        $checked++;
    }
    ok($checked > 40, 'scanned the project');
});
