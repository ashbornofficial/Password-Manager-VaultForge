<?php

/*
 * VaultForge test runner (no PHPUnit / Composer needed).
 *
 *   powershell -ExecutionPolicy Bypass -File run-tests.ps1            all tests
 *   powershell -ExecutionPolicy Bypass -File run-tests.ps1 backup     only tests whose file/name contains "backup"
 */

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';
require __DIR__ . '/lib/Test.php';
require __DIR__ . '/lib/HttpClient.php';
require __DIR__ . '/lib/TestServer.php';

error_reporting(E_ALL);
ini_set('display_errors', '1');
set_error_handler(static function (int $no, string $str, string $file, int $line): bool {
    if (!(error_reporting() & $no)) {
        return false; // silenced with @
    }
    throw new \ErrorException($str, 0, $no, $file, $line);
});

$files = array_merge(glob(__DIR__ . '/Unit/*Test.php') ?: [], glob(__DIR__ . '/Integration/*Test.php') ?: []);
foreach ($files as $file) {
    VaultForge\Tests\Test::$currentFile = str_replace(__DIR__ . DIRECTORY_SEPARATOR, '', $file);
    require $file;
}

exit(VaultForge\Tests\Test::run($argv[1] ?? null));
