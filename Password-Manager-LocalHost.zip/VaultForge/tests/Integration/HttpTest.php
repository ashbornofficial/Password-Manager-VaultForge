<?php

declare(strict_types=1);

use VaultForge\Tests\HttpClient;
use VaultForge\Tests\TestServer;
use function VaultForge\Tests\{contains, eq, notContains, ok, test};

/*
 * End-to-end tests against a real PHP built-in server (127.0.0.1:8099) with its own
 * temporary storage directory and the production KDF parameters. Tests run in order.
 */

const MASTER = 'Integration-Master-Passphrase-7!';
const MASTER2 = 'Rotated-Master-Passphrase-8?';
const BACKUP_PW = 'Separate-Backup-Password-9';
const CANARY_PW = 'HttpCanaryPassword-5f2!';
const CANARY_NOTE = 'HttpCanaryNote-c81';

final class Ctx
{
    public static ?TestServer $server = null;
    public static ?HttpClient $c = null;
    public static array $ids = [];
    public static string $backup = '';
}

function srv(): TestServer
{
    return Ctx::$server ??= new TestServer(8099);
}

function client(): HttpClient
{
    srv();
    return Ctx::$c ??= new HttpClient(8099);
}

function location(array $r): string
{
    return (string) HttpClient::header($r, 'Location');
}

function flashText(HttpClient $c, string $page): string
{
    $r = $c->get($page);
    preg_match_all('/data-message="([^"]*)"/', $r['body'], $m);
    return html_entity_decode(implode(' | ', $m[1]), ENT_QUOTES | ENT_HTML5);
}

function rawStorage(string $dir): string
{
    $raw = '';
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile() && !str_ends_with($f->getFilename(), '.log')) {
            $raw .= file_get_contents($f->getPathname());
        }
    }
    return $raw;
}

test('before setup every page redirects to first-run setup', function () {
    $c = client();
    $r = $c->get('/');
    eq(303, $r['status']);
    eq('/setup', location($r));
    eq('/setup', location($c->get('/unlock')));
    $api = $c->api('GET', '/api/entries');
    ok(in_array($api['status'], [403, 409], true), 'API refuses before setup');
});

test('security headers and cookie attributes', function () {
    srv();
    $c = new HttpClient(8099); // fresh cookie jar so the session cookie is issued
    $r = $c->get('/setup');
    eq(200, $r['status']);
    $csp = (string) HttpClient::header($r, 'Content-Security-Policy');
    contains("default-src 'none'", $csp);
    contains("script-src 'self'", $csp);
    contains("frame-ancestors 'none'", $csp);
    notContains('unsafe-inline', $csp);
    eq('nosniff', HttpClient::header($r, 'X-Content-Type-Options'));
    eq('DENY', HttpClient::header($r, 'X-Frame-Options'));
    eq('same-origin', HttpClient::header($r, 'Referrer-Policy'));
    contains('no-store', (string) HttpClient::header($r, 'Cache-Control'));
    eq(null, HttpClient::header($r, 'X-Powered-By'));
    $cookie = implode("\n", $r['headers']['set-cookie'] ?? []);
    contains('VFSESSID=', $cookie);
    contains('HttpOnly', $cookie);
    contains('SameSite=Strict', $cookie);
    notContains('<script>', preg_replace('#<script src="/assets/[^"]+" defer></script>#', '', $r['body']), 'no inline scripts');
    notContains(' style="', $r['body'], 'no inline styles');
});

test('host header and loopback guard (DNS rebinding)', function () {
    srv();
    $evil = new HttpClient(8099, 'evil.example:8099');
    eq(421, $evil->get('/setup')['status']);
    eq(421, (new HttpClient(8099, '192.168.1.10:8099'))->get('/setup')['status']);
    eq(200, (new HttpClient(8099, 'localhost:8099'))->get('/setup')['status']);
});

test('the SQLite database and other files are never downloadable', function () {
    $c = client();
    foreach (['/vault.sqlite', '/storage/vault.sqlite', '/../storage/vault.sqlite', '/assets/../../storage/vault.sqlite',
        '/assets/..%2f..%2fstorage%2fvault.sqlite', '/assets/%2e%2e/%2e%2e/storage/vault.sqlite', '/assets/..\\..\\storage\\vault.sqlite',
        '/config/config.php', '/assets/../index.php', '/src/App.php', '/storage/sessions', '/.htaccess'] as $path) {
        $r = $c->request('GET', $path);
        notContains('SQLite format 3', $r['body'], "DB leaked via $path");
        notContains('<?php', $r['body'], "source leaked via $path");
        ok($r['status'] >= 300, "$path should not be served (got {$r['status']})");
    }
    $css = $c->request('GET', '/assets/css/app.css');
    eq(200, $css['status']);
    contains('text/css', (string) HttpClient::header($css, 'Content-Type'));
    eq(404, $c->request('GET', '/assets/js/../../index.php')['status']);
});

test('setup requires a CSRF token, a strong password, confirmation and acknowledgement', function () {
    $c = client();
    $c->get('/setup');
    $r = $c->post('/setup', ['master_password' => MASTER, 'master_password_confirm' => MASTER, 'acknowledge' => '1'], false);
    eq(303, $r['status'], 'missing CSRF rejected');
    eq('/setup', location($c->get('/')), 'vault still not initialised');

    $c->get('/setup');
    $r = $c->post('/setup', ['_csrf' => str_repeat('0', 64), 'master_password' => MASTER, 'master_password_confirm' => MASTER, 'acknowledge' => '1']);
    eq(303, $r['status'], 'forged CSRF rejected');

    $c->get('/setup');
    eq(422, $c->post('/setup', ['master_password' => 'short', 'master_password_confirm' => 'short', 'acknowledge' => '1'])['status']);
    eq(422, $c->post('/setup', ['master_password' => 'Password12345', 'master_password_confirm' => 'Password12345', 'acknowledge' => '1'])['status']);
    eq(422, $c->post('/setup', ['master_password' => MASTER, 'master_password_confirm' => MASTER . 'x', 'acknowledge' => '1'])['status']);
    $r = $c->post('/setup', ['master_password' => MASTER, 'master_password_confirm' => MASTER]);
    eq(422, $r['status']);
    contains('cannot be recovered', $r['body']);
});

test('successful setup unlocks the vault and regenerates the session ID', function () {
    $c = client();
    $c->get('/setup');
    $before = $c->cookies['VFSESSID'] ?? '';
    $r = $c->post('/setup', ['master_password' => MASTER, 'master_password_confirm' => MASTER, 'acknowledge' => '1']);
    eq(303, $r['status']);
    eq('/', location($r));
    ok(($c->cookies['VFSESSID'] ?? '') !== '' && $c->cookies['VFSESSID'] !== $before, 'session ID regenerated');
    $keyCookie = implode("\n", array_filter($r['headers']['set-cookie'] ?? [], fn ($h) => str_starts_with($h, 'VFKEY=')));
    contains('HttpOnly', $keyCookie);
    contains('SameSite=Strict', $keyCookie);
    $page = $c->get('/');
    eq(200, $page['status']);
    contains('Dashboard', $page['body']);
    eq('/', location($c->get('/setup')), 'setup cannot run twice');
});

test('API enforces CSRF token, Origin and Fetch-Metadata', function () {
    $c = client();
    $c->refreshCsrf('/');
    eq(200, $c->api('GET', '/api/entries')['status']);
    eq(403, $c->request('GET', '/api/entries', null, ['Accept' => 'application/json'])['status'], 'no token');
    eq(403, $c->api('POST', '/api/entries', ['name' => 'x', 'password' => 'y'], ['X-CSRF-Token' => 'bad'])['status']);
    eq(403, $c->api('POST', '/api/entries', ['name' => 'x', 'password' => 'y'], ['Origin' => 'http://evil.example'])['status']);
    eq(403, $c->api('POST', '/api/entries', ['name' => 'x', 'password' => 'y'], ['Origin' => 'http://127.0.0.1:3000'])['status'], 'other local port');
    eq(403, $c->api('POST', '/api/entries', ['name' => 'x', 'password' => 'y'], ['Sec-Fetch-Site' => 'cross-site'])['status']);
    eq(403, $c->api('POST', '/api/entries', ['name' => 'x', 'password' => 'y'], ['Sec-Fetch-Site' => 'same-site'])['status']);
    eq(0, $c->api('GET', '/api/entries')['json']['count'], 'nothing was created');
    eq(403, $c->post('/settings/preferences', ['auto_lock_minutes' => '60', 'clipboard_clear_seconds' => '0'], true, ['Origin' => 'http://evil.example'])['status']);
});

test('entry CRUD, search, filters and favorites over HTTP', function () {
    $c = client();
    $create = fn (array $e) => $c->api('POST', '/api/entries', $e + ['url' => '', 'username' => '', 'notes' => '', 'category' => '', 'favorite' => false]);
    $r = $create(['name' => 'Canary Bank', 'username' => 'canary-user', 'password' => CANARY_PW, 'notes' => CANARY_NOTE, 'category' => 'Finance', 'favorite' => true]);
    eq(201, $r['status']);
    Ctx::$ids['bank'] = $r['json']['entry']['id'];
    ok(!array_key_exists('password', $r['json']['entry']), 'create response has no password');
    Ctx::$ids['mail'] = $create(['name' => 'Webmail', 'url' => 'mail.example.com', 'username' => 'me@mail.example', 'password' => 'MailPass-123!', 'category' => 'Email'])['json']['entry']['id'];
    Ctx::$ids['xss'] = $create(['name' => '<img src=x onerror=alert(1)>', 'password' => 'xss-pass-1'])['json']['entry']['id'];

    $bad = $create(['name' => '', 'password' => '', 'url' => 'javascript:alert(1)']);
    eq(422, $bad['status']);
    ok(isset($bad['json']['errors']['name'], $bad['json']['errors']['password'], $bad['json']['errors']['url']));
    eq(400, $c->request('POST', '/api/entries', '{not json', ['X-CSRF-Token' => (string) $c->csrf, 'Content-Type' => 'application/json'])['status']);

    $list = $c->api('GET', '/api/entries')['json'];
    eq(3, $list['count']);
    foreach ($list['entries'] as $e) {
        ok(!isset($e['password']) && !isset($e['notes']), 'list never contains secrets');
    }
    eq(['Webmail'], array_column($c->api('GET', '/api/entries?q=MAIL.example')['json']['entries'], 'name'));
    eq(['Canary Bank'], array_column($c->api('GET', '/api/entries?category=finance')['json']['entries'], 'name'));
    eq(['Canary Bank'], array_column($c->api('GET', '/api/entries?favorites=1')['json']['entries'], 'name'));
    eq('https://mail.example.com', $c->api('GET', '/api/entries/' . Ctx::$ids['mail'])['json']['entry']['url']);

    $secret = $c->api('GET', '/api/entries/' . Ctx::$ids['bank'] . '/secret');
    eq(['password' => CANARY_PW, 'notes' => CANARY_NOTE], $secret['json']);
    contains('no-store', (string) HttpClient::header($secret, 'Cache-Control'));

    $u = $c->api('PUT', '/api/entries/' . Ctx::$ids['mail'], ['name' => 'Webmail 2', 'url' => '', 'username' => 'me', 'password' => 'Changed-Pass-9', 'notes' => 'n', 'category' => 'Email', 'favorite' => false]);
    eq(200, $u['status']);
    eq('Webmail 2', $u['json']['entry']['name']);
    eq('Changed-Pass-9', $c->api('GET', '/api/entries/' . Ctx::$ids['mail'] . '/secret')['json']['password']);
    ok($c->api('POST', '/api/entries/' . Ctx::$ids['mail'] . '/favorite', ['favorite' => true])['json']['entry']['favorite']);
    eq(422, $c->api('POST', '/api/entries/' . Ctx::$ids['mail'] . '/favorite', ['favorite' => 'yes'])['status']);

    eq(200, $c->api('DELETE', '/api/entries/' . Ctx::$ids['mail'])['status']);
    eq(404, $c->api('DELETE', '/api/entries/' . Ctx::$ids['mail'])['status']);
    eq(404, $c->api('GET', '/api/entries/99999/secret')['status']);
    eq(405, $c->api('PATCH', '/api/entries/' . Ctx::$ids['bank'])['status']);

    $stats = $c->api('GET', '/api/stats')['json'];
    eq(2, $stats['total']);
    eq(1, $stats['favorites']);
});

test('XSS payloads are returned as JSON data and never rendered by the server', function () {
    $c = client();
    $r = $c->api('GET', '/api/entries/' . Ctx::$ids['xss']);
    contains('application/json', (string) HttpClient::header($r, 'Content-Type'));
    eq('<img src=x onerror=alert(1)>', $r['json']['entry']['name']);
    foreach (['/', '/vault', '/generator', '/settings', '/backup'] as $page) {
        $html = $c->get($page)['body'];
        notContains('onerror=alert', $html, "payload rendered on $page");
    }
});

test('database and session files contain no plaintext secrets', function () {
    $raw = rawStorage(srv()->storage);
    foreach ([CANARY_PW, CANARY_NOTE, 'canary-user', 'Canary Bank', MASTER] as $needle) {
        notContains($needle, $raw, 'plaintext secret found in storage');
        notContains(base64_encode($needle), $raw);
    }
    contains('SQLite format 3', $raw, 'sanity: the DB file was scanned');
});

test('generator API enforces rules server-side', function () {
    $c = client();
    $r = $c->api('POST', '/api/generate/password', ['length' => 32, 'upper' => false, 'lower' => false, 'digits' => true, 'symbols' => false]);
    eq(200, $r['status']);
    ok(preg_match('/^\d{32}$/', $r['json']['password']) === 1);
    eq(422, $c->api('POST', '/api/generate/password', ['length' => 7])['status']);
    eq(422, $c->api('POST', '/api/generate/password', ['length' => 200])['status']);
    eq(422, $c->api('POST', '/api/generate/password', ['length' => '20'])['status'], 'type checked');
    eq(422, $c->api('POST', '/api/generate/password', ['upper' => false, 'lower' => false, 'digits' => false, 'symbols' => false])['status']);
    $p = $c->api('POST', '/api/generate/passphrase', ['words' => 4, 'separator' => 'period', 'capitalize' => true, 'number' => false]);
    eq(4, count(explode('.', $p['json']['password'])));
    eq(422, $c->api('POST', '/api/generate/passphrase', ['words' => 50])['status']);
});

test('encrypted backup export requires the master password and a separate backup password', function () {
    $c = client();
    $c->refreshCsrf('/backup');
    $r = $c->post('/backup/export', ['master_password' => 'wrong-master-password', 'backup_password' => BACKUP_PW, 'backup_password_confirm' => BACKUP_PW]);
    eq('/backup', location($r));
    contains('Incorrect master password', flashText($c, '/backup'));
    $r = $c->post('/backup/export', ['master_password' => MASTER, 'backup_password' => MASTER, 'backup_password_confirm' => MASTER]);
    contains('different from your master password', flashText($c, '/backup'));
    $r = $c->post('/backup/export', ['master_password' => MASTER, 'backup_password' => 'short', 'backup_password_confirm' => 'short']);
    contains('at least', flashText($c, '/backup'));

    $r = $c->post('/backup/export', ['master_password' => MASTER, 'backup_password' => BACKUP_PW, 'backup_password_confirm' => BACKUP_PW]);
    eq(200, $r['status']);
    contains('attachment; filename="vaultforge-backup-', (string) HttpClient::header($r, 'Content-Disposition'));
    $doc = json_decode($r['body'], true);
    eq('vaultforge-backup', $doc['format']);
    eq(2, $doc['entry_count']);
    notContains(CANARY_PW, $r['body']);
    notContains('canary-user', $r['body']);
    Ctx::$backup = $r['body'];
});

test('restore rejects tampered, foreign and wrongly-decrypted backups without changing data', function () {
    $c = client();
    $c->refreshCsrf('/backup');
    $before = $c->api('GET', '/api/entries')['json']['entries'];
    $doc = json_decode(Ctx::$backup, true);
    $ct = base64_decode($doc['ciphertext']);
    $ct[50] = chr(ord($ct[50]) ^ 1);
    $tampered = json_encode(['ciphertext' => base64_encode($ct)] + $doc);
    $headerTampered = json_encode(['entry_count' => 3] + $doc);

    $cases = [
        [$tampered, BACKUP_PW, 'replace', 'modified or corrupted'],
        [$headerTampered, BACKUP_PW, 'merge', 'modified or corrupted'],
        [Ctx::$backup, 'Wrong-Backup-Password-1', 'merge', 'Wrong backup password'],
        ['{"hello":"world"}', BACKUP_PW, 'merge', 'not a VaultForge backup'],
        [random_bytes(500), BACKUP_PW, 'merge', 'invalid JSON'],
        [Ctx::$backup, BACKUP_PW, 'replace', 'Tick the confirmation box'], // replace without confirmation
    ];
    foreach ($cases as [$content, $pw, $mode, $expected]) {
        $fields = ['backup_password' => $pw, 'mode' => $mode];
        if ($mode === 'replace' && $expected !== 'Tick the confirmation box') {
            $fields['confirm_replace'] = '1';
        }
        $r = $c->multipart('/backup/restore', $fields, 'backup_file', 'x.vfbackup', $content);
        eq('/backup', location($r));
        contains($expected, flashText($c, '/backup'));
        $c->refreshCsrf('/backup');
    }
    eq($before, $c->api('GET', '/api/entries')['json']['entries'], 'vault unchanged after rejected restores');
});

test('restore replace and merge work and keep a safety snapshot', function () {
    $c = client();
    $c->refreshCsrf('/backup');
    $c->api('POST', '/api/entries', ['name' => 'Added after backup', 'password' => 'p-1', 'url' => '', 'username' => '', 'notes' => '', 'category' => '', 'favorite' => false]);
    eq(3, $c->api('GET', '/api/entries')['json']['count']);

    $r = $c->multipart('/backup/restore', ['backup_password' => BACKUP_PW, 'mode' => 'merge'], 'backup_file', 'b.vfbackup', Ctx::$backup);
    contains('0 entries added', flashText($c, '/backup'), 'merge skips duplicates');
    eq(3, $c->api('GET', '/api/entries')['json']['count']);

    $c->refreshCsrf('/backup');
    $r = $c->multipart('/backup/restore', ['backup_password' => BACKUP_PW, 'mode' => 'replace', 'confirm_replace' => '1'], 'backup_file', 'b.vfbackup', Ctx::$backup);
    $msg = flashText($c, '/backup');
    contains('2 entries added', $msg);
    contains('safety copy', $msg);
    $list = $c->api('GET', '/api/entries')['json'];
    eq(2, $list['count']);
    ok(!in_array('Added after backup', array_column($list['entries'], 'name'), true));
    $bank = array_values(array_filter($list['entries'], fn ($e) => $e['name'] === 'Canary Bank'))[0];
    eq(CANARY_PW, $c->api('GET', '/api/entries/' . $bank['id'] . '/secret')['json']['password']);
    Ctx::$ids['bank'] = $bank['id'];
    ok(count(glob(srv()->storage . '/backups/pre-restore-*.sqlite')) === 1, 'snapshot written');
});

test('manual lock wipes the session; old cookies are useless', function () {
    $c = client();
    $c->refreshCsrf('/');
    $oldCookies = $c->cookies;
    $r = $c->post('/lock', []);
    eq(303, $r['status']);
    eq('/unlock', location($r));
    ok(!isset($c->cookies['VFKEY']), 'key cookie cleared');
    eq('/unlock', location($c->get('/vault')));
    $api = $c->api('GET', '/api/entries');
    eq(401, $api['status']);
    ok($api['json']['locked'] === true);

    $replay = new HttpClient(8099);
    $replay->cookies = $oldCookies;
    eq(401, $replay->api('GET', '/api/entries', null, ['X-CSRF-Token' => (string) $c->csrf])['status'], 'replaying pre-lock cookies fails');
    eq('/unlock', location($replay->get('/')));
});

test('unlock with wrong and correct master passwords', function () {
    $c = client();
    $c->get('/unlock');
    $r = $c->post('/unlock', ['master_password' => 'definitely-not-it']);
    eq(401, $r['status']);
    contains('Incorrect master password', $r['body']);
    eq(401, $c->post('/unlock', ['master_password' => ''])['status']);
    $before = $c->cookies['VFSESSID'];
    $r = $c->post('/unlock', ['master_password' => MASTER]);
    eq(303, $r['status']);
    eq('/', location($r));
    ok($c->cookies['VFSESSID'] !== $before, 'session ID regenerated on unlock');
    $c->refreshCsrf('/');
    eq(CANARY_PW, $c->api('GET', '/api/entries/' . Ctx::$ids['bank'] . '/secret')['json']['password']);
});

test('a missing key cookie locks the vault even with a valid session cookie', function () {
    $c = client();
    $stolen = new HttpClient(8099);
    $stolen->cookies = ['VFSESSID' => $c->cookies['VFSESSID']]; // session id only, no VFKEY
    eq(401, $stolen->api('GET', '/api/entries', null, ['X-CSRF-Token' => (string) $c->csrf])['status']);
    eq('/unlock', location($c->get('/')), 'the session was locked as a precaution');
    $c->get('/unlock');
    eq(303, $c->post('/unlock', ['master_password' => MASTER])['status']);
});

test('changing the master password rotates keys; old password stops working', function () {
    $c = client();
    $c->refreshCsrf('/settings');
    $dbPath = srv()->storage . '/vault.sqlite';
    $pdo = new PDO('sqlite:' . $dbPath);
    $ctBefore = $pdo->query('SELECT password_ct FROM entries ORDER BY id LIMIT 1')->fetchColumn();
    $pdo = null;

    $c->post('/settings/master-password', ['current_password' => 'wrong-current-pass', 'new_password' => MASTER2, 'new_password_confirm' => MASTER2]);
    contains('current master password is incorrect', flashText($c, '/settings'));
    $c->post('/settings/master-password', ['current_password' => MASTER, 'new_password' => MASTER2, 'new_password_confirm' => MASTER2]);
    contains('Master password changed', flashText($c, '/settings'));

    $pdo = new PDO('sqlite:' . $dbPath);
    ok($ctBefore !== $pdo->query('SELECT password_ct FROM entries ORDER BY id LIMIT 1')->fetchColumn(), 'ciphertexts re-encrypted');
    $pdo = null;
    eq(CANARY_PW, $c->api('GET', '/api/entries/' . Ctx::$ids['bank'] . '/secret')['json']['password'], 'still unlocked after change');

    $c->post('/lock', []);
    $c->get('/unlock');
    eq(401, $c->post('/unlock', ['master_password' => MASTER])['status'], 'old password rejected');
    eq(303, $c->post('/unlock', ['master_password' => MASTER2])['status'], 'new password accepted');
    $c->refreshCsrf('/');
    eq(CANARY_PW, $c->api('GET', '/api/entries/' . Ctx::$ids['bank'] . '/secret')['json']['password']);
});

test('preferences are validated and saved', function () {
    $c = client();
    $c->refreshCsrf('/settings');
    $c->post('/settings/preferences', ['auto_lock_minutes' => '0', 'clipboard_clear_seconds' => '10']);
    contains('between', flashText($c, '/settings'));
    $c->post('/settings/preferences', ['auto_lock_minutes' => '15', 'clipboard_clear_seconds' => '45']);
    contains('Preferences saved', flashText($c, '/settings'));
    $page = $c->get('/settings')['body'];
    contains('data-idle-seconds="900"', $page);
    contains('data-clipboard-seconds="45"', $page);
});

test('login throttling locks out after repeated failures, even for the right password', function () {
    $c = client();
    $c->post('/lock', []);
    $c->get('/unlock');
    $last = null;
    for ($i = 0; $i < 5; $i++) {
        $last = $c->post('/unlock', ['master_password' => 'brute-force-guess-' . $i]);
    }
    contains('Too many failed attempts', $last['body']);
    $r = $c->post('/unlock', ['master_password' => MASTER2]);
    eq(429, $r['status'], 'correct password refused during lockout');
    contains('Try again in', $r['body']);
    contains('data-retry-after', $c->get('/unlock')['body']);
});

test('automatic lock after inactivity (server-enforced) and activity keep-alive', function () {
    $server = new TestServer(8098, ['VAULTFORGE_IDLE_SECONDS' => '3']);
    $c = new HttpClient(8098);
    $c->get('/setup');
    eq(303, $c->post('/setup', ['master_password' => MASTER, 'master_password_confirm' => MASTER, 'acknowledge' => '1'])['status']);
    $c->refreshCsrf('/');
    for ($i = 0; $i < 4; $i++) {
        usleep(1500000);
        eq(200, $c->api('POST', '/api/ping')['status'], 'activity keeps the vault unlocked');
    }
    sleep(4);
    $r = $c->api('GET', '/api/entries');
    eq(401, $r['status'], 'locked after idle timeout');
    ok($r['json']['locked'] === true);
    eq('/unlock', location($c->get('/')));
    contains('inactivity', flashText($c, '/unlock'), 'user is told why the vault locked');
    $server->stop();
});

test('no remote network access: no external URLs in shipped HTML, CSS or JS', function () {
    $root = VF_ROOT;
    $files = array_merge(
        glob("$root/public/assets/js/*.js"), glob("$root/public/assets/css/*.css"),
        glob("$root/templates/*.php"), glob("$root/templates/*/*.php"), ["$root/public/index.php"]
    );
    foreach ($files as $f) {
        $src = (string) file_get_contents($f);
        $src = str_replace('http://www.w3.org/2000/svg', '', $src);
        ok(preg_match('#https?://(?!127\.0\.0\.1|localhost)[a-z0-9-]+\.[a-z0-9.-]+#i', $src, $m) !== 1, 'external URL in ' . basename($f) . ': ' . ($m[0] ?? ''));
        ok(preg_match('#(src|href|action)=["\']//#i', $src) !== 1, 'protocol-relative URL in ' . basename($f));
        notContains('@import', $src);
        notContains('fonts.googleapis', $src);
    }
    $csp = VaultForge\Security\SecurityHeaders::CSP;
    contains("connect-src 'self'", $csp);
});
