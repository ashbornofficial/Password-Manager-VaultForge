<?php

declare(strict_types=1);

namespace VaultForge\Tests;

/** Starts a real PHP built-in server on 127.0.0.1 with an isolated temporary storage directory. */
final class TestServer
{
    /** @var resource|null */
    private $process = null;
    public readonly string $storage;

    public function __construct(public readonly int $port, array $env = [])
    {
        $this->storage = tempDir('vf-http');
        $root = dirname(__DIR__, 2);
        $phpArgs = json_decode((string) getenv('VAULTFORGE_PHP_ARGS'), true) ?: [];
        $cmd = array_merge([PHP_BINARY], $phpArgs, ['-S', "127.0.0.1:$port", '-t', "$root/public", "$root/public/index.php"]);
        $environment = array_merge(getenv(), ['VAULTFORGE_STORAGE' => $this->storage, 'VAULTFORGE_PORT' => (string) $port], $env);
        $log = $this->storage . DIRECTORY_SEPARATOR . 'server-test.log';
        $this->process = proc_open($cmd, [0 => ['pipe', 'r'], 1 => ['file', $log, 'a'], 2 => ['file', $log, 'a']], $pipes, $root, $environment, ['bypass_shell' => true]);
        if (!is_resource($this->process)) {
            throw new \RuntimeException('Could not start the test server.');
        }
        for ($i = 0; $i < 80; $i++) {
            $sock = @stream_socket_client("tcp://127.0.0.1:$port", $e, $s, 0.2);
            if ($sock) {
                fclose($sock);
                register_shutdown_function(fn () => $this->stop());
                return;
            }
            usleep(100000);
        }
        $this->stop();
        throw new \RuntimeException("Test server did not start on port $port");
    }

    public function stop(): void
    {
        if (is_resource($this->process)) {
            proc_terminate($this->process);
            proc_close($this->process);
        }
        $this->process = null;
    }
}
