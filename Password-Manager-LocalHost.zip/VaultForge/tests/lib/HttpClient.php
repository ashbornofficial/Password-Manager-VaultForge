<?php

declare(strict_types=1);

namespace VaultForge\Tests;

/** Raw-socket HTTP/1.0 client with a cookie jar (no curl / allow_url_fopen needed). */
final class HttpClient
{
    /** @var array<string, string> */
    public array $cookies = [];
    public ?string $csrf = null;

    public function __construct(public readonly int $port, public string $host = '')
    {
        $this->host = $host !== '' ? $host : "127.0.0.1:$port";
    }

    /**
     * @param array<string, string> $headers
     * @return array{status: int, headers: array<string, list<string>>, body: string}
     */
    public function request(string $method, string $path, ?string $body = null, array $headers = [], bool $sendCookies = true): array
    {
        $sock = @stream_socket_client("tcp://127.0.0.1:{$this->port}", $errno, $errstr, 10);
        if ($sock === false) {
            throw new \RuntimeException("Connect failed: $errstr");
        }
        stream_set_timeout($sock, 60);
        $lines = ["$method $path HTTP/1.0", "Host: {$this->host}", 'Connection: close'];
        if ($sendCookies && $this->cookies !== []) {
            $lines[] = 'Cookie: ' . implode('; ', array_map(static fn ($k, $v) => "$k=$v", array_keys($this->cookies), $this->cookies));
        }
        foreach ($headers as $k => $v) {
            $lines[] = "$k: $v";
        }
        if ($body !== null) {
            $lines[] = 'Content-Length: ' . strlen($body);
        }
        fwrite($sock, implode("\r\n", $lines) . "\r\n\r\n" . ($body ?? ''));
        $raw = stream_get_contents($sock);
        fclose($sock);

        [$head, $respBody] = array_pad(explode("\r\n\r\n", (string) $raw, 2), 2, '');
        $headerLines = explode("\r\n", $head);
        preg_match('#^HTTP/\d\.\d (\d{3})#', array_shift($headerLines) ?? '', $m);
        $parsed = [];
        foreach ($headerLines as $line) {
            [$k, $v] = array_pad(explode(':', $line, 2), 2, '');
            $parsed[strtolower(trim($k))][] = trim($v);
        }
        foreach ($parsed['set-cookie'] ?? [] as $cookie) {
            [$pair] = explode(';', $cookie, 2);
            [$name, $value] = array_pad(explode('=', $pair, 2), 2, '');
            $expired = $value === '' || $value === 'deleted' || preg_match('/max-age=0|expires=Thu, 01[- ]Jan[- ]1970/i', $cookie)
                || (preg_match('/expires=([^;]+)/i', $cookie, $em) && strtotime($em[1]) < time());
            if ($expired) {
                unset($this->cookies[$name]);
            } else {
                $this->cookies[$name] = $value;
            }
        }
        return ['status' => (int) ($m[1] ?? 0), 'headers' => $parsed, 'body' => $respBody];
    }

    public function get(string $path): array
    {
        $r = $this->request('GET', $path);
        $this->captureCsrf($r['body']);
        return $r;
    }

    /** @param array<string, string> $fields */
    public function post(string $path, array $fields, bool $withCsrf = true, array $headers = []): array
    {
        if ($withCsrf && !isset($fields['_csrf'])) {
            $fields['_csrf'] = (string) $this->csrf;
        }
        $r = $this->request('POST', $path, http_build_query($fields), ['Content-Type' => 'application/x-www-form-urlencoded'] + $headers);
        $this->captureCsrf($r['body']);
        return $r;
    }

    public function api(string $method, string $path, ?array $json = null, array $headers = []): array
    {
        // Caller-supplied headers win over the defaults.
        $h = $headers + ['Accept' => 'application/json', 'X-CSRF-Token' => (string) $this->csrf, 'Sec-Fetch-Site' => 'same-origin'];
        $body = null;
        if ($json !== null) {
            $h['Content-Type'] = 'application/json';
            $body = json_encode($json, JSON_THROW_ON_ERROR);
        }
        $r = $this->request($method, $path, $body, $h);
        $r['json'] = json_decode($r['body'], true);
        return $r;
    }

    /** @param array<string, string> $fields */
    public function multipart(string $path, array $fields, string $fileField, string $fileName, string $fileContent): array
    {
        $boundary = '----vf' . bin2hex(random_bytes(8));
        $fields['_csrf'] ??= (string) $this->csrf;
        $body = '';
        foreach ($fields as $k => $v) {
            $body .= "--$boundary\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n";
        }
        $body .= "--$boundary\r\nContent-Disposition: form-data; name=\"$fileField\"; filename=\"$fileName\"\r\nContent-Type: application/octet-stream\r\n\r\n$fileContent\r\n--$boundary--\r\n";
        return $this->request('POST', $path, $body, ['Content-Type' => "multipart/form-data; boundary=$boundary"]);
    }

    /** GET a page and read its CSRF token (needed after redirects). */
    public function refreshCsrf(string $path = '/'): void
    {
        $r = $this->get($path);
        if ($r['status'] === 303 && isset($r['headers']['location'][0])) {
            $this->get($r['headers']['location'][0]);
        }
    }

    public function captureCsrf(string $body): void
    {
        if (preg_match('/name="csrf-token" content="([a-f0-9]+)"/', $body, $m)) {
            $this->csrf = $m[1];
        }
    }

    public static function header(array $response, string $name): ?string
    {
        return $response['headers'][strtolower($name)][0] ?? null;
    }
}
