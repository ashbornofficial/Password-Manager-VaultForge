<?php

declare(strict_types=1);

namespace VaultForge\Tests;

/** Minimal dependency-free test framework. */
final class Test
{
    /** @var list<array{string, string, callable}> */
    public static array $tests = [];
    public static string $currentFile = '';
    public static int $assertions = 0;

    public static function add(string $name, callable $fn): void
    {
        self::$tests[] = [self::$currentFile, $name, $fn];
    }

    public static function run(?string $filter): int
    {
        $passed = 0;
        $failures = [];
        $start = microtime(true);
        $lastFile = '';
        foreach (self::$tests as [$file, $name, $fn]) {
            if ($filter !== null && stripos($file . ' ' . $name, $filter) === false) {
                continue;
            }
            if ($file !== $lastFile) {
                echo "\n" . $file . "\n";
                $lastFile = $file;
            }
            $t = microtime(true);
            try {
                $fn();
                $passed++;
                printf("  \033[32mPASS\033[0m %s \033[90m(%.2fs)\033[0m\n", $name, microtime(true) - $t);
            } catch (\Throwable $e) {
                $failures[] = "$file > $name";
                printf("  \033[31mFAIL\033[0m %s\n       %s: %s\n       at %s:%d\n", $name, get_class($e), $e->getMessage(), basename($e->getFile()), $e->getLine());
            }
        }
        printf("\n%d passed, %d failed, %d assertions in %.1fs\n", $passed, count($failures), self::$assertions, microtime(true) - $start);
        foreach ($failures as $f) {
            echo "  - $f\n";
        }
        return $failures === [] ? 0 : 1;
    }
}

final class AssertionFailed extends \RuntimeException
{
}

function test(string $name, callable $fn): void
{
    Test::add($name, $fn);
}

function ok(bool $condition, string $message = 'Assertion failed'): void
{
    Test::$assertions++;
    if (!$condition) {
        throw new AssertionFailed($message);
    }
}

function eq(mixed $expected, mixed $actual, string $message = ''): void
{
    Test::$assertions++;
    if ($expected !== $actual) {
        throw new AssertionFailed(($message !== '' ? "$message: " : '') . 'expected ' . var_export($expected, true) . ', got ' . var_export($actual, true));
    }
}

function contains(string $needle, string $haystack, string $message = ''): void
{
    Test::$assertions++;
    if (!str_contains($haystack, $needle)) {
        throw new AssertionFailed(($message !== '' ? "$message: " : '') . 'expected to find ' . var_export($needle, true) . ' in ' . var_export(substr($haystack, 0, 400), true));
    }
}

function notContains(string $needle, string $haystack, string $message = ''): void
{
    Test::$assertions++;
    if (str_contains($haystack, $needle)) {
        throw new AssertionFailed(($message !== '' ? "$message: " : '') . 'did not expect to find ' . var_export($needle, true));
    }
}

/** @param class-string<\Throwable> $class */
function throws(string $class, callable $fn, string $message = ''): \Throwable
{
    Test::$assertions++;
    try {
        $fn();
    } catch (\Throwable $e) {
        if ($e instanceof $class) {
            return $e;
        }
        throw new AssertionFailed("Expected $class, got " . get_class($e) . ': ' . $e->getMessage());
    }
    throw new AssertionFailed($message !== '' ? $message : "Expected $class to be thrown");
}

/** Fresh temporary directory (removed at shutdown). */
function tempDir(string $prefix = 'vf'): string
{
    $dir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $prefix . '-' . bin2hex(random_bytes(6));
    mkdir($dir, 0700, true);
    register_shutdown_function(static fn () => removeDir($dir));
    return $dir;
}

function removeDir(string $dir): void
{
    if (!is_dir($dir)) {
        return;
    }
    $items = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($items as $item) {
        $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
    }
    @rmdir($dir);
}
